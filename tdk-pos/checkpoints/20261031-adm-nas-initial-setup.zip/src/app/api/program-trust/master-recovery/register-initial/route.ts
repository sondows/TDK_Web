import { and, eq, isNull, ne, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { adminSecurityOwners, auditLogs, staff } from "@/db/schema";
import { hashProgramPassword, isValidProgramPassword } from "@/lib/auth";
import { isAdminAuthAttemptAllowed, recordAdminAuthFailure, clearAdminAuthFailures } from "@/lib/admin-auth-limit";
import { getKdsRateLimitIp } from "@/lib/kds-network-server";
import { isNasOwnerSetupWrite } from "@/lib/nas-owner-setup";

const noStore = { "Cache-Control": "no-store" };
const scope = "master-password-initial";

/** NAS local setup may fill a missing owner password exactly once. Recovery stays separate. */
export async function POST(request: Request) {
  if (!isNasOwnerSetupWrite(request))
    return NextResponse.json({ success: false }, { status: 403, headers: noStore });
  const body = await request.json().catch(() => null) as Record<string, unknown> | null;
  const loginId = typeof body?.loginId === "string" ? body.loginId.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!/^[a-z][a-z0-9._-]{2,31}$/.test(loginId) || !isValidProgramPassword(password) ||
    password !== body?.confirmPassword)
    return NextResponse.json({ success: false,
      message: "마스터 비밀번호는 10자리 이상이며 영문, 숫자, 특수문자를 포함하고 확인값과 같아야 합니다." },
    { status: 400, headers: noStore });

  const ip = await getKdsRateLimitIp();
  try {
    if (!await isAdminAuthAttemptAllowed(scope, loginId, ip))
      return NextResponse.json({ success: false, message: "시도 횟수가 많습니다. 15분 후 다시 시도해 주세요." },
        { status: 429, headers: noStore });
    const passwordHash = await hashProgramPassword(password);
    const staffId = await db.transaction(async tx => {
      const [owner] = await tx.select({ staffId: staff.staffId }).from(staff)
        .innerJoin(adminSecurityOwners, eq(adminSecurityOwners.staffId, staff.staffId))
        .where(and(sql`LOWER(${staff.adminLoginId}) = ${loginId}`,
          isNull(staff.securityPasswordHash), eq(staff.isActive, 1), eq(staff.adminEnabled, 1),
          isNull(staff.terminatedAt), ne(staff.staffCode, "000"), eq(staff.role, "OWNER")))
        .limit(1).for("update");
      if (!owner) return null;
      await tx.update(staff).set({ securityPasswordHash: passwordHash, updatedAt: new Date() })
        .where(and(eq(staff.staffId, owner.staffId), isNull(staff.securityPasswordHash)));
      await tx.insert(auditLogs).values({ staffId: owner.staffId,
        actionType: "MASTER_PASSWORD_REGISTERED", entityType: "STAFF", entityId: owner.staffId });
      return owner.staffId;
    });
    if (!staffId) {
      const allowed = await recordAdminAuthFailure(scope, loginId, ip);
      return NextResponse.json({ success: false, message: allowed ?
        "최초 등록 대상 계정을 확인해 주세요." : "시도 횟수가 많습니다. 15분 후 다시 시도해 주세요." },
      { status: allowed ? 409 : 429, headers: noStore });
    }
    await clearAdminAuthFailures(scope, loginId, ip);
    return NextResponse.json({ success: true }, { headers: noStore });
  } catch (error) {
    const detail = error as { code?: string; cause?: { code?: string } };
    console.error("Initial master password registration failed", { code: detail.code ?? detail.cause?.code });
    return NextResponse.json({ success: false, message: "마스터 비밀번호를 등록하지 못했습니다." },
      { status: 503, headers: noStore });
  }
}
