import "server-only";

/** Set only by server.cjs for an actual local socket while NAS setup mode is enabled. */
export function isNasOwnerSetupRequest(request: Request) {
  return process.env.TDK_NAS_OWNER_SETUP === "1" &&
    request.headers.get("x-tdk-nas-owner-setup") === "1";
}

export function isNasOwnerSetupWrite(request: Request) {
  if (!isNasOwnerSetupRequest(request)) return false;
  const origin = request.headers.get("origin");
  const host = request.headers.get("host");
  if (!origin || !host) return false;
  try {
    const url = new URL(origin);
    return (url.protocol === "http:" || url.protocol === "https:") &&
      url.host.toLowerCase() === host.toLowerCase();
  } catch { return false; }
}
