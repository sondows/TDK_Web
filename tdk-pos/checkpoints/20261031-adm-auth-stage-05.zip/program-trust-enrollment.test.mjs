import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { resolve } from "node:path";
import test from "node:test";
import { runInNewContext } from "node:vm";
import ts from "typescript";

const nativeRequire = createRequire(import.meta.url);
const source = readFileSync(resolve(import.meta.dirname, "program-trust-routes.ts"), "utf8");
const code = ts.transpileModule(source, { compilerOptions: {
  module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022,
} }).outputText;
const staff = { staffId: "staff_id", securityPasswordHash: "security_password_hash",
  employeePinHash: "employee_pin_hash", adminLoginId: "admin_login_id", isActive: "is_active",
  terminatedAt: "terminated_at", staffCode: "staff_code", kdsEnabled: "kds_enabled" };
const schema = { staff, programTrustTokens: { tokenId: "token_id" },
  auditLogs: { name: "audit_logs" }, staffSessions: { name: "staff_sessions" } };
const issuedCookies = [];
const candidate = { staffId: 7, hash: "stored-hash", pinHash: "already-set" };
const tx = { insert: () => ({ values: async () => [{ insertId: 42 }] }) };
const db = {
  select() { return { from() { return this; }, where() { return this; }, limit: async () => [candidate] }; },
  transaction: callback => callback(tx),
};
const NextResponse = { json(body, options = {}) {
  return { status: options.status ?? 200, body,
    cookies: { set: (...args) => issuedCookies.push(args) } };
} };
const loaded = { exports: {} };
runInNewContext(code, {
  module: loaded, exports: loaded.exports, Request, URL, Date, console,
  require: name => name === "server-only" ? {} :
    name === "drizzle-orm" ? { and: () => ({}), eq: () => ({}), isNull: () => ({}),
      ne: () => ({}), sql: () => ({}) } :
      name === "next/server" ? { NextResponse } :
        name === "next/headers" ? { cookies: async () => ({ getAll: () => [] }) } :
          name === "@/db" ? { db } :
            name === "@/db/schema" ? schema :
              name === "@/lib/auth" ? { verifySecurityPassword: async (password) => password === "Valid#12345" } :
                name === "@/lib/admin-auth-limit" ? {
                  isAdminAuthAttemptAllowed: async () => true,
                  recordAdminAuthFailure: async () => true,
                  clearAdminAuthFailures: async () => {},
                } :
                  name === "@/lib/kds-device" ? { isHttpsSameOriginRequest: () => true } :
                    name === "@/lib/kds-network-server" ? { getKdsRateLimitIp: async () => null } :
                      name === "@/lib/program-trust-client-label" ? { programTrustClientLabel: () => "Test browser" } :
                        name === "@/lib/program-trust" ? {
                          isSecureTrustRequest: () => true,
                          programPermission: () => staff.kdsEnabled,
                          newProgramTrustToken: () => "random-test-token",
                          hashProgramTrustToken: () => "token-hash",
                          tokenCookieName: () => "tdk_kds_trust_42",
                          trustCookieOptions: { httpOnly: true, secure: true },
                        } : nativeRequire(name),
});

const request = password => new Request("https://tdkon.myasustor.com/api/kitchen/auth/trust", {
  method: "POST", headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ loginId: "employee7", password }),
});

test("first enrollment accepts ID and password without a network-dependent PIN", async () => {
  const wrong = await loaded.exports.enrollProgramTrust(request("Incorrect#12345"), "KDS");
  assert.equal(wrong.status, 401);
  assert.equal(issuedCookies.length, 0);
  const valid = await loaded.exports.enrollProgramTrust(request("Valid#12345"), "KDS");
  assert.equal(valid.status, 200);
  assert.equal(valid.body.pinSetupRequired, false);
  assert.equal(issuedCookies.length, 1);
  assert.equal(issuedCookies[0][0], "tdk_kds_trust_42");
});
