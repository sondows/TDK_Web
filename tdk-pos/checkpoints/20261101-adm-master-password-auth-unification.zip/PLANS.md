# TDKON 단계별 개발 계획

## 사용법과 상태 기준

새 개발 목표를 받으면 현재 코드와 DB 의존성을 먼저 분석하고 이 표를 목표에 맞게 갱신한다. 각 단계에는 코드 분석, 최소 수정, 관련 테스트, 결과 확인을 순서대로 기록한다. `PASS`는 실제 검증 결과와 복구 지점을 남긴 경우에만 부여한다. 문제가 나면 해당 단계에서 원인을 수정하고 다시 검증한다. 같은 문제가 두 번 반복되면 다음 기능 단계로 넘어가지 않고 실행 코드·DB·API·화면·인증 로직·환경·배포 상태를 확인한다.

현재 목표: ADM 최초 인증 문제를 해결하고 POS·ADM·KDS 인증 흐름을 순차적으로 검증한다. HOS는 향후 개발 대상이다. 운영 DB `TDK_POS`의 변경, 인증 보안 정책 변경, 대규모 삭제, 운영 배포는 사용자 승인 후 진행한다. 개발 DB는 `TDK_POS_TEST`이다.

## 현재 기준선

- 2026-10-30: 기존 작업 트리에 프로그램 신뢰 토큰·마스터 비밀번호 복구 관련 수정 및 미추적 파일이 다수 존재한다. 이 코드는 단계별 검증 기록이 없어 완료로 간주하지 않는다.
- 앞선 점검에서 프로덕션 빌드와 TypeScript 검사는 통과했다. 변경 파일 대상 ESLint는 통과했으며, 전체 소스 ESLint에는 기존 파일의 오류가 남아 있다. 이 결과는 아래 개별 단계의 `PASS` 근거가 아니다.
- 인증 흐름과 DB 전환 설명은 `docs/program-trust-rollout.md`에 있다. 운영 DB와 NAS 배포는 진행하지 않았다.

## ADM 최초 인증 단계

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 ADM 계정 및 마스터 비밀번호 상태 확인 | `scripts/check-owner-first-auth-test.cjs`, `TDK_POS_TEST` 읽기 전용 조회, 계획 기록 | 개발 DB 연결 및 계정 식별 | 조회 결과와 이후 복구 분기 | 대상 계정·최고관리자 권한·비밀번호 해시·PIN·잠금·복구 권한 상태를 확인하고 결과 기록 | 읽기 전용 스크립트 실행 및 조회 항목 확인 | PASS |
| 2 | ID 입력과 서버 상태 조회 연결 | `ProgramTrustGate.tsx`, ADM 신뢰·복구 상태 API | 1 PASS | ADM 최초 인증 화면·API | ID 입력 후 서버 상태가 의도된 화면 전환에 반영되고 계정 정보가 무단 노출되지 않음 | 관련 상태 전환 단위 테스트와 개발 환경 API 확인 | PASS |
| 3 | 마스터 비밀번호 미등록 시 등록 버튼 표시 | `ProgramTrustGate.tsx`, 복구 상태 API | 2 PASS | ADM 화면 분기 | 유효한 복구 권한이 있을 때만 등록 버튼이 표시됨 | 유효·만료·부재 복구 권한 화면/API 테스트 | PASS |
| 4 | 마스터 비밀번호 등록 및 저장 | 복구 등록 API, `staff` 해시, 개발 DB 스키마 | 3 PASS, 개발 DB 스키마 확인 | 최고관리자 인증 정보·기존 세션 | 유효한 권한으로 해시가 저장되고 권한이 일회용으로 소비되며 세션이 무효화됨 | 개발 DB 통합 테스트, 재사용·만료·실패 경로 확인 | PASS |
| 5 | ID + 마스터 비밀번호 인증 | ADM 신뢰 등록 API, 비밀번호 검증 로직 | 4 PASS | ADM 최초 인증·시도 제한 | 올바른 자격만 통과하고 오류·잠금 정책이 유지됨 | 성공·실패·잠금 테스트와 개발 환경 API 확인 | PASS |
| 6 | 프로그램별 보안토큰 발급 및 검증 | 신뢰 토큰 API·쿠키·DB·호스트 접근 검사 | 5 PASS | POS·ADM·KDS 신뢰 상태 | 토큰이 프로그램별로 분리되고 서버 검증·폐기가 작동함 | 토큰 발급·교차 사용 거절·폐기 테스트 | PASS |
| 7 | 개인 PIN 등록 또는 기존 PIN 인증 | PIN API, 개인 PIN 정책, 로그인 화면 | 6 PASS | 직원 PIN·업무 화면 진입 | 새 PIN 등록 또는 기존 PIN 확인 후에만 세션이 생성됨 | PIN 등록·오입력·재시도·세션 생성 테스트 | PASS |
| 8 | 재접속 시 토큰 + PIN 로그인 | POS·ADM·KDS 로그인 API·화면 | 7 PASS | 재접속 인증 | 유효 토큰에 개인 PIN을 요구하고 무효 토큰은 최초 인증으로 돌아감 | 재접속·쿠키 만료·토큰 폐기 테스트 | PASS |
| 9 | 퇴사·프로그램 권한 변경 시 인증 무효화 | 직원 변경·퇴사 API, 토큰·세션 조회 | 8 PASS | 직원 권한·기존 세션 | 퇴사 또는 권한 해제 직후 해당 토큰과 세션이 거절됨 | 퇴사·비활성화·권한 해제 통합 테스트 | PASS |
| 10 | POS·ADM·KDS 통합 회귀 검증 | 관련 API·화면·테스트, 배포 준비 기록 | 1~9 PASS | 세 프로그램 인증 및 기존 기능 | 개발 환경에서 전체 흐름과 기존 정상 기능을 확인하고 결과·DB 변경·배포 필요 여부 기록 | 관련 테스트 모음, 빌드, 개발 환경 시나리오 점검 | PASS |

## 단계 기록

### 1단계 — PASS

- 분석: 기존 `check-owner-first-auth-test.cjs`는 `DB_NAME=TDK_POS_TEST`를 강제하고 `sondows` 계정의 권한·마스터 비밀번호 해시 존재 여부·PIN·로그인 잠금·복구 권한 수만 읽기 전용으로 조회한다.
- 검증: `node scripts/check-owner-first-auth-test.cjs` 실행 성공. `TDK_POS_TEST`에서 `sondows`는 단일 행(`staff_id=1`)이며 활성 최고관리자이고 ADM 권한과 개인 PIN, 관리자 2차 비밀번호가 있다. 마스터 비밀번호 해시는 `NULL`, 로그인 잠금은 없고 활성 복구 권한은 0건이다. 만료 1건·폐기 3건이다. 해시나 토큰 값은 출력하지 않았다.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-01.md`에 읽기 전용 검증 결과와 다음 분기를 기록했다. 계정 및 운영 DB 데이터는 변경하지 않았다.

### 2단계 — PASS

- 분석: 기존 화면은 복구 링크의 서버 상태 조회 결과로 ID를 읽기 전용으로 채우고 즉시 등록 단계로 이동했다. 상태 API는 유효한 복구 권한과 일치하는 ID를 함께 검증한다.
- 수정: 복구 화면에서 ID 확인 단계를 추가하고, 제출한 ID와 복구 권한으로 상태 API를 다시 호출한다. 다른 ID·무효 권한은 다음 단계로 진행하지 않는다. API 요청·응답 처리는 `master-recovery-client.ts`에 둔다.
- 검증: 상태 전환과 클라이언트 API 계약 단위 테스트 5건 통과, 변경 파일 ESLint 및 TypeScript 통과. `TDK_POS_TEST` 스키마 확인 통과. `integration-master-recovery-test.cjs`는 유효·다른 ID·무효 권한의 API 응답을 확인하고 임시 계정 정리를 완료했다. 브라우저 클릭 경로는 10단계 통합 검증에서 다시 확인한다.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-02.md`에 수정 파일과 검증 결과를 기록했다.

### 3단계 — PASS

- 분석: 서버는 `passwordConfigured`를 반환하지만 기존 화면 버튼은 그 값을 사용하지 않았다. 만료 검증은 DB 현지 시각의 `DATETIME`을 앱 서버 시각과 비교해 약 9시간 어긋났다.
- 수정: ID 확인 응답의 비밀번호 상태에 따라 등록/재설정 버튼과 안내를 구분했다. 복구 상태 조회와 등록 API의 만료 판정을 DB `NOW()`로 통일했다. 상태 쿠키 유효기간도 DB의 남은 시간으로 계산한다.
- 검증: 관련 단위 테스트 6건, TypeScript, 변경 파일 ESLint 통과. 개발 DB 통합 검사에서 무효·다른 ID·만료 권한이 거절되고 유효 권한이 처리됐다. 헤드리스 Chrome에서 ID 확인, 미등록 계정의 등록 버튼, 만료 링크 차단, 기존 비밀번호 계정의 재설정 버튼을 확인했다.
- 오류 분석: 개발 DB의 복구 상태 조회 제한 키가 55회로 누적돼 429가 화면 검사를 가렸다. 테스트가 해당 키를 검사 동안 분리하고 원래 값으로 복원하도록 수정했다. 검사 후 55회 복원 확인.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-03.zip`에 이 단계의 코드·테스트·계획 스냅샷을 저장했다.

### 4단계 — PASS

- 분석: 복구 등록 API는 복구 권한을 잠근 트랜잭션 안에서 직원 해시·권한 사용 시각·토큰 폐기·세션 종료·감사 로그를 갱신한다. 개발 DB의 관련 스키마는 준비 상태다.
- 검증: `integration-master-recovery-test.cjs`에서 약한 비밀번호와 무효·만료·재사용 권한은 거절됐고, 거절 후 해시는 여전히 비어 있었다. 정상 등록 뒤 `scrypt$` 해시와 권한 사용 표식을 확인했다. 재설정 뒤 활성 토큰·세션이 각각 0건이었다. 임시 계정·권한 정리 완료.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-04.zip`에 이 단계의 복구 API·통합 검사·계획 파일을 저장한다.

### 5단계 — PASS

- 분석: ADM 최초 인증은 `enrollProgramTrust`에서 ID·마스터 비밀번호를 검증한다. 실패 횟수는 계정별/검증된 IP별로 기록하며 15분 동안 5회부터 잠근다.
- 검증: `TDK_POS_TEST` 임시 계정의 잘못된 비밀번호 1~4회는 401, 5회와 잠금 중 올바른 비밀번호는 429였다. 검사에서 저장된 실패 횟수 5회와 15분 이내 시각을 확인한 뒤 임시 계정·잠금 데이터를 정리했다. 관련 단위 테스트 1건 및 변경 파일 ESLint 통과.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-05.zip`에 이 단계의 인증 코드·통합 검사·계획 파일을 저장한다.

### 6단계 — PASS

- 분석: POS·ADM·KDS 토큰 쿠키 이름은 분리돼 있다. 서버는 토큰 해시·프로그램·직원 활성 상태·해당 권한·폐기 상태를 함께 확인하고, 폐기 시 연결된 세션을 종료한다.
- 검증: 호스트 접근·토큰·등록 단위 테스트 11건 통과. `integration-program-trust-test.cjs`에서 세 프로그램의 잘못된 비밀번호 401, 정상 발급 200, 타 프로그램 토큰 사용 거절, PIN 로그인 200, 토큰 폐기 뒤 페이지/API·세션 차단을 확인했다. 임시 직원 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-06.zip`에 관련 코드·계획을 저장한다.

### 7단계 — PASS

- 분석: 신규 PIN은 프로그램 신뢰 토큰을 먼저 검증한 뒤 저장한다. 마스터 비밀번호 없이 최초 PIN을 등록할 수 있는 시간은 토큰 발급 후 10분이며, 기존 PIN 변경에는 재인증이 필요하다. 기존 코드의 10분 판정은 DB `DATETIME`과 앱 시각을 섞어 사용했다.
- 수정: 최초 PIN 허용 시간을 DB `NOW()` 기준으로 계산하고 트랜잭션 안에서도 다시 확인한다. 개발 DB 통합 검사에 11분 지난 토큰의 재인증 요구를 추가했다.
- 검증: PIN 정책·인증 상태 테스트 4건, TypeScript, 변경 파일 ESLint 통과. POS·ADM·KDS 각각 신규 PIN 등록 후 로그인 200과 잘못된 PIN 401을 확인했다. ADM에서 11분 지난 토큰의 무비밀번호 등록 403, 마스터 비밀번호 재인증 후 등록 200을 확인했다. 모든 임시 직원 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-07.zip`에 PIN API·통합 검사·계획을 저장한다.

### 8단계 — PASS

- 분석: 로그아웃은 직원 세션만 종료하고 프로그램 신뢰 토큰은 유지한다. PIN 로그인 API는 해당 프로그램의 유효 토큰을 먼저 확인한다.
- 검증: 인증 상태 단위 테스트 3건과 검사 스크립트 ESLint 통과. 개발 DB 임시 직원으로 POS·ADM·KDS 각각 로그아웃 뒤 토큰이 유지됨을 확인했다. 토큰 없는 PIN 로그인은 403, 유효 토큰+PIN 재접속은 200, 토큰 폐기 후 기존 세션·PIN 재로그인은 차단됐다. 임시 계정 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-08.zip`에 재접속 검사와 관련 코드를 저장한다.

### 9단계 — PASS

- 분석: 직원 수정 API는 해제한 프로그램의 토큰과 관련 세션을 폐기하고, 비활성화 시 모든 프로그램 접근을 끊는다. 퇴사 API는 모든 토큰·세션과 프로그램 권한을 종료한다. 두 API 모두 최고관리자 2차 인증을 요구한다.
- 검증: 직원 수정 단위 테스트 6건 및 새 통합 검사 ESLint 통과. `integration-staff-access-lifecycle-test.cjs`에서 2차 인증 없는 수정 428, 인증 후 KDS 권한 해제, 계정 비활성화, 퇴사 API의 토큰·세션·권한 차단을 개발 DB에서 확인했다. 임시 최고관리자와 직원 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-09.zip`에 관련 API·검사·계획을 저장한다.

### 10단계 — PASS

- 분석: 단계 1~9 변경의 통합 회귀, 개발 DB 상태, 빌드와 배포 필요 여부를 확인했다.
- 검증: 인증 관련 단위 테스트 51건, 변경 파일 ESLint, 프로덕션 빌드 및 TypeScript 검사가 통과했다. 개발 DB에서 마스터 복구, POS·ADM·KDS 토큰/PIN/재접속, 최고관리자 2차 인증을 거친 직원 권한 생애주기, 임시 비밀번호 교체를 실제 API로 검사했다. 헤드리스 Chrome에서 ADM 복구 화면의 ID 확인·등록·만료·재설정 분기를 검사했다. 각 통합 검사는 임시 데이터를 정리했다.
- DB 상태: 이 작업에서 마이그레이션을 적용하지 않았다. `TDK_POS_TEST`의 인증 스키마는 준비 상태이며 검증 후 기존 직원 4명, 활성 신뢰 토큰 0건이다. 기존 `sondows`의 마스터 비밀번호 해시는 여전히 `NULL`이고 활성 복구 권한은 0건이다. 운영 DB `TDK_POS`는 변경하지 않았다.
- 배포: 코드 변경을 실제 운영에 반영하려면 NAS 배포와 운영 DB 마이그레이션이 필요하다. 두 작업은 사용자 승인 후 진행한다. 기존 최고관리자의 실제 최초 인증은 본인의 일회용 복구 링크 사용과 비밀번호 등록 후 별도로 확인해야 한다.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-10.zip`에 최종 소스·마이그레이션·스크립트·계획 스냅샷을 저장한다.

## 실제 계정 수용 및 운영 전환

| 항목 | 현재 상태 | 다음 조건 |
| --- | --- | --- |
| 기존 `TDK_POS_TEST` 최고관리자 `sondows`의 직접 최초 인증 | BLOCKED | 본인이 15분 유효한 일회용 복구 링크에서 마스터 비밀번호를 등록하고 ADM 로그인·개인 PIN·2차 인증을 확인해야 한다. 현재 활성 링크는 없다. |
| 운영 DB `TDK_POS` 마이그레이션 및 NAS 배포 | BLOCKED | 사용자 승인과 운영 백업 확인이 필요하다. 승인 전에는 운영 데이터를 변경하지 않는다. |

전체 저장소의 기존 ESLint 오류는 이번 인증 변경과 별개로 남아 있다. 이번 변경 파일만 대상으로 한 ESLint는 통과했다. 빌드의 메뉴 이미지 저장 경로 경고 2건도 기존 파일에서 발생한다.

## ADM 로그인 ID 입력값 전달 재확인 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `sondows` 입력의 화면 상태·입력 이벤트·기존 API 전달 확인 | ADM 로그인 화면 및 기존 복구 상태 조회 경로의 진단, 필요 시 ID 전달 부분만 | 개발 서버 및 기존 코드 확인 | ADM ID 입력과 상태 조회 | 실제 브라우저 입력·Enter·자동입력 유사 이벤트·기존 API 요청과 응답을 구분해 기록 | 개발 서버 브라우저 검사, 관련 단위 테스트, 서버 라우트 확인 | PASS |

이 단계에서는 마스터 비밀번호, PIN, 토큰, 권한, DB 구조, 인증 정책, POS·KDS 기능을 수정하지 않는다. 유효한 복구 권한이 없는 일반 로그인에서 계정 상태가 노출되지 않는 기존 정책은 유지한다.

### 1단계 — PASS: 진단 완료

- `src/components/ProgramTrustGate.tsx`의 ID 입력은 `value={loginId}`와 `onChange`의 `setLoginId(event.target.value)`로 연결된다. 앱 전용 `onBlur` 처리기는 없으며, 포커스 해제로 계정 조회를 시작하지 않는다.
- 개발 서버의 실제 `/tdkadm/login`에서 `sondows`를 입력한 뒤 화면 값과 React 렌더 속성 값이 모두 `sondows`임을 확인했다. 브라우저 이벤트는 `input` 3회, `change` 1회, `blur` 1회, Enter 1회였다. 포커스 해제와 Enter 후에도 ID가 유지됐다. 자동완성에 준하는 native setter + `input` 이벤트 후에도 두 값이 일치했다. 브라우저에 저장된 자격 증명의 실제 자동완성은 재현하지 않았다.
- 일반 ADM 로그인은 최초 로딩에 `GET /api/admin-center/trust`, `GET /api/admin-center/trust/initialize`를 호출한다. 이 요청은 ID를 포함하지 않는다. ID 입력·포커스 해제·비밀번호 없는 Enter 중 계정 상태 `POST` 호출은 없었다. 따라서 일반 화면에서 ID만 입력해도 계정 상태가 반영될 것이라는 기대는 현재 코드와 다르다.
- 기존 `POST /api/program-trust/master-recovery/status`는 유효한 일회용 복구 링크가 있을 때 `계정 상태 확인` 제출로만 호출된다. `master-recovery-client.test.mjs` 3건 통과: `sondows`를 요청 본문에 담는 동작, 다른 ID·권한 부재 응답 거절, 응답에 따른 분기를 확인했다. 서버 라우트는 본문 ID를 읽어 유효한 복구 권한과 계정을 함께 조회한다. 실제 `sondows` 계정의 유효한 복구 권한이 없어 이번 진단에서 해당 계정에 대한 서버 상태 응답은 검증하지 않았다.
- 수정: 진단 전용 `scripts/check-adm-id-input-test.cjs`와 이 계획 기록만 추가했다. 인증 코드와 DB 구조·데이터는 변경하지 않았다. 진단 스크립트 ESLint 통과. 운영 로그는 추가하지 않았다.
- 체크포인트: `checkpoints/20261031-adm-id-input-stage-01.zip`.

## ADM 마스터 비밀번호 최초 등록 및 화면 복귀 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | NAS 승인 권한으로 해시 미등록 계정의 마스터 비밀번호만 저장하고 최초 인증 화면으로 복귀 | ADM `ProgramTrustGate`, 전용 최초 등록 API, 격리 DB 브라우저/API 테스트 | ADM ID 전달 진단 PASS, 기존 복구 권한/해시 저장 방식 확인 | ADM 승인된 최초 등록 분기만 | 승인 없는 등록 거절, 해시 NULL 계정에만 scrypt 해시 저장, PIN·권한·세션·토큰 보존, 브라우저에서 지정 화면 복귀 | `TDK_POS_TEST` 임시 계정으로 API·DB·Chrome 검증 | PASS |

작업 제한: 실제 `sondows` 자격 증명 변경 금지. 운영 DB `TDK_POS`와 DB 구조 변경 금지. 최초 등록 API는 기존 비밀번호 재설정 API와 분리하고 세션·토큰·PIN을 변경하지 않는다. 성공 후에는 로그인이나 다음 인증 단계를 실행하지 않는다.

### 1단계 — PASS

- 분석: 기존 NAS 발급 복구 링크는 직원 계정과 일회용 권한을 묶고, 상태 조회는 ID와 비밀번호 해시 등록 여부를 확인한다. 기존 비밀번호 재설정 API는 세션·신뢰 토큰까지 폐기하므로 최초 등록에서는 재사용하지 않는다. `/api/admin-center/trust/initialize`는 기존 직원이 없는 신규 설치 전용이라 `sondows`에 적용할 수 없다.
- 권한: 기존 `TDK_POS_TEST`의 `sondows`는 활성 최고관리자이고 별도 소유자 2차 인증 상태는 `ACTIVE`지만 `security_password_hash`는 `NULL`이다. 현재 활성 NAS 복구 권한은 0건이다. 따라서 실제 계정 비밀번호는 설정하지 않았으며, 테스트에서는 NAS 발급 권한을 모사한 일회용 grant를 임시 계정에만 발급했다.
- 구현: ID blur 또는 Enter에서 기존 상태 API를 호출한다. NAS 승인 grant와 ID가 일치하고 마스터 해시가 없으면 `마스터 비밀번호 등록` 창을 자동으로 연다. 별도 `register-initial` API가 서버에서도 grant 유효성·계정 연결·해시 NULL을 재검증한 뒤 `scrypt` 해시를 `staff.security_password_hash`에 최초 한 번만 저장하고 grant를 소비한다. 해시가 이미 있거나 승인 토큰이 없으면 등록을 거절한다. 입력창은 길이·영문·숫자·특수문자·일치 조건을 화면과 서버 양쪽에서 검사한다.
- 완료 화면: 성공 시 등록창을 닫고 복구 URL 상태를 지운 뒤 동일 ID, 빈 마스터 비밀번호 입력창, `인증` 버튼으로 돌아온다. 인증 API, PIN, 토큰, 세션은 호출·발급하지 않는다.
- 검증: `check-adm-initial-master-registration-test.cjs`가 `TDK_POS_TEST` 임시 최고관리자와 실제 Chrome에서 blur·Enter 양쪽의 창 전환, 약한/불일치 비밀번호 차단, 승인 없는 요청 거절, 상태 및 등록 API 응답 200, 해시 저장, grant 재사용 거절, ID 유지·빈 비밀번호·`인증` 표시를 확인했다. 임시 계정은 cleanup 완료했다. 테스트 행은 기존 PIN 센티널과 ACTIVE 소유자 2차 인증 정보를 그대로 보존했으며 토큰·세션은 생성되지 않았다. 인증 관련 단위 테스트 12건, 변경 파일 ESLint, TypeScript 검사 모두 통과했다.
- DB/배포: 테이블 구조 및 운영 DB `TDK_POS`를 변경하지 않았다. 테스트는 격리된 `TDK_POS_TEST` 임시 행만 사용 후 삭제했다. 실제 `sondows` 화면 등록은 NAS 관리자가 15분 일회용 권한을 발급한 뒤 별도 수행해야 한다. 이 단계에서 실제 로그인·PIN·토큰 단계로 진행하지 않았다.
- 체크포인트: `checkpoints/20261031-adm-master-password-initial-stage-01.zip`.

## 개발 서버 HMR 404 및 수정 반영 재확인 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Next.js 개발 서버 HMR 연결·자동 반영을 확인하고 실행 상태를 재시작 | `server.cjs`, Next 설정·Proxy, HMR 진단 스크립트, 계획 기록 | 현재 3000 포트 서버 식별 | 개발 서버와 ADM 화면 갱신 | 개발 모드·올바른 프로젝트 경로·WebSocket 101·실제 소스 자동 반영·일반 새로고침·POS/ADM/KDS 경로 확인 | 재시작 전후 Chrome CDP와 임시 문구 변경 및 복구 | PASS |

### 1단계 — PASS

- 조사: `npm run dev`는 `node server.cjs`를 실행하며 `NODE_ENV`가 production이 아닐 때 `next({dev:true})`로 동작한다. 설치 버전은 Next.js 16.3.5, Turbopack이다. `getRequestHandler()`가 첫 요청의 Node HTTP 서버에서 Next 업그레이드 핸들러를 등록한다. `src/proxy.ts`와 인증 분기는 일반 HTTP 요청에 적용되며 정상 HMR WebSocket 업그레이드를 차단하지 않는다.
- 원인: 유효한 HMR은 `GET /_next/hmr?id=...` 형태의 WebSocket Upgrade이고 응답 `101`이 정상이다. Upgrade 헤더 없이 같은 경로를 일반 HTTP GET으로 요청하면 `404`가 반환된다. 재시작 직후 개발 로그에는 진단용 새 Chrome과 별개인 HMR `GET` 404가 한 차례 있었지만, 해당 요청 헤더와 출처는 수집하지 않아 오래된 세션 ID인지 비 Upgrade 요청인지 구분할 수 없었다. 진단용 새 Chrome의 WebSocket은 `101`을 받았고 HTTP 응답 404는 없었다. 서버 설정 오류는 재현되지 않았다. 기존 브라우저 탭에서 오류가 남으면 새로고침해 새 HMR 연결을 만든다.
- 경로: 포트 3000 소유 트리는 `npm run dev` → `node server.cjs`였고, Next가 시작 로그에서 현재 `D:\10_프로그래밍_소스\01_TDK_Web\tdk-pos`를 사용함을 확인했다. 실제 파일을 임시 변경해 브라우저 화면에서 읽어들인 것으로 소스·서버 경로가 일치함도 검증했다. 재시작 전후 임시 문구를 복구했다.
- 캐시/PWA: 프로젝트에 Service Worker 등록 코드나 서비스 워커 파일이 없다. 새 Chrome 프로필에서 localhost 서비스 워커 0개, Cache Storage 키 0개를 확인했다. 기존 사용자 프로필의 잔존 SW는 직접 접근하지 않았으며 이번 새 브라우저 검증에서는 PWA 캐시 영향이 없었다.
- 재시작 및 검증: 기존 터미널 세션에 연결할 수 없어 Ctrl-C와 비강제 종료를 시도했으나 종료되지 않았다. 포트 소유 트리를 재확인한 뒤 해당 개발 서버 프로세스만 종료하고 `npm run dev`를 다시 실행했다. 새 서버는 현재 실행 중이다. Chrome에서 `http://localhost:3000` 및 허용된 `http://192.168.0.54:3000` 모두 HMR 연결 101, 임시 텍스트의 자동 재컴파일·화면 반영, 원문 복구, 일반 새로고침 최신 화면 표시를 확인했다. Next 로그에 `Compiled in 2.5–2.8s`가 기록됐다. `/tdkadm/login`, `/tdkpos/login`, `/tdkkds`는 HTTP 200이었다.
- 변경/DB/운영: 런타임 서버·Proxy·인증 코드는 변경하지 않았다. `scripts/check-dev-hmr-test.cjs`는 임시 소스 문구를 자동 복구하는 개발 진단용으로 추가했다. `.next` 캐시를 삭제하지 않았고 DB·운영 빌드·Docker·NAS는 건드리지 않았다.
- 체크포인트: `checkpoints/20261031-dev-hmr-stage-01.zip`.

## ADM 최초 마스터 비밀번호 등록 흐름 단순화 — 2026-10-31

이 단계는 사용자의 최신 지시가 기존의 일회용 복구 링크 기반 최초 등록 정책을 대체한다. 별도 비밀번호 재설정용 복구 링크는 유지한다.

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 최초 설치·복구 경로와 개발 DB 계정 상태 분석 | 초기화 API, 복구 API, ADM 화면, `TDK_POS_TEST` | 기존 코드와 개발 DB 읽기 | ADM 최초 등록 | `sondows` 해시 NULL 및 기존 권한·PIN 상태 확인 | 읽기 전용 `check-owner-first-auth-test.cjs` | PASS |
| 2 | NAS 로컬 초기 설정 경계 구현 | `kds-ingress.cjs`, `nas-owner-setup.ts`, 외부 Host 접근 정책 | 1 PASS | 최초 등록 API | 모드 미설정·LAN·외부 Host·위조 헤더 차단 | 입구 단위 테스트와 실제 HTTP Host 요청 | PASS |
| 3 | 최초 설치와 기존 최고관리자 NULL 해시 등록 | 초기화 API, 상태 API, 최초 등록 API | 2 PASS | 최고관리자 최초 비밀번호 | 1회 완료 표식, NULL 해시에만 해시 저장, 기존 PIN·권한 유지 | 최초 설치 API 단위 테스트, 개발 DB 격리 계정 통합 테스트 | PASS |
| 4 | ADM 등록창 및 인증 화면 복귀 | `ProgramTrustGate.tsx`, 인증 단계 흐름 | 3 PASS | ADM 로그인 화면 | ID blur·등록창·저장·ID 유지·빈 비밀번호·인증 버튼 | 실제 Chrome, `sondows` 읽기 전용 등록창과 격리 계정 저장 | PASS |
| 5 | 회귀 검증·운영 절차·복구 지점 | 관련 테스트, 문서, 체크포인트 | 4 PASS | 배포 전 검증 | 일반 모드 차단, 경로 200, 문서와 결과 기록 | TypeScript·ESLint·단위 테스트·일반 서버 API | PASS |

검증 결과: `TDK_POS_TEST`의 실제 `sondows`는 테스트 전후 모두 활성 최고관리자이며 `security_password_hash=NULL`, PIN·소유자 2차 인증 상태 유지. NAS 로컬 설정 모드에서 `sondows` ID의 blur와 Enter 후 실제 Chrome 등록창 표시를 확인했으며 비밀번호는 입력하거나 변경하지 않았다. 격리 계정에서는 실제 Chrome 등록·해시 저장·재등록 409·권한과 PIN 유지·ID 유지 및 빈 비밀번호와 `인증` 버튼 복귀를 확인하고 임시 행을 정리했다. 외부 Host는 403, 모드 종료 후 로컬 상태·등록 API도 403이다. 관련 단위 테스트 18건, TypeScript, ESLint 통과. 일반 모드에서 ADM·POS·KDS 경로는 모두 HTTP 200.

최초 설치 분기: 서버 1회 완료 표식과 중복 차단은 단위 테스트 통과. Chrome에서는 초기 설치 가능 API 응답을 모의해 ID·마스터 비밀번호·확인 입력 화면을 확인했다. 실제 빈 DB를 이용한 최초 최고관리자 생성은 기존 개발 데이터 보존 때문에 미검증이다. 운영 DB `TDK_POS`, DB 테이블 구조, 실제 `sondows` 비밀번호, PIN·토큰·세션, NAS 운영 배포는 변경하지 않았다.

복구 지점: `checkpoints/20261031-adm-nas-initial-setup.zip`에 이 단계에서 수정한 코드·테스트·문서·계획을 저장했다.

## ADM ID 입력 후 계정 상태 조회 루틴 점검 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 입력·조회·접근 제어와 개발 DB 상태 확인 | `ProgramTrustGate.tsx`, 기존 상태 API, `TDK_POS_TEST` | 이전 최초 등록 단계 PASS | ADM 최초 인증 화면 | 일반 모드와 NAS 설정 모드의 응답 차이, `sondows`·토큰 상태 확인 | 코드 추적·읽기 전용 DB/API·Chrome 요청 기록 | PASS |
| 2 | 누락된 입력값 확정 연결만 수정 | ADM ID 입력 이벤트 | 1 PASS | ADM ID 자동완성·초기값 | DOM 값과 React 상태를 일치시키고 최신 ID만 반영 | Chrome 입력·자동완성·연속 변경 | PASS |
| 3 | 실제 브라우저 및 회귀 검증 | Chrome, TypeScript, ESLint | 2 PASS | ADM 화면 | 조회 요청·응답·화면 상태와 일반 모드 차단 확인 | Chrome CDP·관련 정적 검사 | PASS |

운영 DB `TDK_POS`, 개발 DB의 계정·비밀번호·PIN·보안토큰 데이터와 스키마, 마스터 비밀번호 등록·PIN·보안토큰 발급 로직은 변경하지 않는다. 기존 상태 조회 API의 시도 제한 기록은 요청에 따라 증가한다.

- 원인: 일반 입력의 `onChange`·`onBlur`·Enter와 기존 상태 조회 POST는 실행됐다. 일반 개발 서버는 `TDK_NAS_OWNER_SETUP` 미설정이어서 `POST /api/admin-center/trust/initial-master/status`에 403/`available:false`를 반환하므로 화면 변경이 없는 것은 기존 접근 제어의 결과다. 자동완성으로 DOM에만 ID가 채워지고 `onChange`가 없으면 기존 함수가 빈 React 상태를 읽어 조회를 생략하는 누락도 있었다.
- 수정: ADM ID 확정 시 실제 입력 DOM 값을 React 상태와 기존 조회 함수에 전달하고, 화면이 처음 나타날 때 미리 입력된 DOM 값을 확인한다. 동일 ID 중복 조회를 억제하며 ID 변경·로그인 진행 시 이전 응답을 무시한다. 새 API와 등록 권한은 추가하지 않았다.
- 개발 DB 읽기 전용 확인: `sondows`는 활성 OWNER·ADM 허용·해시 NULL이며 최초 설치 완료 표식은 이미 완료 상태다. `sondows`의 ADM 토큰 행은 0건, 새 Chrome 프로필의 신뢰 토큰 상태는 `trusted:false`였다. 테스트 전후 해시·PIN·2차 인증 상태는 유지됐다.
- 실제 Chrome 일반 모드: `sondows` 입력·blur·Enter, 다른 ID로 변경, DOM 값만 채운 초기 자동 입력에서 상태 조회 요청을 확인했다. 요청 ID·서버 403/`available:false`·React 표시값 일치·등록창 미표시를 확인했다.
- 실제 Chrome NAS 설정 모드: `sondows` 요청의 200/`available:true`와 등록창 표시를 확인했다. 이후 개발 DB의 기존 15분 상태 조회 제한 버킷이 31회가 되어 다음 요청은 429였다. 제한 행을 삭제하거나 초기화하지 않았다.
- Chrome 모의 API 응답: 200/`available:true`·200/`available:false`로 ID 재조회, 초기 자동 입력, 늦게 도착한 이전 ID 응답 무시를 확인했다. 이 세부 동작의 연속 실서버 재검증은 429 때문에 미실시다.
- TypeScript, 변경 파일 ESLint, 브라우저 테스트 통과. NAS 설정 모드를 종료한 일반 개발 서버에서 상태 API 403과 `trusted:false`를 재확인했다. 복구 지점: `checkpoints/20261031-adm-id-status-stage-01.zip`.

## ADM ID → 다음 로그인 화면 전환 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 ID·토큰·등록 상태 API 분석 | ProgramTrustGate, trust/status, initialize, initial-master/status | 이전 ID 조회 단계 PASS | ADM 최초 인증 화면 | 기존 API로 PIN·비밀번호·등록 화면을 분기할 수 있음 | 코드 추적·읽기 전용 개발 DB 조회 | IN_PROGRESS |
| 2 | ID 입력 → 다음 버튼 → 기존 상태 API 연결 | ProgramTrustGate, ADM PIN 화면의 선택 ID 전달 | 1 PASS | ADM 화면 전환 | 자동 조회 제거, 중복 제출 방지, 오류·뒤로가기·ID 유지 | Chrome 및 기존 화면 회귀 | PASS |
| 3 | 조건별 전환 검증 및 기록 | ADM UI 단위·브라우저 검증, PLANS | 2 PASS | ADM 화면 | 토큰·비밀번호·등록 권한 분기 확인 | Chrome, 테스트 계정/모의 응답, TypeScript·ESLint | PASS |

마스터 비밀번호 저장·검증 API, PIN 인증 API, 토큰 발급, DB 스키마·기존 계정·권한은 이 단계에서 수정하지 않는다. 운영 DB `TDK_POS`는 변경하지 않는다.
## ADM 로그인 ID → 다음 화면 전환 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 상태 조회 API와 화면 흐름 확인 | ProgramTrustGate, 기존 trust/initialize/initial-master/status API | ID 상태 조회 단계 PASS | ADM 최초 인증 화면 | 기존 API와 권한 검증 유지 | 코드 추적 및 일반 모드 응답 확인 | PASS |
| 2 | ID 입력 후 다음 버튼에서만 상태 조회하고 결과별 화면 이동 | ProgramTrustGate, AdminLoginForm, program-auth-flow | 1 PASS | ADM 최초 인증 및 PIN 진입 화면 | 자동 조회 제거, 중복 요청 차단, ID 유지 및 뒤로가기 | Chrome에서 입력·요청·분기 검증 | PASS |
| 3 | 오류 및 접근 권한 차단 검증과 기록 | Chrome 검사 스크립트, PLANS | 2 PASS | ADM 로그인 화면 | 일반 모드 등록 거부, 실패 안내, 기존 계정 데이터 보존 | 실제 일반 모드 요청과 모의 상태별 응답을 구분해 확인 | PASS |

- ID 입력 중 onChange/onBlur 및 자동완성 동기화는 상태 조회를 호출하지 않는다. 다음 버튼 제출만 기존 상태 API 세 곳(trust, initialize, initial-master/status)을 호출한다. 요청 중 버튼을 비활성화하고 동기화 잠금도 적용한다.
- 상태에 따라 유효 토큰은 기존 PIN 화면, 토큰이 없으면 기존 마스터 비밀번호 화면, 서버가 허가한 최초 등록은 기존 등록창, 초기 설치는 기존 최고관리자 등록 화면으로 이동한다. 실패 시 ID 화면에 오류를 표시한다. 화면 뒤로가기와 PIN 진입 시 ID를 유지한다.
- 일반 개발 모드 Chrome 요청에서 ID `sondows`가 상태 API에 전달되고 최초 등록 상태 API가 403을 반환하며 비밀번호 화면으로 이동하는 것을 확인했다. 따라서 ID만으로 비밀번호 등록창이 열리지 않는다.
- Chrome headless CDP 검증에서 입력만으로 API가 호출되지 않는 점, 응답 대기 중 중복 요청 차단, 토큰/PIN 분기, 초기 설치 분기, 서버 허가 등록창 분기, 서버 오류 안내, ID 유지 및 뒤로가기를 확인했다. 이 분기들의 응답은 격리된 브라우저 요청 모의 응답으로 검증했으며, 실제 NAS 초기 설정 권한으로 DB를 변경하지 않았다.
- TypeScript `tsc --noEmit`, 변경 파일 ESLint, 검증 스크립트 `node --check`, Chrome 검증을 통과했다. API, DB 스키마/데이터, 운영 DB `TDK_POS`는 변경하지 않았다.
- 복구 체크포인트: `checkpoints/20261031-adm-id-next-stage-01.zip`.

## ADM ID 다음 이후 화면 분기 오분기 수정 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | TDK_POS_TEST 계정, bootstrap latch, 초기 설정 모드/API 상태 확인 | TDK_POS_TEST 및 기존 상태 API | ADM ID 다음 화면 기존 구현 | ADM 로그인 분기 | DB/API 응답을 읽기 전용으로 확인 | MySQL SELECT 및 실제 로컬 API 요청 | PASS |
| 2 | 등록 허용·비허용·비밀번호 등록 상태별 분기 수정 | 기존 initial-master/status API 응답, ProgramTrustGate | 1 PASS | ADM ID 다음 이후 화면 | 미등록·비허가 계정이 비밀번호 인증으로 오분기하지 않음 | TypeScript, ESLint, Chrome 분기 검사 | IN_PROGRESS |
| 3 | 실제 승인 초기 설정에서 sondows 등록 화면 검증 | 개발 서버, Chrome, TDK_POS_TEST | 2 구현 | ADM 최초 설정 화면 | 실제 API 200/available:true 및 등록창 표시 | Chrome에서 API와 화면을 함께 확인 | BLOCKED |

- 읽기 전용 DB 확인: TDK_POS_TEST에서 sondows 계정 존재, master hash NULL, OWNER, 활성, ADM 허용, 미퇴사, owner 레코드 존재. security_bootstrap_state.completed_at은 설정 완료 상태.
- 최초 설정 모드는 기본 서버에서 비활성. 일반 모드 실 API는 initial-master/status 403 available:false, initialize 200 available:false, trust 200 trusted:false를 반환했다. 기존 화면은 setup status 403을 정상 분기로 취급한 다음 무조건 LOGIN_PASSWORD로 이동한 것이 오분기 원인.
- 수정: 승인 모드 응답에서만 기존 상태 API가 계정 존재/비밀번호 설정 여부를 함께 반환하도록 하고, 유효 owner의 미등록 계정은 기존 등록창, 등록된 계정은 비밀번호 화면, 등록 권한이 없는 미등록 계정은 안내만 표시한다. setup status 403도 ID 화면의 권한 안내로 남긴다. 등록 API, PIN/토큰, DB 구조·데이터 변경 없음.
- 일반 모드 실제 Chrome에서는 403 뒤 등록 권한 안내가 표시되고 비밀번호 입력 화면으로 이동하지 않는 것까지 확인했다. 격리된 응답 모의로 다른 분기도 확인했으나 실제 모드 검증의 대체 PASS로 취급하지 않는다.
- 실제 승인 모드 검증을 위해 개발 서버를 로컬 설정 모드로 재시작했으나, 상태 API가 기존 DB 요청 제한으로 429를 반환했다. 카운터는 33회였으며 초기화·우회하지 않았다. 검증 후 서버를 일반 모드로 재시작했다. 실제 available:true 및 등록창 노출은 미검증이므로 전체 단계 완료/PASS로 표시하지 않는다.
- 검증: TypeScript, 변경 파일 ESLint, 검증 스크립트 구문 검사, 일반 모드 Chrome 검증 통과. 개발 DB/운영 DB 데이터는 변경하지 않았다.
- 복구 체크포인트: checkpoints/20261031-adm-id-next-branch-fix.zip.
- 정정: API 검증은 기존 admin_auth_attempts 상태 조회 제한 카운터를 정상 증가시켰다. 계정/비밀번호/최초 설정 데이터는 변경하지 않았으며 이 카운터를 초기화하거나 우회하지 않았다. 승인 모드 검증은 카운터 33회로 429가 반환되어 실제 등록 가능 응답까지 미완료다.

## ADM 최초 설정 차단 원인 및 Windows 개발 모드 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | NAS/DB/계정/초기화/API/요청 제한의 호출 순서와 차단 원인 확인 | ProgramTrustGate, setup status, initialize, ingress, auth limit | 이전 ID 분기 수정 | ADM 최초 등록만 | 계정 상태와 권한 정책, limiter 동작 확정 | 코드 추적 및 TDK_POS_TEST 읽기 전용 조회 | PASS |
| 2 | 최초 설정 계정 상태 판정 공통화, UI 분기 명확화 | 기존 status 및 register-initial API, 공통 정책 모듈, ProgramTrustGate | 1 PASS | ADM 최초 설정/인증 분기 | 최초 설치·비밀번호 미등록·등록됨·복구를 구분하고 권한 gate 유지 | 단위 테스트 및 typecheck | PASS |
| 3 | Windows 관리자용 TDK_POS_TEST 전용 개발 초기 설정 실행 절차 | Windows PowerShell 실행 스크립트, ingress attestation, 설정 문서 | 2 PASS | Windows 개발 환경 로컬 localhost만 | 상승된 관리자 토큰, 개발 모드, TDK_POS_TEST를 모두 확인; production 거부 | 스크립트 구문/비관리자 거부/ingress 단위 테스트 | IN_PROGRESS |
| 4 | 실제 Windows Chrome에서 sondows 등록창 표시 | dev 서버, Chrome, TDK_POS_TEST | 2·3 PASS 및 상태 조회 제한 해제 | ADM 최초 등록 화면 | 실제 DB 응답 available:true와 등록창 표시 | Chrome CDP 실제 API 확인, 비밀번호는 입력/저장하지 않음 | BLOCKED |

- 차단 원인: 일반 Windows npm run dev에는 NAS setup 플래그가 없어 기존 status API가 403을 반환했다. 이전 로컬 설정 모드 확인은 동일 IP 15분 상태조회 제한기에 걸려 429가 났다. DB의 admin_auth_attempts 해당 카운터는 기존 33회였으며 초기화/우회하지 않았다.
- TDK_POS_TEST 읽기 전용 조회에서는 sondows가 활성 OWNER/ADM 허용, 마스터 hash NULL, bootstrap latch 완료로 확인됐다. 그러므로 빈 DB 최초 관리자 분기가 아니라 기존 owner 비밀번호 미등록 분기가 적용되어야 한다.
- 최초 설정 상태 판단을 공통 분류 함수로 모으고 initialize GET/POST, 초기 마스터 상태 API 및 기존 초기 등록 write API가 같은 계정 판정 함수를 사용하게 했다. 복구 토큰 흐름은 별도로 유지했다.
- Windows 개발 절차는 관리자 토큰, NODE_ENV=development, DB_NAME=TDK_POS_TEST 조건을 검사한다. Node ingress는 localhost loopback 요청에만 내부 attestation을 붙이며, 브라우저 위조 헤더, LAN 요청, 운영 모드는 거부한다. NAS setup 경로는 유지했다.
- 검증: 일반 모드 실제 Chrome은 실 API 403 뒤 안내를 표시하고 마스터 비밀번호 인증 화면으로 이동하지 않았다. 분류 단위 테스트 2개, ingress 테스트 9개, TypeScript, ESLint, PowerShell 구문 검사를 통과했다. 비관리자 실행은 명시적으로 거부됐다.
- 현재 실행 환경의 Windows 관리자 토큰은 비상승 상태다. 따라서 안전 스크립트로 설정 모드를 시작할 수 없어 실제 설정 모드 DB 응답과 Chrome 등록창은 검증하지 못했다. 모의 응답 분기는 통과했지만 PASS로 계산하지 않는다. 등록창 검증 단계는 BLOCKED로 남기고, 사용자 비밀번호 입력/DB 저장은 수행하지 않았다.
- 운영 DB TDK_POS 및 계정/해시/PIN/권한/최초 설정 데이터 변경 없음. 복구 체크포인트: checkpoints/20261031-adm-windows-owner-setup.zip.
- 일반 Chrome 검증 후 이 작업에서 실행한 일반 모드 개발 서버를 종료해 3000 포트를 비웠다. 관리자 PowerShell에서 전용 스크립트를 바로 시작할 수 있다. 제한 카운터는 마지막 읽기 전용 조회 시 33회/984초 경과로 15분 창을 지난 상태였다.

## Windows 개발 초기 설정의 불필요한 상태조회 제한 분리 — 2026-11-01

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | ADM 진입 시 자동 호출 여부와 429 발생 조건 확인 | ProgramTrustGate, initial-master/status, admin-auth-limit | Windows 초기 설정 모드 지원 | ADM 최초 ID 다음 | 자동 호출 및 limiter 위치 확인 | 코드 추적, 기존 30회/15분 제한 동작 확인 | PASS |
| 2 | Windows 관리자·개발 DB·localhost 설정 흐름에 한해 상태조회 limiter 충돌 제거 | owner setup mode, initial-master/status | 1 PASS | Windows 개발 초기 등록 상태 조회 | local dev는 반복 조회 차단 오류 없음, NAS/일반 경로 limiter 유지 | 정책 단위 테스트, TypeScript, ESLint | PASS |
| 3 | 제한 이력 보존 및 결과 문서화 | PLANS, checkpoint | 2 PASS | 문서 | limiter 카운터 삭제/초기화 없이 검증 | 관련 테스트 및 코드 검사 | PASS |

- 실제 원인: ADM 첫 화면 진입 자체는 계정 상태 API를 호출하지 않는다. ID 입력 후 다음을 누를 때 initial-master/status가 호출된다. 상태 API는 승인된 설정 모드 요청마다 15분 IP 제한 카운터를 증가시키며 30회를 넘으면 429를 반환한다. 이전 조회 시 34회로 제한 창 안에 있었다.
- 수정: 인증 정책이나 카운터 기록을 지우지 않고, Windows 개발 전용 모드(NODE_ENV=development, DB_NAME=TDK_POS_TEST, TDK_WINDOWS_DEV_OWNER_SETUP=1)에서는 기존 loopback setup attestation 검사 이후에만 이 읽기 전용 상태조회 rate limit을 생략한다. NAS setup 및 다른 경로의 30회/15분 제한은 유지한다. 비밀번호 등록 write 실패 제한과 OWNER/hash NULL 검사도 그대로 유지.
- 기존 제한 카운터는 변경/삭제하지 않았다. production, 운영 DB, NAS 모드에서는 제한 로직이 유지됨을 정책 테스트로 확인.
- 검증: TypeScript, ESLint, 상태 정책 테스트 3건, ingress 보안 테스트 9건 통과. Chrome 실화면 검증은 이번 변경 범위에서 수행하지 않았다.
- 복구 체크포인트: checkpoints/20261101-adm-windows-status-limit.zip.

## 3000번 ADM 최초 설정 요청 제한 오류의 런타임 원인 — 2026-11-01

- 재현: 현재 `http://localhost:3000/api/admin-center/trust/initial-master/status`에 `sondows`를 1회 요청했고 HTTP 429, `{"available":false}`를 확인했다. DB·계정·마스터 비밀번호 저장 API는 호출하거나 변경하지 않았다.
- 코드 원인: 429는 기존 15분 요청 제한을 Windows 개발 설정 모드가 해제하지 못할 때 반환된다. 소스에는 개발 DB `TDK_POS_TEST`와 `TDK_WINDOWS_DEV_OWNER_SETUP=1`이 모두 설정된 경우 제한을 면제하는 로직이 있으며, 해당 정책 단위 테스트는 통과한다.
- 실행 원인: 현 요청이 429인 점으로 미루어 현재 응답 프로세스의 유효 런타임 환경은 Windows 설정 모드가 아니다. 실제로 포트 3000에 기존 PID 533464가 LISTENING 중이며, 프로세스 정보 조회는 권한 거부되어 어느 터미널에서 어떤 환경으로 시작됐는지는 확인할 수 없었다. 기존 프로세스가 일반 `npm run dev`로 시작된 상태에서 설정 스크립트 실행이 포트 충돌로 실패했거나, 브라우저가 그 서버에 계속 접속하는 상황이 root cause다. 제한 카운터나 초기 설정 latch를 지우지 않았다.
- 수정: `scripts/start-windows-owner-setup.ps1`는 기존 개발 서버를 종료하지 않고 첫 빈 포트(기본 3000, 현재처럼 점유 중이면 3001)를 선택해 전용 설정 서버를 띄운다. 시작 URL과 설정 모드/DB 이름을 출력한다. `server.cjs`도 개발 서버 시작 시 DB 이름과 Windows owner setup 활성 여부만 출력한다(비밀값 출력 없음).
- 검증: PowerShell 파서 PASS, `node --check server.cjs` PASS, TypeScript `tsc --noEmit` PASS, 변경 관련 ESLint PASS, `node --experimental-strip-types --test src/lib/initial-admin-setup.test.mjs` 3/3 PASS. 직접 브라우저 설정 모드의 등록 화면 검증은 현재 서버 프로세스를 재시작하지 못해 BLOCKED이며 PASS 처리하지 않는다.
- DB 변경 없음. 운영 DB `TDK_POS` 변경 없음. 테스트용 비밀번호 저장 없음.
- 다음 재개 시: 관리자 PowerShell에서 기존 3000 개발 서버를 실행한 터미널에서 Ctrl+C로 종료하고, `Set-Location 'D:\10_프로그래밍_소스\01_TDK_Web\tdk-pos'; .\scripts\start-windows-owner-setup.ps1` 실행. 서버 시작 시 `DB_NAME=TDK_POS_TEST, Windows owner setup=enabled`를 확인하고 브라우저에서 `http://localhost:3000/tdkadm` 새로고침 후 `sondows` 조회 결과를 확인한다.
## 마스터 비밀번호 → 프로그램 토큰 → PIN 연결 — 2026-11-01

| 단계 | 목표 | 수정 대상 | 선행 조건 | 완료 기준 | 검증 | 상태 |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 마스터 비밀번호 인증 결과가 다음 단계로 연결 | ProgramTrustGate, trust enrollment API | 기존 인증/계정 확인 | 일반 설정 모드에서 setup 전용 403은 등록 거절로 유지하면서 일반 비밀번호 인증은 진행; 실패 시 토큰 없음 | `TDK_POS_TEST` 임시 직원 실 API: 잘못된 비밀번호 401, 정답 200 | PASS |
| 2 | 프로그램 토큰 해시 저장 및 안전 쿠키 발급/사용 | program trust API, DB, 쿠키 | 1 PASS | 무작위 토큰, DB SHA-256, Secure·HttpOnly·SameSite 쿠키, 프로그램 간 분리, 기존 유효 토큰 재사용 | 실제 ADM API/DB 통합 검사 통과. 브라우저의 실제 쿠키 저장은 Chrome 검증 차단 | IN_PROGRESS |
| 3 | PIN 상태에 따른 등록/입력 분기 | ProgramTrustGate, trust status | 2 PASS | DB PIN 상태가 화면 분기와 일치 | 임시 계정 API는 pinSetupRequired=true; sondows는 기존 PIN 등록 | PASS |
| 4 | 최초 PIN 등록과 세션 생성 | `/api/program-trust/pin`, 세션 | 3 PASS | 6자리 정책, 해시 저장, 세션 쿠키/DB 행 | 임시 계정 실제 ADM API 통과, Chrome 화면은 미검증 | PASS |
| 5 | 기존 PIN 인증 및 로그인 | ADM 로그인 API/UI | 4 PASS | PIN 성공 시 세션, 실패 거부 | 임시 계정 실제 API 성공/실패 통과, Chrome 화면은 미검증 | IN_PROGRESS |
| 6 | 재접속 토큰 + PIN 흐름 | trust status, PIN login | 5 PASS | 유효 쿠키 후 PIN 재로그인, 폐기/퇴사 토큰 거부 | 임시 계정 API 재접속 통과, Chrome 쿠키 자동 저장은 미검증 | TODO |

- sondows 읽기 전용 상태: TDK_POS_TEST, staff_id=1, 활성 OWNER, ADM 권한, 퇴사 아님, 마스터 해시 등록(scrypt), 개인 PIN 등록, 활성 ADM 토큰 1건, 최근 마스터 로그인 잠금 없음. 그러므로 이 계정에서 `ID + PIN` 화면은 유효 토큰과 기존 PIN에 따른 정상 분기이며 PIN 등록 화면으로 바뀌면 안 된다.
- 차단 원인: ADM ID 다음 분기는 등록 권한 전용 `initial-master/status` API가 일반 로그인에서 반환하는 403을 전체 인증 실패로 처리했다. 이 때문에 마스터 해시가 있는 일반 계정도 비밀번호 인증 단계에 도달하지 못했다.
- 수정: setup status 403은 계정/해시 정보를 노출하지 않고 `LOGIN_PASSWORD`로 진행한다. API가 일반 계정의 마스터 해시를 검증하며, 미등록/없는/비활성/권한 없는 계정은 기존 generic 실패 응답으로 거부된다. 최초 등록 허용 판정은 기존처럼 setup status의 승인 응답에만 의존한다.
- 실제 통합 검사(개발 DB에 임시 직원 1명 생성 후 정리): 잘못된 마스터 비밀번호 401 및 쿠키 없음, 올바른 비밀번호 ADM 토큰 발급 200, DB SHA-256 해시 일치 및 원문 미저장, HttpOnly+Secure+SameSite=Strict, 상태 API trusted=true, 최초 PIN 등록과 세션, 잘못된 PIN 401, PIN 로그인·재접속·페이지 200을 확인했다. `cleanup=complete`; 기존 sondows 행/비밀번호/PIN/토큰은 변경하지 않았다.
- 단위 테스트 8건, TypeScript, ESLint, Node 구문 검사는 통과했다. Chrome CDP 검증은 새 격리 프로필에서도 `Page.enable timeout`으로 실패해 실제 UI 화면 및 브라우저 쿠키 자동 저장을 확인하지 못했다. 이를 PASS로 기록하지 않는다. 이 이유로 2단계에 머물며 3~6단계는 진행하지 않는다.
- 운영 DB TDK_POS, 스키마, 기존 직원 데이터 변경 없음. 테스트 계정은 개발 DB에서 제거 완료. 테스트 비밀번호/PIN은 로그에 출력하지 않았다.
## ADM 마스터 비밀번호 인증 단일화 — 2026-11-01

| 단계 | 목표 | 대상 | 선행 | 완료 기준 | 테스트 | 상태 |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 인증 API·검증 함수·저장 컬럼·호출처와 TDK_POS_TEST 상태 조사 | trust routes, owner-security routes, schema, read-only query | 없음 | 두 경로의 저장/검증 차이 및 이전 영향 범위 기록 | 코드 추적, 비밀값 없는 SELECT | PASS |
| 2 | OWNER 보안 확인이 직원 마스터 해시를 사용하게 전환 | admin-auth.ts, owner-password route | 1 PASS | 소유자 멤버십 검사는 별도로 유지, old owner hash fallback 없음 | helper/route tests, TypeScript | PASS |
| 3 | 보안 메뉴 비밀번호 변경을 직원 마스터 해시 변경으로 연결 | owner-password route/UI | 2 PASS | 새 비밀번호가 ADM 인증과 보안 재인증에 동일, 세션·토큰 수명 정책 보존 | 개발 DB 임시 OWNER 통합 테스트 | PASS |
| 4 | OWNER 관리 흐름에서 레거시 비밀번호 인증 의존 제거 | owners route/UI, owner helper | 2 PASS | 권한 관리는 membership 기반, 레거시 hash는 인증·가용성 판정에 미사용 | owner management/role tests | PASS |
| 5 | 문구 변경 및 POS·ADM·KDS 회귀 | OwnerSecurityPrompt, auth routes/tests | 2~4 PASS | 보안 확인에 ‘마스터 비밀번호’, 일반 직원 차단, 기존 PIN·토큰 보존 | 실제 API/DB + Chrome 가능한 항목, full relevant suite | IN_PROGRESS |

- 조사 결과: ADM trust enrollment(`src/lib/program-trust-routes.ts`)는 `staff.security_password_hash`를 `verifySecurityPassword`로 확인한다. ADM 보안 메뉴(`/api/admin-center/security/owner-password`, `getOwnerSecurityState`)는 `admin_security_owners.password_hash`와 `credential_state`를 별도로 확인한다. 직원 관리·토큰 관리·OWNER 관리 API는 `requireOwnerSecurityAccess`로 이 별도 상태에 의존한다.
- 저장: `staff.security_password_hash`는 직원별 마스터 비밀번호이며, `admin_security_owners.password_hash`는 기존 OWNER 전용 확인값이다. `admin_security_settings.owner_security_password_hash` 컬럼도 있으나 현재 런타임 코드에서는 참조되지 않는다. 두 scrypt 해시가 모두 설정된 것은 읽기 전용으로 확인했지만 해시 비교만으로 원문 비밀번호 동일/상이 여부를 단정하지 않는다.
- TDK_POS_TEST sondows: staff_id=1, 활성 OWNER/ADM 허용, 직원 마스터 해시 설정, OWNER 전용 해시 설정/ACTIVE, 개인 PIN 및 활성 ADM 토큰 존재. 두 해시 원문은 읽거나 기록하지 않았다.
- 정책: OWNER 여부는 `admin_security_owners` 멤버십으로 계속 판정하고, 인증만 `staff.security_password_hash`로 통합한다. 레거시 OWNER 해시는 삭제·덮어쓰기하지 않고 인증 fallback에도 쓰지 않는다. DB 스키마와 운영 DB `TDK_POS`는 변경하지 않는다.

- Implementation: ADM master login and OWNER security reauthentication both verify `staff.security_password_hash`. OWNER access is still gated separately by `admin_security_owners` membership. Legacy OWNER hash and status are no longer used for verification or availability; stored values and schema are preserved. Changing the master password updates only the staff master hash and clears OWNER reauthentication freshness. Existing PIN, program trust tokens, and login sessions remain active. Temporary master-password issuance can target another OWNER but blocks self-targeting.
- Actual TDK_POS_TEST API integration: temporary OWNER master login 200, master password change 200 and changed password ADM login 200, legacy OWNER password 401, master reauthentication 200, owner management 200, trust-token management 200, regular ADM employee owner-management access 403. Existing OWNER PIN hash and active token count stayed unchanged across password change; legacy OWNER hash stayed unchanged. Regular employee PIN setup/login/re-entry also passed. Temporary rows, tokens, sessions, and logs were cleaned (`cleanup=complete`).
- Read-only sondows state after test: TDK_POS_TEST; active OWNER with ADM access; master password and PIN configured; one active ADM token. No sondows credential or token data was changed.
- Verification: `tsc --noEmit` PASS, changed-file ESLint PASS, owner-password route/helper tests 7/7 PASS, program-trust tests 5/5 PASS, live development-server + TDK_POS_TEST API integration PASS. Direct Chrome UI inspection was unavailable, so visual rendering remains unverified and stage 5 stays IN_PROGRESS. No production DB, schema, or sondows data was changed.
