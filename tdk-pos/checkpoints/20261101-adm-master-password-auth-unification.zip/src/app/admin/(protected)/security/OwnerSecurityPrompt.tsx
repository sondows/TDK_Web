"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import type { OwnerSecurityState } from "@/lib/admin-auth";
import styles from "../../admin.module.css";

export default function OwnerSecurityPrompt({ state }: { state: OwnerSecurityState }) {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const denied = state === "NOT_OWNER";
  const setupRequired = state === "OWNER_UNCONFIGURED";
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (busy || denied || setupRequired || !password) return;
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/admin-center/security/owner-password", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "verify", password }),
      });
      const result = await response.json() as { success?: boolean; message?: string };
      if (!response.ok || !result.success) { setMessage(result.message ?? "??? ???? ?????."); setPassword(""); return; }
      setPassword(""); router.refresh();
    } catch { setMessage("?? ???? ??? ? ????."); }
    finally { setBusy(false); }
  };
  return <main className={styles.content}>
    <section className={styles.loginCard}>
      <div className={styles.loginHeading}><h1>?? ??</h1><p>{denied ? "?????? ? ??? ??? ? ????." : setupRequired ? "??? ??? ????? ???? ?????. ADM ??? ???? ?? ??? ???." : "?? ??? ????? ??? ????? ??? ???."}</p></div>
      {!denied && !setupRequired && <form className={styles.loginForm} onSubmit={submit}>
        <label htmlFor="owner-security-password">??? ????</label>
        <input autoComplete="current-password" id="owner-security-password" maxLength={128} onChange={event => setPassword(event.target.value)} required type="password" value={password} />
        {message && <p className={styles.loginError} role="alert">{message}</p>}
        <button disabled={busy || password.length === 0} type="submit">{busy ? "?? ??" : "??"}</button>
      </form>}
      {denied && <p role="status">????? ?? ??? ??? ???.</p>}
    </section>
  </main>;
}
