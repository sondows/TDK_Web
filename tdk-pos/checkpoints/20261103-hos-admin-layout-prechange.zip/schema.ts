import { sql } from "drizzle-orm";
import type { AnyMySqlColumn } from "drizzle-orm/mysql-core";

import {
  mysqlTable,
  bigint,
  varchar,
  int,
  tinyint,
  datetime,
  date,
  decimal,
  text,
  index,
  primaryKey,
  uniqueIndex,
  mysqlEnum,
} from "drizzle-orm/mysql-core";

export const diningTables = mysqlTable(
  "dining_tables",
  {
    tableId: bigint("table_id", {
      mode: "number",
      unsigned: true,
    })
      .autoincrement()
      .primaryKey(),

    tableNo: varchar("table_no", { length: 20 }).notNull(),

    tableName: varchar("table_name", { length: 100 }),

    capacity: int("capacity").notNull().default(0),

    positionX: decimal("position_x", { precision: 5, scale: 2 }),
    positionY: decimal("position_y", { precision: 5, scale: 2 }),
    layoutWidth: decimal("layout_width", { precision: 5, scale: 2 }),
    layoutHeight: decimal("layout_height", { precision: 5, scale: 2 }),
    rotation: int("rotation").notNull().default(0),

    sortOrder: int("sort_order").notNull().default(0),

    isActive: tinyint("is_active").notNull().default(1),

    createdAt: datetime("created_at")
      .notNull()
      .default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("uq_dining_table_no").on(table.tableNo),
  ]
);

export const staff = mysqlTable(
  "staff",
  {
    staffId: bigint("staff_id", {
      mode: "number",
      unsigned: true,
    })
      .autoincrement()
      .primaryKey(),
    staffCode: varchar("staff_code", { length: 30 }).notNull(),
    name: varchar("name", { length: 100 }).notNull(),
    posEnabled: tinyint("pos_enabled").notNull().default(0),
    hosEnabled: tinyint("hos_enabled").notNull().default(0),
    employeePinHash: varchar("employee_pin_hash", { length: 255 }),
    securityPasswordHash: varchar("security_password_hash", { length: 255 }),
    securityPasswordChangeRequired: tinyint("security_password_change_required").notNull().default(0),
    terminatedAt: datetime("terminated_at"),
    kdsEnabled: tinyint("kds_enabled").notNull().default(0),
    kdsPasswordHash: varchar("kds_password_hash", { length: 255 }),
    kdsTotpSecretEnc: varchar("kds_totp_secret_enc", { length: 512 }),
    kdsTotpPendingSecretEnc: varchar("kds_totp_pending_secret_enc", { length: 512 }),
    kdsTotpPendingExpiresAt: datetime("kds_totp_pending_expires_at"),
    kdsPinChangeRequired: tinyint("kds_pin_change_required").notNull().default(1),
    adminLoginId: varchar("admin_login_id", { length: 32 }),
    adminEnabled: tinyint("admin_enabled").notNull().default(0),
    role: mysqlEnum("role", ["OWNER", "MANAGER", "STAFF"])
      .notNull()
      .default("STAFF"),
    isActive: tinyint("is_active").notNull().default(1),
    cancelRequiresPin: tinyint("cancel_requires_pin").notNull().default(1),
    createdAt: datetime("created_at")
      .notNull()
      .default(sql`CURRENT_TIMESTAMP`),
    updatedAt: datetime("updated_at")
      .notNull()
      .default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("uq_staff_code").on(table.staffCode),
    uniqueIndex("uq_staff_admin_login_id").on(table.adminLoginId),
  ]
);

export const customers = mysqlTable(
  "customers",
  {
    customerId: bigint("customer_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    contactName: varchar("contact_name", { length: 100 }),
    phone: varchar("phone", { length: 30 }),
    email: varchar("email", { length: 255 }),
    memo: text("memo"),
    isPaymentManaged: tinyint("is_payment_managed").notNull().default(0),
    autoCompletePayment: tinyint("auto_complete_payment").notNull().default(1),
    autoPrintSignReceipt: tinyint("auto_print_sign_receipt").notNull().default(1),
    usesFixedCoupon: tinyint("uses_fixed_coupon").notNull().default(0),
    fixedCouponAmount: decimal("fixed_coupon_amount", { precision: 14, scale: 2 }),
    fixedCouponBalancePolicy: mysqlEnum("fixed_coupon_balance_policy", ["CASH_CHANGE", "FORFEIT"]).notNull().default("FORFEIT"),
    fixedCouponCashChangeEnabled: tinyint("fixed_coupon_cash_change_enabled").notNull().default(0),
    fixedCouponCashChangeMinPercent: tinyint("fixed_coupon_cash_change_min_percent", { unsigned: true }),
    sortOrder: int("sort_order").notNull().default(0),
    isActive: tinyint("is_active").notNull().default(1),
    createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    index("idx_customers_name").on(table.name),
    index("idx_customers_phone").on(table.phone),
  ]
);

/** Read-only archive of daily totals from the former POS; no operational foreign keys. */
export const legacyDailySales = mysqlTable("legacy_daily_sales", {
  id: bigint("id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  businessDate: date("business_date").notNull(),
  saleCount: int("sale_count", { unsigned: true }).notNull(),
  grossSales: decimal("gross_sales", { precision: 14, scale: 2 }).notNull(),
  discountAmount: decimal("discount_amount", { precision: 14, scale: 2 }).notNull(),
  netSales: decimal("net_sales", { precision: 14, scale: 2 }).notNull(),
  cardAmount: decimal("card_amount", { precision: 14, scale: 2 }).notNull(),
  cashAmount: decimal("cash_amount", { precision: 14, scale: 2 }).notNull(),
  bankTransferAmount: decimal("bank_transfer_amount", { precision: 14, scale: 2 }).notNull(),
  otherAmount: decimal("other_amount", { precision: 14, scale: 2 }).notNull(),
  cancelledCount: int("cancelled_count", { unsigned: true }).notNull(),
  cancelledAmount: decimal("cancelled_amount", { precision: 14, scale: 2 }).notNull(),
  source: varchar("source", { length: 30 }).notNull(),
  importedAt: datetime("imported_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("uq_legacy_daily_sales_business_date").on(table.businessDate),
  index("idx_legacy_daily_sales_source_date").on(table.source, table.businessDate),
]);

export const staffSessions = mysqlTable("staff_sessions", {
  staffSessionId: bigint("staff_session_id", {
    mode: "number",
    unsigned: true,
  })
    .autoincrement()
    .primaryKey(),
  staffId: bigint("staff_id", {
    mode: "number",
    unsigned: true,
  }).notNull(),
  deviceId: bigint("device_id", {
    mode: "number",
    unsigned: true,
  }),
  // KDS managed-device registry has a different key space from legacy POS devices.
  managedDeviceId: bigint("managed_device_id", { mode: "number", unsigned: true }),
  trustTokenId: bigint("trust_token_id", { mode: "number", unsigned: true }),
  sessionTokenHash: varchar("session_token_hash", { length: 255 }),
  loggedInAt: datetime("logged_in_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
  lastActiveAt: datetime("last_active_at"),
  loggedOutAt: datetime("logged_out_at"),
  sessionType: mysqlEnum("session_type", ["POS", "ADMIN", "KDS", "HOS"]).notNull().default("POS"),
  status: mysqlEnum("status", ["ACTIVE", "LOGGED_OUT", "EXPIRED"])
    .notNull()
    .default("ACTIVE"),
  ownerReauthenticatedAt: datetime("owner_reauthenticated_at"),
});

export const adminSecuritySettings = mysqlTable("admin_security_settings", {
  settingsId: tinyint("settings_id").primaryKey(),
  ownerStaffId: bigint("owner_staff_id", { mode: "number", unsigned: true }),
  ownerSecurityPasswordHash: varchar("owner_security_password_hash", { length: 255 }),
  deviceRegistrationPasswordEnabled: tinyint("device_registration_password_enabled").notNull().default(0),
  deviceRegistrationPasswordHash: varchar("device_registration_password_hash", { length: 255 }),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedByStaffId: bigint("updated_by_staff_id", { mode: "number", unsigned: true }),
});

// Per-person second-factor credentials. A NULL hash means the member must enroll personally.
export const adminSecurityOwners = mysqlTable("admin_security_owners", {
  staffId: bigint("staff_id", { mode: "number", unsigned: true }).primaryKey(),
  passwordHash: varchar("password_hash", { length: 255 }),
  credentialState: mysqlEnum("credential_state", ["SETUP_PENDING", "RESET_REQUIRED", "ACTIVE"]).notNull().default("SETUP_PENDING"),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  assignedByStaffId: bigint("assigned_by_staff_id", { mode: "number", unsigned: true }),
});

/** A one-way latch: completing setup never becomes available again when owners leave. */
export const securityBootstrapState = mysqlTable("security_bootstrap_state", {
  stateId: tinyint("state_id").primaryKey(),
  completedAt: datetime("completed_at"),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const staffSecurityInvites = mysqlTable("staff_security_invites", {
  inviteId: bigint("invite_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  staffId: bigint("staff_id", { mode: "number", unsigned: true }).notNull(),
  inviteHash: varchar("invite_hash", { length: 64 }).notNull(),
  expiresAt: datetime("expires_at").notNull(),
  usedAt: datetime("used_at"),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  createdByStaffId: bigint("created_by_staff_id", { mode: "number", unsigned: true }),
}, table => [
  uniqueIndex("uq_staff_security_invites_hash").on(table.inviteHash),
  index("idx_staff_security_invites_staff").on(table.staffId, table.expiresAt),
]);

/** NAS-admin-issued, short-lived proof for recovering an existing owner's master password. */
export const masterPasswordRecoveryGrants = mysqlTable("master_password_recovery_grants", {
  grantId: bigint("grant_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  staffId: bigint("staff_id", { mode: "number", unsigned: true }).notNull(),
  tokenHash: varchar("token_hash", { length: 64 }).notNull(),
  expiresAt: datetime("expires_at").notNull(),
  usedAt: datetime("used_at"),
  revokedAt: datetime("revoked_at"),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => [
  uniqueIndex("uq_master_password_recovery_token").on(table.tokenHash),
  index("idx_master_password_recovery_staff").on(table.staffId, table.expiresAt),
]);

export const adminAuthAttempts = mysqlTable("admin_auth_attempts", {
  attemptKey: varchar("attempt_key", { length: 64 }).primaryKey(),
  windowStartedAt: datetime("window_started_at").notNull(),
  attemptCount: int("attempt_count", { unsigned: true }).notNull().default(0),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => [index("idx_admin_auth_attempts_updated_at").on(table.updatedAt)]);

export const kdsLoginAttempts = mysqlTable("kds_login_attempts", {
  staffId: bigint("staff_id", { mode: "number", unsigned: true }).primaryKey(),
  windowStartedAt: datetime("window_started_at").notNull(),
  attemptCount: int("attempt_count", { unsigned: true }).notNull().default(0),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const kdsAuthIpAttempts = mysqlTable("kds_auth_ip_attempts", {
  ipHash: varchar("ip_hash", { length: 64 }).primaryKey(),
  windowStartedAt: datetime("window_started_at").notNull(),
  attemptCount: int("attempt_count", { unsigned: true }).notNull().default(0),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => [index("idx_kds_auth_ip_updated_at").on(table.updatedAt)]);

export const kdsTrustedDevices = mysqlTable("kds_trusted_devices", {
  deviceId: bigint("device_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  staffId: bigint("staff_id", { mode: "number", unsigned: true }).notNull(),
  tokenHash: varchar("token_hash", { length: 64 }).notNull(),
  deviceLabel: varchar("device_label", { length: 120 }).notNull().default("KDS device"),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  lastUsedAt: datetime("last_used_at"),
  expiresAt: datetime("expires_at").notNull(),
  revokedAt: datetime("revoked_at"),
}, table => [uniqueIndex("uq_kds_trusted_devices_token_hash").on(table.tokenHash), index("idx_kds_trusted_devices_staff").on(table.staffId, table.revokedAt)]);

export const managedDevices = mysqlTable("managed_devices", {
  deviceId: bigint("device_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  deviceCode: varchar("device_code", { length: 24 }),
  deviceName: varchar("device_name", { length: 120 }).notNull(),
  deviceType: mysqlEnum("device_type", ["POS", "KDS", "ADM", "HOS"]).notNull(),
  status: mysqlEnum("status", ["PENDING", "APPROVED", "DENIED", "REVOKED", "EXPIRED"]).notNull().default("PENDING"),
  posEnabled: tinyint("pos_enabled").notNull().default(0),
  kdsEnabled: tinyint("kds_enabled").notNull().default(0),
  admEnabled: tinyint("adm_enabled").notNull().default(0),
  hosEnabled: tinyint("hos_enabled").notNull().default(0),
  tokenHash: varchar("token_hash", { length: 64 }),
  requestTokenHash: varchar("request_token_hash", { length: 64 }),
  confirmationCode: varchar("confirmation_code", { length: 6 }),
  registeredByStaffId: bigint("registered_by_staff_id", { mode: "number", unsigned: true }),
  requestedAt: datetime("requested_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  requestExpiresAt: datetime("request_expires_at"),
  approvedAt: datetime("approved_at"),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  lastUsedAt: datetime("last_used_at"),
  expiresAt: datetime("expires_at"),
  revokedAt: datetime("revoked_at"),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => [
  uniqueIndex("uq_managed_devices_code").on(table.deviceCode),
  uniqueIndex("uq_managed_devices_token_hash").on(table.tokenHash),
  uniqueIndex("uq_managed_devices_request_token_hash").on(table.requestTokenHash),
  index("idx_managed_devices_status_requested").on(table.status, table.requestedAt),
  index("idx_managed_devices_staff").on(table.registeredByStaffId, table.deviceType),
]);

/** Browser trust is independent of the employee PIN session and legacy device approval. */
export const programTrustTokens = mysqlTable("program_trust_tokens", {
  tokenId: bigint("token_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  program: mysqlEnum("program", ["POS", "ADM", "KDS", "HOS"]).notNull(),
  tokenHash: varchar("token_hash", { length: 64 }).notNull(),
  enrolledByStaffId: bigint("enrolled_by_staff_id", { mode: "number", unsigned: true }).notNull(),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  lastUsedAt: datetime("last_used_at"),
  revokedAt: datetime("revoked_at"),
  clientLabel: varchar("client_label", { length: 120 }),
  revokeReason: varchar("revoke_reason", { length: 100 }),
}, table => [
  uniqueIndex("uq_program_trust_tokens_hash").on(table.tokenHash),
  index("idx_program_trust_tokens_program").on(table.program, table.revokedAt),
  index("idx_program_trust_tokens_staff").on(table.enrolledByStaffId),
]);

export const systemSettings = mysqlTable("system_settings", {
  settingKey: varchar("setting_key", { length: 100 }).primaryKey(),
  settingValue: varchar("setting_value", { length: 255 }).notNull(),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedByStaffId: bigint("updated_by_staff_id", { mode: "number", unsigned: true }),
});

/** Master definitions for reusable discounts. POS quick presets use slots 1 through 4. */
export const discountRules = mysqlTable(
  "discount_rules",
  {
    discountRuleId: bigint("discount_rule_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    posPresetSlot: tinyint("pos_preset_slot", { unsigned: true }),
    discountCode: varchar("discount_code", { length: 40 }).notNull(),
    discountName: varchar("discount_name", { length: 150 }).notNull(),
    discountType: mysqlEnum("discount_type", ["RATE", "AMOUNT", "FREE_ITEM"]).notNull(),
    discountValue: decimal("discount_value", { precision: 14, scale: 2 }).notNull().default("0.00"),
    maxDiscountAmount: decimal("max_discount_amount", { precision: 14, scale: 2 }),
    minOrderAmount: decimal("min_order_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
    requiresManager: tinyint("requires_manager").notNull().default(0),
    startAt: datetime("start_at"),
    endAt: datetime("end_at"),
    isActive: tinyint("is_active").notNull().default(1),
    createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("uq_discount_rule_code").on(table.discountCode),
    uniqueIndex("uq_discount_rules_pos_preset_slot").on(table.posPresetSlot),
    index("idx_discount_rules_pos_preset_active").on(table.posPresetSlot, table.isActive),
  ]
);

export const partyGroups = mysqlTable("party_groups", {
  groupId: bigint("group_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  status: mysqlEnum("status", ["ACTIVE", "RELEASED"]).notNull().default("ACTIVE"),
  createdByStaffId: bigint("created_by_staff_id", { mode: "number", unsigned: true }),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  releasedAt: datetime("released_at"),
});

export const tableSessions = mysqlTable("table_sessions", {
  sessionId: bigint("session_id", {
    mode: "number",
    unsigned: true,
  })
    .autoincrement()
    .primaryKey(),
  businessSessionId: bigint("business_session_id", { mode: "number", unsigned: true }).references(() => businessSessions.businessSessionId),

  tableId: bigint("table_id", {
    mode: "number",
    unsigned: true,
  }),

  groupId: bigint("group_id", {
    mode: "number",
    unsigned: true,
  }),

  personCount: int("person_count").notNull().default(0),

  babyCount: int("baby_count").notNull().default(0),

  status: mysqlEnum("status", [
    "OPEN",
    "CLOSED",
    "CANCELLED",
  ])
    .notNull()
    .default("OPEN"),

  openedByStaffId: bigint("opened_by_staff_id", {
    mode: "number",
    unsigned: true,
  }),

  closedByStaffId: bigint("closed_by_staff_id", {
    mode: "number",
    unsigned: true,
  }),

  openedAt: datetime("opened_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),

  closedAt: datetime("closed_at"),

  note: varchar("note", { length: 500 }),
  sessionKind: mysqlEnum("session_kind", ["DINE_IN", "TAKEOUT_WALK_IN", "TAKEOUT_PHONE"]).notNull().default("DINE_IN"),
  displayName: varchar("display_name", { length: 100 }),
  takeoutLabelKey: varchar("takeout_label_key", { length: 40 }),
  createRequestKey: varchar("create_request_key", { length: 36 }),
  pickupName: varchar("pickup_name", { length: 100 }),
  pickupPhone: varchar("pickup_phone", { length: 30 }),
  pickupCustomerId: bigint("pickup_customer_id", { mode: "number", unsigned: true }).references(() => customers.customerId),
  pickupAt: datetime("pickup_at"),
}, (table) => [uniqueIndex("uq_table_sessions_takeout_label_key").on(table.takeoutLabelKey), uniqueIndex("uq_table_sessions_create_request_key").on(table.createRequestKey), index("idx_table_sessions_kind_status").on(table.sessionKind, table.status), index("idx_table_sessions_pickup_customer").on(table.pickupCustomerId)]);

export const menuCategories = mysqlTable("menu_categories", {
  categoryId: bigint("category_id", {
    mode: "number",
    unsigned: true,
  })
    .autoincrement()
    .primaryKey(),
  posName: varchar("pos_name", { length: 100 }).notNull(),
  sortOrder: int("sort_order").notNull().default(0),
  isActive: tinyint("is_active").notNull().default(1),
});

/** A dated business can contain several independently closed intervals. */
export const businessSessions = mysqlTable("business_sessions", {
  businessSessionId: bigint("business_session_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  businessDate: date("business_date", { mode: "string" }).notNull(),
  status: mysqlEnum("status", ["OPEN", "CLOSED"]).notNull().default("OPEN"),
  openGuard: tinyint("open_guard").unique(),
  cutoffTime: varchar("cutoff_time", { length: 5 }).notNull(),
  openingCashEnabled: tinyint("opening_cash_enabled").notNull().default(0),
  openingCash: decimal("opening_cash", { precision: 14, scale: 2 }),
  openedAt: datetime("opened_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  closedAt: datetime("closed_at"),
  closedByStaffId: bigint("closed_by_staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
  expectedCash: decimal("expected_cash", { precision: 14, scale: 2 }),
  actualCash: decimal("actual_cash", { precision: 14, scale: 2 }),
  cashDifference: decimal("cash_difference", { precision: 14, scale: 2 }),
  closingSnapshot: text("closing_snapshot"),
}, table => [index("idx_business_sessions_date").on(table.businessDate, table.businessSessionId)]);

/** Calendar-date settlement revisions. Historical business_sessions remain untouched. */
export const dailyClosingSnapshots = mysqlTable("daily_closing_snapshots", {
  dailyClosingId: bigint("daily_closing_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  salesDate: date("sales_date", { mode: "string" }).notNull(),
  revision: int("revision", { unsigned: true }).notNull(),
  requestKey: varchar("request_key", { length: 36 }).notNull(),
  snapshot: text("snapshot").notNull(),
  closedAt: datetime("closed_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  closedByStaffId: bigint("closed_by_staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
}, table => [
  uniqueIndex("uq_daily_closing_date_revision").on(table.salesDate, table.revision),
  uniqueIndex("uq_daily_closing_request").on(table.requestKey),
]);

export const businessSessionMutex = mysqlTable("business_session_mutex", {
  mutexId: tinyint("mutex_id").primaryKey(),
});

export const menus = mysqlTable("menus", {
  menuId: bigint("menu_id", {
    mode: "number",
    unsigned: true,
  })
    .autoincrement()
    .primaryKey(),
  menuCode: varchar("menu_code", { length: 40 }).notNull(),
  posName: varchar("pos_name", { length: 150 }).notNull(),
  categoryId: bigint("category_id", {
    mode: "number",
    unsigned: true,
  }),
  price: decimal("price", { precision: 14, scale: 2 }).notNull().default("0"),
  prepStationId: bigint("prep_station_id", {
    mode: "number",
    unsigned: true,
  }),
  isActive: tinyint("is_active").notNull().default(1),
  isQrVisible: tinyint("is_qr_visible").notNull().default(1),
  menuNumber: int("menu_number"),
  sortOrder: int("sort_order").notNull().default(0),
  kdsKind: mysqlEnum("kds_kind", ["NONE", "POT", "ADDON", "SOLO"]).notNull().default("NONE"),
  kdsGroupKey: varchar("kds_group_key", { length: 60 }),
  kdsCompletionTimer: tinyint("kds_completion_timer").notNull().default(0),
  kdsPostCookTimer: tinyint("kds_post_cook_timer").notNull().default(0),
  kdsVisible: tinyint("kds_visible").notNull().default(1),
  createdAt: datetime("created_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
}, (table) => [uniqueIndex("uq_menu_code").on(table.menuCode)]);

/** Existing stock item catalog from the store inventory schema. */
export const inventoryItems = mysqlTable("inventory_items", {
  inventoryItemId: bigint("inventory_item_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  itemCode: varchar("item_code", { length: 40 }),
  itemName: varchar("item_name", { length: 150 }).notNull(),
  itemType: mysqlEnum("item_type", ["INGREDIENT", "PREPARED", "BEVERAGE", "LIQUOR", "SUPPLY", "OTHER"]).notNull().default("OTHER"),
  baseUnit: varchar("base_unit", { length: 20 }).notNull(),
  trackingType: mysqlEnum("tracking_type", ["REALTIME", "THEORETICAL", "NONE"]).notNull().default("REALTIME"),
  currentQty: bigint("current_qty", { mode: "number" }).notNull().default(0),
  lowStockQty: bigint("low_stock_qty", { mode: "number" }),
  isActive: tinyint("is_active").notNull().default(1),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [uniqueIndex("uq_inventory_item_code").on(table.itemCode), index("idx_inventory_item_name").on(table.itemName)]);

/** Existing stock movement ledger; each row records the resulting balance. */
export const inventoryTransactions = mysqlTable("inventory_transactions", {
  inventoryTransactionId: bigint("inventory_transaction_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  inventoryItemId: bigint("inventory_item_id", { mode: "number", unsigned: true }).notNull().references(() => inventoryItems.inventoryItemId),
  transactionType: mysqlEnum("transaction_type", ["OPENING", "PURCHASE", "SALE", "PRODUCTION", "WASTE", "SERVICE", "ADJUSTMENT", "RETURN_IN", "RETURN_OUT", "OTHER"]).notNull(),
  qtyChange: bigint("qty_change", { mode: "number" }).notNull(),
  balanceAfter: bigint("balance_after", { mode: "number" }),
  orderItemId: bigint("order_item_id", { mode: "number", unsigned: true }).references(() => orderItems.orderItemId),
  purchaseItemId: bigint("purchase_item_id", { mode: "number", unsigned: true }),
  staffId: bigint("staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
  transactionAt: datetime("transaction_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  remark: varchar("remark", { length: 500 }),
}, (table) => [index("idx_inventory_tx_item_time").on(table.inventoryItemId, table.transactionAt), index("idx_inventory_tx_type_time").on(table.transactionType, table.transactionAt)]);

/** Existing recipe link from a sellable menu to a reusable inventory item. */
export const menuInventory = mysqlTable("menu_inventory", {
  menuId: bigint("menu_id", { mode: "number", unsigned: true }).notNull().references(() => menus.menuId, { onDelete: "cascade" }),
  inventoryItemId: bigint("inventory_item_id", { mode: "number", unsigned: true }).notNull().references(() => inventoryItems.inventoryItemId),
  qtyUsed: bigint("qty_used", { mode: "number" }).notNull().default(1),
}, (table) => [primaryKey({ columns: [table.menuId, table.inventoryItemId] })]);

export const menuImages = mysqlTable("menu_images", {
  menuImageId: bigint("menu_image_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  menuId: bigint("menu_id", { mode: "number", unsigned: true }).notNull().references(() => menus.menuId, { onDelete: "cascade" }),
  imageType: mysqlEnum("image_type", ["POS", "QR_THUMBNAIL", "QR_LARGE", "OTHER"]).notNull(),
  imageUrl: varchar("image_url", { length: 500 }).notNull(),
  sortOrder: int("sort_order").notNull().default(0),
  isActive: tinyint("is_active").notNull().default(1),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("idx_menu_images_menu_type").on(table.menuId, table.imageType, table.isActive)]);

export const modifierGroups = mysqlTable("modifier_groups", {
  modifierGroupId: bigint("modifier_group_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  posName: varchar("pos_name", { length: 150 }).notNull(),
  minSelect: int("min_select").notNull().default(0),
  maxSelect: int("max_select").notNull().default(1),
  isRequired: tinyint("is_required").notNull().default(0),
  isActive: tinyint("is_active").notNull().default(1),
  sortOrder: int("sort_order").notNull().default(0),
});

export const modifierOptions = mysqlTable("modifier_options", {
  modifierOptionId: bigint("modifier_option_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  modifierGroupId: bigint("modifier_group_id", { mode: "number", unsigned: true }).notNull().references(() => modifierGroups.modifierGroupId, { onDelete: "cascade" }),
  posName: varchar("pos_name", { length: 150 }).notNull(),
  priceDelta: decimal("price_delta", { precision: 14, scale: 2 }).notNull().default("0.00"),
  linkedMenuId: bigint("linked_menu_id", { mode: "number", unsigned: true }).references(() => menus.menuId),
  sortOrder: int("sort_order").notNull().default(0),
  isActive: tinyint("is_active").notNull().default(1),
}, (table) => [index("idx_modifier_options_group").on(table.modifierGroupId, table.isActive)]);

export const menuModifierGroups = mysqlTable("menu_modifier_groups", {
  menuId: bigint("menu_id", { mode: "number", unsigned: true }).notNull().references(() => menus.menuId, { onDelete: "cascade" }),
  modifierGroupId: bigint("modifier_group_id", { mode: "number", unsigned: true }).notNull().references(() => modifierGroups.modifierGroupId, { onDelete: "cascade" }),
  sortOrder: int("sort_order").notNull().default(0),
  posChoiceDefaultOptionId: bigint("pos_choice_default_option_id", { mode: "number", unsigned: true }),
}, (table) => [primaryKey({ columns: [table.menuId, table.modifierGroupId] }), index("fk_menu_modifier_groups_group").on(table.modifierGroupId)]);

export const menuComponents = mysqlTable("menu_components", {
  menuComponentId: bigint("menu_component_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  parentMenuId: bigint("parent_menu_id", { mode: "number", unsigned: true }).notNull().references(() => menus.menuId),
  componentMenuId: bigint("component_menu_id", { mode: "number", unsigned: true }).notNull().references(() => menus.menuId),
  qtyPerUnit: int("qty_per_unit").notNull().default(1),
  printOnKitchen: tinyint("print_on_kitchen").notNull().default(1),
  printOnReceipt: tinyint("print_on_receipt").notNull().default(0),
  sortOrder: int("sort_order").notNull().default(0),
}, (table) => [uniqueIndex("uq_menu_component").on(table.parentMenuId, table.componentMenuId)]);

export const orders = mysqlTable("orders", {
  orderId: bigint("order_id", {
    mode: "number",
    unsigned: true,
  })
    .autoincrement()
    .primaryKey(),
  sessionId: bigint("session_id", {
    mode: "number",
    unsigned: true,
  }).notNull(),
  orderType: mysqlEnum("order_type", ["POS", "QR", "OTHER"])
    .notNull()
    .default("POS"),
  status: mysqlEnum("status", ["OPEN", "ACCEPTED", "CANCELLED", "COMPLETED"])
    .notNull()
    .default("ACCEPTED"),
  subtotalAmount: decimal("subtotal_amount", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  discountAmount: decimal("discount_amount", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  totalAmount: decimal("total_amount", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  createdByStaffId: bigint("created_by_staff_id", {
    mode: "number",
    unsigned: true,
  }),
  acceptedByStaffId: bigint("accepted_by_staff_id", {
    mode: "number",
    unsigned: true,
  }),
  orderedAt: datetime("ordered_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
  acceptedAt: datetime("accepted_at"),
  note: varchar("note", { length: 500 }),
});

// A merge keeps both table sessions and their orders intact.  The source
// session is only hidden from the physical-table view while this row is ACTIVE.
export const tableSessionMerges = mysqlTable(
  "table_session_merges",
  {
    mergeId: bigint("merge_id", { mode: "number", unsigned: true })
      .autoincrement()
      .primaryKey(),
    sourceSessionId: bigint("source_session_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => tableSessions.sessionId),
    sourceTableId: bigint("source_table_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => diningTables.tableId),
    destinationSessionId: bigint("destination_session_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => tableSessions.sessionId),
    destinationTableId: bigint("destination_table_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => diningTables.tableId),
    status: mysqlEnum("status", ["ACTIVE", "SEPARATED"]).notNull().default("ACTIVE"),
    mergedByStaffId: bigint("merged_by_staff_id", { mode: "number", unsigned: true })
      .references(() => staff.staffId),
    mergedAt: datetime("merged_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    separatedAt: datetime("separated_at"),
  },
  (table) => [
    index("idx_table_session_merges_source_active").on(table.sourceSessionId, table.status),
    index("idx_table_session_merges_destination_active").on(table.destinationSessionId, table.status),
    index("idx_table_session_merges_source_table_active").on(table.sourceTableId, table.status),
  ]
);

/** Discounts are attached to a table session without changing original order prices. */
export const tableSessionDiscounts = mysqlTable(
  "table_session_discounts",
  {
    tableSessionDiscountId: bigint("table_session_discount_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
    sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => tableSessions.sessionId),
    discountType: mysqlEnum("discount_type", ["SNS_REVIEW", "AMOUNT", "PERCENT"]).notNull(),
    label: varchar("label", { length: 100 }).notNull(),
    discountAmount: decimal("discount_amount", { precision: 14, scale: 2 }).notNull(),
    discountRate: int("discount_rate"),
    appliedByStaffId: bigint("applied_by_staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
    createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [index("idx_table_session_discounts_session").on(table.sessionId, table.createdAt)]
);

export const orderItems = mysqlTable("order_items", {
  orderItemId: bigint("order_item_id", {
    mode: "number",
    unsigned: true,
  })
    .autoincrement()
    .primaryKey(),
  orderId: bigint("order_id", {
    mode: "number",
    unsigned: true,
  }).notNull(),
  parentOrderItemId: bigint("parent_order_item_id", {
    mode: "number",
    unsigned: true,
  }),
  menuId: bigint("menu_id", {
    mode: "number",
    unsigned: true,
  }).notNull(),
  itemName: varchar("item_name", { length: 200 }).notNull(),
  qty: int("qty").notNull(),
  actualComponentQty: int("actual_component_qty"),
  unitPrice: decimal("unit_price", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  discountAmount: decimal("discount_amount", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  totalAmount: decimal("total_amount", { precision: 14, scale: 2 })
    .notNull()
    .default("0"),
  prepStationId: bigint("prep_station_id", {
    mode: "number",
    unsigned: true,
  }),
  itemType: mysqlEnum("item_type", ["NORMAL", "COMPONENT", "SERVICE"])
    .notNull()
    .default("NORMAL"),
  status: mysqlEnum("status", [
    "ORDERED",
    "PREPARING",
    "READY",
    "SERVED",
    "CANCELLED",
  ])
    .notNull()
    .default("ORDERED"),
  printOnReceipt: tinyint("print_on_receipt").notNull().default(1),
  orderedAt: datetime("ordered_at")
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
  cancelledAt: datetime("cancelled_at"),
  cancelledByStaffId: bigint("cancelled_by_staff_id", {
    mode: "number",
    unsigned: true,
  }),
  note: varchar("note", { length: 500 }),
});

/** Kitchen work is attached to immutable order batches; sales and payment state stay separate. */
export const kdsCookingGroups = mysqlTable("kds_cooking_groups", {
  groupId: bigint("group_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  compatibilityKey: varchar("compatibility_key", { length: 80 }).notNull(),
  startedAtMs: bigint("started_at_ms", { mode: "number", unsigned: true }).notNull(),
}, table => [index("idx_kds_groups_compatibility_time").on(table.compatibilityKey, table.startedAtMs)]);

/** One short database row lock serializes grouping across several kitchen tablets. */
export const kdsGroupMutex = mysqlTable("kds_group_mutex", {
  mutexId: tinyint("mutex_id").primaryKey(),
});

export const kdsSyncCursor = mysqlTable("kds_sync_cursor", {
  cursorId: tinyint("cursor_id").primaryKey(),
  initialOrderId: bigint("initial_order_id", { mode: "number", unsigned: true }).notNull(),
  lastOrderId: bigint("last_order_id", { mode: "number", unsigned: true }).notNull(),
});

export const kdsTasks = mysqlTable("kds_tasks", {
  taskId: bigint("task_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  orderId: bigint("order_id", { mode: "number", unsigned: true }).notNull().references(() => orders.orderId),
  taskKey: varchar("task_key", { length: 80 }).notNull(),
  memberItems: text("member_items").notNull(),
  kind: mysqlEnum("kind", ["POT", "SOLO"]).notNull(),
  compatibilityKey: varchar("compatibility_key", { length: 80 }).notNull(),
  completionTimer: tinyint("completion_timer").notNull().default(0),
  postCookTimerMinutes: tinyint("post_cook_timer_minutes", { unsigned: true }),
  postCookTimerStartedAtMs: bigint("post_cook_timer_started_at_ms", { mode: "number", unsigned: true }),
  status: mysqlEnum("status", ["WAITING", "COOKING", "DONE"]).notNull().default("WAITING"),
  cookingGroupId: bigint("cooking_group_id", { mode: "number", unsigned: true }).references(() => kdsCookingGroups.groupId),
  cookingStartedAtMs: bigint("cooking_started_at_ms", { mode: "number", unsigned: true }),
  cookingCompletedAtMs: bigint("cooking_completed_at_ms", { mode: "number", unsigned: true }),
  previousState: text("previous_state"),
  changedAtMs: bigint("changed_at_ms", { mode: "number", unsigned: true }),
  cancelAcknowledgedAtMs: bigint("cancel_acknowledged_at_ms", { mode: "number", unsigned: true }),
}, table => [
  uniqueIndex("uq_kds_tasks_key").on(table.taskKey),
  index("idx_kds_tasks_order").on(table.orderId),
  index("idx_kds_tasks_status").on(table.status, table.taskId),
]);

/** User-controlled kitchen display order, independent of POS party groups. */
export const kdsTableOrder = mysqlTable("kds_table_order", {
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).primaryKey(),
  sortOrder: int("sort_order").notNull(),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

/** User-controlled ordering of tables inside one POS party, separate from global KDS order. */
export const kdsPartyTableOrder = mysqlTable("kds_party_table_order", {
  partyGroupId: bigint("party_group_id", { mode: "number", unsigned: true }).notNull(),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull(),
  sortOrder: int("sort_order").notNull(),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => [
  uniqueIndex("uq_kds_party_table_order_member").on(table.partyGroupId, table.sessionId),
  index("idx_kds_party_table_order_sort").on(table.partyGroupId, table.sortOrder, table.sessionId),
]);

/** Existing checkout tables. A checkout is linked to its bill scope through checkout_items. */
export const paymentMethods = mysqlTable("payment_methods", {
  paymentMethodId: bigint("payment_method_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  methodCode: varchar("method_code", { length: 30 }).notNull(),
  methodName: varchar("method_name", { length: 100 }).notNull(),
  methodType: mysqlEnum("method_type", ["CASH", "CARD", "VOUCHER", "CREDIT", "TRANSFER", "OTHER"]).notNull(),
  isActive: tinyint("is_active").notNull().default(1),
  sortOrder: int("sort_order").notNull().default(0),
}, (table) => [uniqueIndex("uq_payment_method_code").on(table.methodCode)]);

export const paymentMethodSettings = mysqlTable("payment_method_settings", {
  paymentMethodId: bigint("payment_method_id", { mode: "number", unsigned: true }).primaryKey().references(() => paymentMethods.paymentMethodId),
  inputType: mysqlEnum("input_type", ["AMOUNT", "QUANTITY"]).notNull(),
  unitAmount: decimal("unit_amount", { precision: 14, scale: 2 }),
  balancePolicy: mysqlEnum("balance_policy", ["CASH_CHANGE", "FORFEIT"]),
  cashChangeEnabled: tinyint("cash_change_enabled"),
  cashChangeMinPercent: tinyint("cash_change_min_percent", { unsigned: true }),
  validityEnabled: tinyint("validity_enabled").notNull().default(0),
  validFrom: date("valid_from", { mode: "string" }),
  validUntil: date("valid_until", { mode: "string" }),
  accountInfoEnabled: tinyint("account_info_enabled").notNull().default(0),
  accountInfoPrintEnabled: tinyint("account_info_print_enabled").notNull().default(0),
  autoCompleteEnabled: tinyint("auto_complete_enabled").notNull().default(1),
  bankName: varchar("bank_name", { length: 100 }),
  accountNumber: varchar("account_number", { length: 100 }),
  accountHolder: varchar("account_holder", { length: 100 }),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedByStaffId: bigint("updated_by_staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
});

export const checkouts = mysqlTable("checkouts", {
  checkoutId: bigint("checkout_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  receiptLookupCode: varchar("receipt_lookup_code", { length: 16 }),
  subtotalAmount: decimal("subtotal_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  discountAmount: decimal("discount_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  totalAmount: decimal("total_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  paidAmount: decimal("paid_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  status: mysqlEnum("status", ["OPEN", "PARTIALLY_PAID", "PAID", "CANCELLED", "REFUNDED"]).notNull().default("OPEN"),
  createdByStaffId: bigint("created_by_staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  completedAt: datetime("completed_at"),
  note: varchar("note", { length: 500 }),
}, (table) => [index("idx_checkouts_status_time").on(table.status, table.createdAt), uniqueIndex("uq_checkouts_receipt_lookup_code").on(table.receiptLookupCode)]);

export const checkoutItems = mysqlTable("checkout_items", {
  checkoutItemId: bigint("checkout_item_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  checkoutId: bigint("checkout_id", { mode: "number", unsigned: true }).notNull().references(() => checkouts.checkoutId),
  orderItemId: bigint("order_item_id", { mode: "number", unsigned: true }).notNull().references(() => orderItems.orderItemId),
  qty: int("qty").notNull(),
  unitPrice: decimal("unit_price", { precision: 14, scale: 2 }).notNull().default("0.00"),
  discountAmount: decimal("discount_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
}, (table) => [index("idx_checkout_items_order_item").on(table.orderItemId), index("fk_checkout_items_checkout").on(table.checkoutId)]);

export const payments = mysqlTable("payments", {
  paymentId: bigint("payment_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  checkoutId: bigint("checkout_id", { mode: "number", unsigned: true }).notNull().references(() => checkouts.checkoutId),
  paymentMethodId: bigint("payment_method_id", { mode: "number", unsigned: true }).notNull().references(() => paymentMethods.paymentMethodId),
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
  appliedAmount: decimal("applied_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  customerId: bigint("customer_id", { mode: "number", unsigned: true }).references(() => customers.customerId),
  customerCouponCustomerNameSnapshot: varchar("customer_coupon_customer_name_snapshot", { length: 100 }),
  customerCouponQuantity: int("customer_coupon_quantity", { unsigned: true }),
  customerCouponUnitAmountSnapshot: decimal("customer_coupon_unit_amount_snapshot", { precision: 14, scale: 2 }),
  status: mysqlEnum("status", ["PENDING", "APPROVED", "CANCELLED", "REFUNDED", "FAILED"]).notNull().default("APPROVED"),
  approvalNo: varchar("approval_no", { length: 100 }),
  externalTransactionId: varchar("external_transaction_id", { length: 150 }),
  processedByStaffId: bigint("processed_by_staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
  paidAt: datetime("paid_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  cancelledAt: datetime("cancelled_at"),
  note: varchar("note", { length: 500 }),
}, (table) => [index("idx_payments_checkout_status").on(table.checkoutId, table.status), index("idx_payments_paid_at").on(table.paidAt), index("idx_payments_customer").on(table.customerId)]);

/** Records which physical table session received each portion of a group checkout payment. */
export const paymentSessionAllocations = mysqlTable("payment_session_allocations", {
  paymentId: bigint("payment_id", { mode: "number", unsigned: true }).notNull().references(() => payments.paymentId),
  sessionId: bigint("session_id", { mode: "number", unsigned: true }).notNull().references(() => tableSessions.sessionId),
  appliedAmount: decimal("applied_amount", { precision: 14, scale: 2 }).notNull(),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  primaryKey({ columns: [table.paymentId, table.sessionId] }),
  index("idx_payment_session_allocations_session").on(table.sessionId),
]);

/** Signed customer trade balance history. Payment entries retain their source payment link. */
export const customerPrepaidLedger = mysqlTable("customer_prepaid_ledger", {
  ledgerId: bigint("ledger_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  customerId: bigint("customer_id", { mode: "number", unsigned: true }).notNull().references(() => customers.customerId),
  paymentId: bigint("payment_id", { mode: "number", unsigned: true }).references(() => payments.paymentId),
  entryType: mysqlEnum("entry_type", ["CARD_OVERPAYMENT", "CARD_OVERPAYMENT_REVERSAL", "PAYMENT_OVERPAYMENT", "PAYMENT_OVERPAYMENT_REVERSAL", "DEPOSIT", "REFUND", "ADJUSTMENT", "CUSTOMER_PAYMENT", "CUSTOMER_PAYMENT_REVERSAL"]).notNull(),
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
  transactionAt: datetime("transaction_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  methodCode: varchar("method_code", { length: 20 }),
  adjustmentReason: varchar("adjustment_reason", { length: 100 }),
  memo: varchar("memo", { length: 500 }),
  requestKey: varchar("request_key", { length: 36 }),
  reversesLedgerId: bigint("reverses_ledger_id", { mode: "number", unsigned: true }).references((): AnyMySqlColumn => customerPrepaidLedger.ledgerId),
  createdByStaffId: bigint("created_by_staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("idx_customer_prepaid_ledger_customer_time").on(table.customerId, table.createdAt),
  index("idx_customer_prepaid_ledger_customer_transaction").on(table.customerId, table.transactionAt, table.ledgerId),
  uniqueIndex("uq_customer_prepaid_ledger_payment_type").on(table.paymentId, table.entryType),
  uniqueIndex("uq_customer_prepaid_ledger_reversal").on(table.reversesLedgerId),
  uniqueIndex("uq_customer_prepaid_ledger_request").on(table.requestKey),
]);

export const paymentOtherDetails = mysqlTable("payment_other_details", {
  paymentId: bigint("payment_id", { mode: "number", unsigned: true }).primaryKey().references(() => payments.paymentId),
  methodNameSnapshot: varchar("method_name_snapshot", { length: 100 }).notNull(),
  inputTypeSnapshot: mysqlEnum("input_type_snapshot", ["AMOUNT", "QUANTITY"]).notNull(),
  quantity: int("quantity", { unsigned: true }),
  unitAmountSnapshot: decimal("unit_amount_snapshot", { precision: 14, scale: 2 }),
  submittedAmount: decimal("submitted_amount", { precision: 14, scale: 2 }).notNull(),
  appliedAmount: decimal("applied_amount", { precision: 14, scale: 2 }).notNull(),
  balancePolicySnapshot: mysqlEnum("balance_policy_snapshot", ["CASH_CHANGE", "FORFEIT"]),
  cashChangeEnabledSnapshot: tinyint("cash_change_enabled_snapshot"),
  cashChangeMinPercentSnapshot: tinyint("cash_change_min_percent_snapshot", { unsigned: true }),
  cashChangeAmount: decimal("cash_change_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  forfeitedAmount: decimal("forfeited_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const auditLogs = mysqlTable("audit_logs", {
  auditLogId: bigint("audit_log_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  staffId: bigint("staff_id", { mode: "number", unsigned: true }).references(() => staff.staffId),
  deviceId: bigint("device_id", { mode: "number", unsigned: true }),
  actionType: varchar("action_type", { length: 50 }).notNull(),
  entityType: varchar("entity_type", { length: 50 }).notNull(),
  entityId: bigint("entity_id", { mode: "number", unsigned: true }),
  description: varchar("description", { length: 1000 }),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const cashOpeningFunds = mysqlTable("cash_opening_funds", {
  cashOpeningFundId: bigint("cash_opening_fund_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  businessDate: date("business_date", { mode: "string" }).notNull(),
  otherAmount: bigint("other_amount", { mode: "number", unsigned: true }).notNull().default(0),
  count50000: int("count_50000", { unsigned: true }).notNull().default(0),
  count10000: int("count_10000", { unsigned: true }).notNull().default(0),
  count5000: int("count_5000", { unsigned: true }).notNull().default(0),
  count1000: int("count_1000", { unsigned: true }).notNull().default(0),
  count500: int("count_500", { unsigned: true }).notNull().default(0),
  count100: int("count_100", { unsigned: true }).notNull().default(0),
  totalAmount: bigint("total_amount", { mode: "number", unsigned: true }).notNull().default(0),
  createdByStaffId: bigint("created_by_staff_id", { mode: "number", unsigned: true }).notNull().references(() => staff.staffId),
  updatedByStaffId: bigint("updated_by_staff_id", { mode: "number", unsigned: true }).notNull().references(() => staff.staffId),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: datetime("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, table => [uniqueIndex("uq_cash_opening_funds_business_date").on(table.businessDate)]);

export const orderItemCancellations = mysqlTable("order_item_cancellations", {
  cancellationId: bigint("cancellation_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  orderItemId: bigint("order_item_id", { mode: "number", unsigned: true }).notNull().references(() => orderItems.orderItemId),
  cancelledQty: int("cancelled_qty").notNull(),
  cancelledAmount: decimal("cancelled_amount", { precision: 14, scale: 2 }).notNull(),
  cancellationReason: varchar("cancellation_reason", { length: 500 }).notNull(),
  cancelledByStaffId: bigint("cancelled_by_staff_id", { mode: "number", unsigned: true }).notNull().references(() => staff.staffId),
  cancelledAt: datetime("cancelled_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  createdAt: datetime("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [index("idx_order_item_cancellations_item").on(table.orderItemId, table.cancelledAt), index("idx_order_item_cancellations_staff").on(table.cancelledByStaffId)]);

export const orderItemOptions = mysqlTable("order_item_options", {
  orderItemOptionId: bigint("order_item_option_id", { mode: "number", unsigned: true }).autoincrement().primaryKey(),
  orderItemId: bigint("order_item_id", { mode: "number", unsigned: true }).notNull().references(() => orderItems.orderItemId),
  modifierOptionId: bigint("modifier_option_id", { mode: "number", unsigned: true }).references(() => modifierOptions.modifierOptionId),
  optionName: varchar("option_name", { length: 200 }).notNull(),
  qty: int("qty").notNull().default(1),
  unitPrice: decimal("unit_price", { precision: 14, scale: 2 }).notNull().default("0.00"),
  totalAmount: decimal("total_amount", { precision: 14, scale: 2 }).notNull().default("0.00"),
}, (table) => [index("fk_order_item_options_item").on(table.orderItemId), index("fk_order_item_options_option").on(table.modifierOptionId)]);
