"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import QRCode from "qrcode";
import QrStoreTitle from "@/app/qr/QrStoreTitle";
import { aggregateQrOrderItems, totalQrOrderAmount } from "@/lib/qr-order-history-model";
import type { QrPublicTitleSettings } from "@/lib/qr-title-model";
import type { QrPublicNotice } from "@/lib/qr-notice-model";

type OrderItem = {
  qrOrderId: number;
  qrOrderItemId: number;
  menuId: number;
  itemName: string;
  qty: number;
  unitPrice: string;
  totalAmount: string;
  options: Array<{ optionName: string; qty: number; totalAmount: string }>;
  kdsKind: string;
  stage: string | null;
  kdsStartedAtMs: number | null;
  kdsCompletedAtMs: number | null;
  timerEndsAtMs: number | null;
};
type QrOrder = {
  qrOrderId: number;
  status: string;
  totalAmount: string;
  orderedAt: string;
  acceptedOrderId: number | null;
  acceptedAt: string | null;
  note: string | null;
};
type Payload = {
  success?: boolean;
  tableNo?: string;
  serverNow?: number;
  canViewOrders?: boolean;
  needsJoin?: boolean;
  orders?: QrOrder[];
  items?: OrderItem[];
  message?: string;
};
type Invite = { url: string; qrData: string; expiresAt: string };
type ViewMode = "aggregate" | "detail";

const emptyOrders: QrOrder[] = [];
const emptyItems: OrderItem[] = [];
const won = (amount: string | number) => `${new Intl.NumberFormat("ko-KR").format(Math.round(Number(amount) || 0))}원`;
const dateTime = (value: string) => new Intl.DateTimeFormat("ko-KR", { hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(value));
const elapsedMinutes = (from: number, now: number) => Math.max(0, Math.floor((now - from) / 60_000));

function itemStatus(item: OrderItem, order: QrOrder, nowMs: number): string | null {
  if (order.status !== "ACCEPTED" || !item.stage) return null;
  if (item.stage === "WAITING") return "조리대기";
  if (item.stage === "COOKING") return item.kdsStartedAtMs
    ? `조리중 · ${elapsedMinutes(item.kdsStartedAtMs, nowMs)}분 경과`
    : "조리중";
  if (item.stage === "DONE") {
    if (item.kdsKind === "POT" && item.timerEndsAtMs && nowMs < item.timerEndsAtMs) {
      const remaining = Math.ceil((item.timerEndsAtMs - nowMs) / 1000);
      return `매장끓이기 · ${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, "0")} 남음`;
    }
    return item.kdsCompletedAtMs
      ? `조리완료 · ${elapsedMinutes(item.kdsCompletedAtMs, nowMs)}분 경과`
      : "조리완료";
  }
  return null;
}

export default function QrOrderHistory({ titleData, notices = [] }: { titleData: QrPublicTitleSettings; notices?: QrPublicNotice[] }) {
  const router = useRouter();
  const [payload, setPayload] = useState<Payload | null>(null);
  const [error, setError] = useState("");
  const [serverOffset, setServerOffset] = useState(0);
  const [now, setNow] = useState(0);
  const [viewMode, setViewMode] = useState<ViewMode>("aggregate");
  const [invite, setInvite] = useState<Invite | null>(null);
  const [shareOpen, setShareOpen] = useState(false);
  const [shareBusy, setShareBusy] = useState(false);
  const [shareError, setShareError] = useState("");
  const [shareMessage, setShareMessage] = useState("");
  const inviteRequestRef = useRef(false);

  const refresh = useCallback(async () => {
    const response = await fetch("/api/qr/table-orders", { cache: "no-store", credentials: "same-origin" });
    const data = await response.json() as Payload;
    if (!response.ok || !data.success) {
      const failure = new Error(data.message ?? "테이블 QR 인증이 필요합니다. 테이블 스티커를 다시 스캔해 주세요.") as Error & { status: number };
      failure.status = response.status;
      throw failure;
    }
    setPayload(data);
    setServerOffset((data.serverNow ?? Date.now()) - Date.now());
    setError("");
    if (data.needsJoin && !data.orders?.some(order => order.status === "PENDING")) router.replace("/qrorder/join-required");
    else if (data.orders?.length === 0) router.replace("/qrorder/order");
  }, [router]);

  useEffect(() => {
    let mounted = true;
    const load = () => void refresh().catch(reason => {
      if (!mounted) return;
      setError(reason instanceof Error ? reason.message : "주문내역을 불러오지 못했습니다.");
      const status = reason instanceof Error ? (reason as Error & { status?: number }).status : undefined;
      if (status === 401 || status === 409) {
        setInvite(null);
        setShareOpen(false);
      }
    });
    const poll = window.setInterval(load, 5000);
    const tick = window.setInterval(() => setNow(Date.now()), 1000);
    load();
    return () => { mounted = false; window.clearInterval(poll); window.clearInterval(tick); };
  }, [refresh]);

  const orders = payload?.orders ?? emptyOrders;
  const items = payload?.items ?? emptyItems;
  const total = useMemo(() => totalQrOrderAmount(orders), [orders]);
  const aggregateItems = useMemo(() => aggregateQrOrderItems(orders, items), [items, orders]);
  const pendingFirstOrder = !payload?.canViewOrders && orders.some(order => order.status === "PENDING");
  const rejectedOrder = orders.some(order => order.status === "REJECTED");
  const serverNow = now ? now + serverOffset : payload?.serverNow ?? 0;
  const inviteIsValid = Boolean(invite && Date.parse(invite.expiresAt) > serverNow);

  const createInvite = async () => {
    if (inviteRequestRef.current) return;
    inviteRequestRef.current = true;
    setShareBusy(true);
    setShareError("");
    setShareMessage("");
    try {
      const response = await fetch("/api/qr/order-invites", { method: "POST", credentials: "same-origin" });
      const result = await response.json() as { success?: boolean; url?: string; expiresAt?: string; message?: string };
      if (!response.ok || !result.success || !result.url || !result.expiresAt) {
        throw new Error(result.message ?? "함께 주문할 QR을 만들지 못했습니다.");
      }
      const qrData = await QRCode.toDataURL(result.url, { width: 280, margin: 1, errorCorrectionLevel: "M" });
      setInvite({ url: result.url, qrData, expiresAt: result.expiresAt });
    } catch (reason) {
      setShareError(reason instanceof Error ? reason.message : "함께 주문할 QR을 만들지 못했습니다.");
    } finally {
      inviteRequestRef.current = false;
      setShareBusy(false);
    }
  };

  const openShare = () => {
    setShareOpen(true);
    setShareError("");
    const reusableInvite = invite && Date.parse(invite.expiresAt) > Date.now();
    if (!reusableInvite) void createInvite();
  };

  const copyInvite = async () => {
    if (!invite) return;
    try {
      let copied = false;
      if (navigator.clipboard?.writeText) {
        try {
          await navigator.clipboard.writeText(invite.url);
          copied = true;
        } catch { /* Try the browser selection fallback below. */ }
      }
      if (!copied) {
        const input = document.createElement("textarea");
        input.value = invite.url;
        input.setAttribute("readonly", "");
        input.style.position = "fixed";
        input.style.opacity = "0";
        document.body.append(input);
        input.select();
        copied = document.execCommand("copy");
        input.remove();
      }
      if (!copied) throw new Error("copy failed");
      setShareMessage("주문 링크를 복사했습니다.");
    } catch {
      setShareError("링크를 복사하지 못했습니다. 주소를 길게 눌러 복사해 주세요.");
    }
  };

  const shareInvite = async () => {
    if (!invite) return;
    if (!navigator.share) {
      await copyInvite();
      return;
    }
    try {
      await navigator.share({ title: "함께 주문하기", text: `테이블 ${payload?.tableNo ?? ""}에서 함께 주문해 주세요.`, url: invite.url });
      setShareMessage("주문 링크를 공유했습니다.");
    } catch (reason) {
      if (reason instanceof DOMException && reason.name === "AbortError") return;
      await copyInvite();
    }
  };

  const canRetryOrder = Boolean(payload?.canViewOrders || rejectedOrder);

  return <main className="mx-auto min-h-svh max-w-lg bg-slate-50 px-4 pb-[max(1.5rem,env(safe-area-inset-bottom))] text-slate-900">
    <QrStoreTitle fixedHero orderHistoryHeader notices={notices} settings={titleData} />
    <div className="mx-auto mt-4 max-w-2xl">
      <div className="flex items-end justify-between gap-3">
        <h1 className="text-xl font-extrabold">주문내역</h1>
        <span className="shrink-0 text-sm font-bold text-slate-600">{payload?.tableNo ? `${payload.tableNo} 테이블` : "— 테이블"}</span>
      </div>
      <div className="mt-3 flex items-center justify-between border-b border-slate-200 pb-4 text-sm">
        <span className="font-semibold text-slate-500">주문금액</span>
        <strong className="text-lg tabular-nums">{won(total)}</strong>
      </div>
      {error && <p className="mt-3 rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>}
      {pendingFirstOrder && <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm font-semibold text-amber-800">첫 주문 승인 후 테이블 이용이 시작됩니다.</p>}

      <div aria-label="주문내역 보기" className="mt-4 grid grid-cols-2 rounded-xl bg-slate-200 p-1" role="tablist">
        <button aria-selected={viewMode === "aggregate"} className={`min-h-10 rounded-lg text-sm font-bold ${viewMode === "aggregate" ? "bg-white text-slate-900 shadow-sm" : "text-slate-600"}`} onClick={() => setViewMode("aggregate")} role="tab" type="button">집계</button>
        <button aria-selected={viewMode === "detail"} className={`min-h-10 rounded-lg text-sm font-bold ${viewMode === "detail" ? "bg-white text-slate-900 shadow-sm" : "text-slate-600"}`} onClick={() => setViewMode("detail")} role="tab" type="button">상세</button>
      </div>

      <section aria-label={viewMode === "aggregate" ? "메뉴별 주문 집계" : "주문 회차별 상세"} className="mt-3 space-y-3" role="tabpanel">
        {!payload && !error && <p className="rounded-xl bg-white p-5 text-center text-sm text-slate-500">주문내역을 불러오는 중입니다.</p>}
        {payload && viewMode === "aggregate" && (aggregateItems.length
          ? <ul className="divide-y divide-slate-200 rounded-2xl bg-white px-4 shadow-sm">{aggregateItems.map(item => <li className="flex items-center justify-between gap-3 py-4" key={item.menuId}>
              <span className="min-w-0 font-semibold">{item.itemName} <span className="tabular-nums">{item.qty}</span></span>
              <strong className="shrink-0 tabular-nums">{won(item.totalAmount)}</strong>
            </li>)}</ul>
          : <p className="rounded-xl bg-white p-5 text-center text-sm text-slate-500">표시할 주문 메뉴가 없습니다.</p>)}
        {payload && viewMode === "detail" && (orders.length
          ? orders.map((order, orderIndex) => <section className="rounded-2xl bg-white p-4 shadow-sm" key={order.qrOrderId}>
              <div className="flex items-center justify-between gap-3">
                <h2 className="font-extrabold">{orderIndex + 1}차 주문</h2>
                <time className="shrink-0 text-sm text-slate-500" dateTime={order.orderedAt}>{dateTime(order.orderedAt)}</time>
              </div>
              <p className={`mt-1 text-sm font-bold ${order.status === "REJECTED" ? "text-red-600" : order.status === "PENDING" ? "text-amber-700" : order.status === "ACCEPTED" ? "text-blue-700" : "text-slate-600"}`}>
                {order.status === "PENDING" ? "직원 확인 대기" : order.status === "ACCEPTED" ? "주문 접수" : order.status === "REJECTED" ? "직원 확인 필요" : "주문 취소"}
              </p>
              {order.status === "REJECTED" && order.note && <p className="mt-1 text-xs leading-5 text-red-600">{order.note}</p>}
              <ul className="mt-2 divide-y divide-slate-100">{items.filter(item => item.qrOrderId === order.qrOrderId).map(item => {
                const status = itemStatus(item, order, serverNow);
                return <li className="py-3" key={item.qrOrderItemId}>
                  <div className="flex items-start justify-between gap-3">
                    <span className="min-w-0 font-semibold">{item.itemName} <span className="tabular-nums">{item.qty}</span></span>
                    <strong className="shrink-0 tabular-nums">{won(item.totalAmount)}</strong>
                  </div>
                  {item.options.length > 0 && <p className="mt-1 text-xs leading-5 text-slate-500">{item.options.map(option => `${option.optionName}${option.qty > 1 ? ` ×${option.qty}` : ""}`).join(" · ")}</p>}
                  {status && <p className={`mt-1 text-xs font-semibold ${item.stage === "DONE" ? "text-emerald-700" : item.stage === "COOKING" ? "text-blue-700" : "text-slate-500"}`}>{status}</p>}
                </li>;
              })}</ul>
              <div className="flex justify-end border-t border-slate-100 pt-3 font-extrabold tabular-nums">{won(order.totalAmount)}</div>
            </section>)
          : <p className="rounded-xl bg-white p-5 text-center text-sm text-slate-500">표시할 주문 회차가 없습니다.</p>)}
      </section>
    </div>

    {payload?.canViewOrders ? <div className="mx-auto mt-5 grid max-w-2xl grid-cols-2 gap-2">
      <button className="min-h-12 rounded-xl bg-blue-700 px-3 text-sm font-extrabold text-white" onClick={() => router.push("/qrorder/order")} type="button">추가 주문</button>
      <button className="min-h-12 rounded-xl border border-blue-200 bg-white px-3 text-sm font-extrabold text-blue-700" onClick={openShare} type="button">QR 공유</button>
    </div> : canRetryOrder ? <div className="mx-auto mt-5 grid max-w-2xl grid-cols-2 gap-2">
      <button className="min-h-12 rounded-xl bg-blue-700 px-3 text-sm font-extrabold text-white" onClick={() => router.push("/qrorder/order")} type="button">추가 주문</button>
      <button className="min-h-12 rounded-xl border border-slate-200 bg-slate-100 px-3 text-sm font-bold text-slate-400" disabled type="button">QR 공유</button>
    </div> : null}

    {shareOpen && <div className="fixed inset-0 z-[90] flex items-end justify-center bg-slate-950/50 p-0 sm:items-center sm:p-4" onClick={() => setShareOpen(false)}>
      <section aria-labelledby="qr-share-title" aria-modal="true" className="max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-white p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-2xl sm:rounded-3xl" onClick={event => event.stopPropagation()} role="dialog">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-extrabold" id="qr-share-title">함께 주문하기</h2>
          <button aria-label="닫기" className="grid size-10 shrink-0 place-items-center rounded-full bg-slate-100 text-xl" onClick={() => setShareOpen(false)} type="button">×</button>
        </div>
        <p className="mt-1 text-sm text-slate-600">함께 주문할 사람에게 QR을 공유하세요.</p>
        <p className="mt-3 text-center text-sm font-bold text-slate-700">{payload?.tableNo ? `${payload.tableNo} 테이블` : "테이블 확인 중"}</p>
        {shareBusy && <p className="py-8 text-center text-sm text-slate-500">주문용 QR을 준비하고 있습니다.</p>}
        {shareError && <p className="mt-3 rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">{shareError}</p>}
        {invite && !inviteIsValid && <p className="mt-4 rounded-xl bg-amber-50 p-3 text-center text-sm text-amber-800">공유 QR이 만료되었습니다. QR 공유를 다시 눌러 새 링크를 준비해 주세요.</p>}
        {invite && inviteIsValid && <>
          <Image alt="함께 주문할 수 있는 QR 코드" className="mx-auto mt-3 size-64 max-w-full object-contain" height={280} src={invite.qrData} unoptimized width={280} />
          <p className="break-all rounded-lg bg-slate-50 p-3 text-xs text-slate-600">{invite.url}</p>
          <p className="mt-1 text-center text-xs text-slate-500">30분 동안 유효 · 만료 {dateTime(invite.expiresAt)}</p>
          {shareMessage && <p aria-live="polite" className="mt-2 text-center text-sm font-semibold text-emerald-700">{shareMessage}</p>}
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button className="min-h-12 rounded-xl bg-blue-700 px-3 text-sm font-bold text-white" onClick={() => void shareInvite()} type="button">공유</button>
            <button className="min-h-12 rounded-xl border border-blue-200 bg-white px-3 text-sm font-bold text-blue-700" onClick={() => void copyInvite()} type="button">링크 복사</button>
          </div>
        </>}
        <button className="mt-2 min-h-11 w-full rounded-xl bg-slate-100 font-bold text-slate-700" onClick={() => setShareOpen(false)} type="button">닫기</button>
      </section>
    </div>}
  </main>;
}
