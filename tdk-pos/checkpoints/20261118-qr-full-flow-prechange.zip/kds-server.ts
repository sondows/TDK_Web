﻿import "server-only";

import { randomUUID } from "node:crypto";
import type { PoolConnection, ResultSetHeader, RowDataPacket } from "mysql2/promise";
import { pool } from "@/db";
import { isQrMenuAddonGroupName } from "@/lib/qr-menu-addon-model";
import { attachKdsOrderBundleAddons, buildKdsOrderBundleKeys, buildKdsTableOrderBundleKeys, groupKdsPotDisplayRows } from "@/lib/kds-party-grouping";
import {
  buildKdsTaskDrafts, findKdsRecentMenuGroup, isKdsMenuEligible, kdsCookOptionSignature, needsNewCookingGroup, remainingKdsQuantity, transitionKdsState, transitionKdsLinkedAddonState,
  isKdsPostCookTimerMinutes, matchesKdsTableStartBatch, type KdsPostCookTimerMinutes, type KdsMember, type KdsMenuKind, type KdsState, type KdsStateSnapshot, type KdsTaskStatus,
  canAcceptKdsQueuedUndo, canRequestKdsTaskCompletionDuringStartWindow, DEFAULT_KDS_COMPLETION_COUNTDOWN_SECONDS,
  DEFAULT_KDS_ORDER_BUNDLE_SETTINGS, isKdsCompletionCountdownSeconds, isKdsStartUndoWindowMs,
  kdsCompletionCountdownMs, kdsStartUndoWindowMs, kdsTableCompletionFinalizeAtMs, KDS_WINDOW_MS,
  canCancelKdsTableCompletion, canFinalizeKdsTableCompletion, canRecoverKdsTableCompletionCancellation,
} from "@/lib/kds-model";

type IdRow = RowDataPacket & { orderId: number };
type CursorRow = RowDataPacket & { initialOrderId: number; lastOrderId: number };
type SourceRow = RowDataPacket & {
  itemId: number; parentItemId: number | null; menuId: number;
  itemType: "NORMAL" | "COMPONENT" | "SERVICE";
  kdsKind: KdsMenuKind; kdsGroupKey: string | null; kdsCompletionTimer: number; kdsSimpleCook: number; printOnKitchen: number; kdsVisible: number;
};
type TaskRow = RowDataPacket & {
  taskId: number; orderId: number; memberItems: string; kind: "POT" | "SOLO";
  compatibilityKey: string; completionTimer: number; status: KdsTaskStatus;
  cookingGroupId: number | null; cookingStartedAtMs: number | null; cookingCompletedAtMs: number | null;
  postCookTimerMinutes: number | null; postCookTimerStartedAtMs: number | null;
  previousState: string | null; changedAtMs: number | null; cancelAcknowledgedAtMs: number | null;
  sessionId: number; groupId: number | null; tableId: number | null; tableNo: string | null;
  sessionKind: "DINE_IN" | "TAKEOUT_WALK_IN" | "TAKEOUT_PHONE";
  displayName: string | null; orderStatus: string; sessionStatus: string; orderedAtMs: number; confirmedAtMs: number; orderNote: string | null;
};
type ItemRow = RowDataPacket & {
  itemId: number; parentItemId: number | null; itemName: string; qty: number; note: string | null;
  actualComponentQty: number | null; status: string; kdsVisible: number; kdsKind: KdsMenuKind;
  kdsGroupKey: string | null; kdsPostCookTimer: number;
};
type CancelRow = RowDataPacket & { itemId: number; cancelledQty: number };
type OptionRow = RowDataPacket & { itemId: number; optionName: string; qty: number; groupName?: string | null };
type GroupRow = RowDataPacket & { groupId: number; startedAtMs: number };
type MenuGroupCandidateRow = GroupRow & { lastStartAtMs: number; previousState: string | null };

const number = (value: number | string | null) => value === null ? null : Number(value);

type BundleTaskRow = RowDataPacket & {
  taskId: number; orderId: number; memberItems: string; kind: "POT" | "SOLO"; compatibilityKey: string;
  status: KdsTaskStatus; cookingGroupId: number | null; cookingStartedAtMs: number | null; cookingCompletedAtMs: number | null;
  previousState: string | null; changedAtMs: number | null; sessionId: number; groupId: number | null; tableId: number;
  sessionKind: "DINE_IN" | "TAKEOUT_WALK_IN" | "TAKEOUT_PHONE"; sessionStatus: string; orderStatus: string;
  orderedAtMs: number; confirmedAtMs: number;
};

/** Resolve active cross-session add-on tasks from persisted table/time/menu facts. Caller holds a transaction. */
async function linkedOrderBundleAddonTaskIds(connection: PoolConnection, potTaskId: number) {
  const [enabledRows] = await connection.query<Array<RowDataPacket & { settingKey: string; settingValue: string }>>(
    "SELECT setting_key AS settingKey,setting_value AS settingValue FROM system_settings WHERE setting_key IN ('kds_order_bundle_enabled','kds_order_bundle_minutes')",
  );
  const settings = new Map(enabledRows.map(row => [row.settingKey, row.settingValue]));
  const minutes = Number(settings.get("kds_order_bundle_minutes") ?? 3);
  if (settings.get("kds_order_bundle_enabled") !== "1" || !Number.isInteger(minutes) || minutes < 1 || minutes > 60) return [];

  const [rows] = await connection.query<BundleTaskRow[]>(`
    SELECT k.task_id AS taskId,k.order_id AS orderId,k.member_items AS memberItems,k.kind,k.compatibility_key AS compatibilityKey,
      k.status,k.cooking_group_id AS cookingGroupId,k.cooking_started_at_ms AS cookingStartedAtMs,
      k.cooking_completed_at_ms AS cookingCompletedAtMs,k.previous_state AS previousState,k.changed_at_ms AS changedAtMs,
      s.session_id AS sessionId,s.group_id AS groupId,s.table_id AS tableId,s.session_kind AS sessionKind,s.status AS sessionStatus,
      o.status AS orderStatus,ROUND(UNIX_TIMESTAMP(o.ordered_at)*1000) AS orderedAtMs,
      ROUND(UNIX_TIMESTAMP(COALESCE(o.accepted_at,o.ordered_at))*1000) AS confirmedAtMs
    FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
    INNER JOIN table_sessions s ON s.session_id=o.session_id
    WHERE s.table_id=(SELECT target_session.table_id FROM kds_tasks target INNER JOIN orders target_order ON target_order.order_id=target.order_id
      INNER JOIN table_sessions target_session ON target_session.session_id=target_order.session_id WHERE target.task_id=?)
      AND s.session_kind='DINE_IN' AND s.status='OPEN'
    ORDER BY confirmedAtMs,k.task_id FOR UPDATE`, [potTaskId]);
  const pot = rows.find(row => Number(row.taskId) === potTaskId);
  if (!pot || pot.kind !== "POT" || pot.sessionKind !== "DINE_IN" || pot.sessionStatus !== "OPEN") return [];
  const orderBundles = buildKdsTableOrderBundleKeys(rows.map(row => ({
    sessionId: Number(row.sessionId), tableId: Number(row.tableId), orderId: Number(row.orderId),
    groupId: row.groupId === null ? null : Number(row.groupId), sessionKind: row.sessionKind,
    orderedAtMs: Number(row.orderedAtMs), confirmedAtMs: Number(row.confirmedAtMs),
  })), minutes * 60_000);
  const potBundle = orderBundles.get(`${pot.tableId}:${pot.orderId}`);
  if (!potBundle) return [];

  const memberIds = [...new Set(rows.flatMap(row => (JSON.parse(row.memberItems) as KdsMember[]).map(member => member.itemId)))];
  if (!memberIds.length) return [];
  const [itemRows] = await connection.query<Array<RowDataPacket & {
    itemId: number; itemStatus: string; orderStatus: string; sessionStatus: string; kdsKind: KdsMenuKind;
    kdsGroupKey: string | null; kdsVisible: number; remaining: number;
  }>>(`
    SELECT oi.order_item_id AS itemId,oi.status AS itemStatus,o.status AS orderStatus,s.status AS sessionStatus,
      m.kds_kind AS kdsKind,m.kds_group_key AS kdsGroupKey,m.kds_visible AS kdsVisible,
      COALESCE(oi.actual_component_qty,oi.qty)-COALESCE(c.cancelled_qty,0) AS remaining
    FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id INNER JOIN orders o ON o.order_id=oi.order_id
    INNER JOIN table_sessions s ON s.session_id=o.session_id
    LEFT JOIN (SELECT order_item_id,SUM(cancelled_qty) AS cancelled_qty FROM order_item_cancellations
      WHERE order_item_id IN (?) GROUP BY order_item_id) c ON c.order_item_id=oi.order_item_id
    WHERE oi.order_item_id IN (?)`, [memberIds, memberIds]);
  const configById = new Map(itemRows.map(item => [Number(item.itemId), item]));
  const liveMember = (itemId: number) => {
    const item = configById.get(itemId);
    return Boolean(item && item.itemStatus !== "CANCELLED" && item.orderStatus !== "CANCELLED" &&
      item.sessionStatus === "OPEN" && item.kdsVisible && Number(item.remaining) > 0);
  };
  const addonTaskIds: number[] = [];
  for (const addon of rows) {
    if (addon.kind !== "SOLO" || Number(addon.taskId) === potTaskId || addon.orderStatus === "CANCELLED") continue;
    const addonBundle = orderBundles.get(`${addon.tableId}:${addon.orderId}`);
    if (!addonBundle || addonBundle !== potBundle || Number(pot.confirmedAtMs) > Number(addon.confirmedAtMs)) continue;
    const members = (JSON.parse(addon.memberItems) as KdsMember[]).filter(member => member.kind !== "COMPONENT");
    if (!members.length || members.some(member => member.simpleCook) || !members.every(member => liveMember(member.itemId) && configById.get(member.itemId)?.kdsKind === "ADDON")) continue;
    const groupKeys = [...new Set(members.map(member => configById.get(member.itemId)?.kdsGroupKey?.trim() || null))];
    if (groupKeys.length !== 1) continue;
    const groupKey = groupKeys[0];
    let candidates = rows.filter(candidate => candidate.kind === "POT" && candidate.tableId === addon.tableId &&
      candidate.sessionStatus === "OPEN" && candidate.orderStatus !== "CANCELLED" &&
      orderBundles.get(`${candidate.tableId}:${candidate.orderId}`) === addonBundle &&
      Number(candidate.confirmedAtMs) <= Number(addon.confirmedAtMs) &&
      (addon.status === "DONE"
        ? candidate.status === "DONE" && candidate.cookingCompletedAtMs !== null &&
          Number(candidate.cookingCompletedAtMs) >= Number(addon.confirmedAtMs) &&
          addon.cookingCompletedAtMs !== null && Number(candidate.cookingCompletedAtMs) >= Number(addon.cookingCompletedAtMs)
        : candidate.status !== "DONE") &&
      (JSON.parse(candidate.memberItems) as KdsMember[]).some(member => member.kind !== "COMPONENT" && liveMember(member.itemId)));
    if (groupKey !== null) candidates = candidates.filter(candidate => candidate.compatibilityKey === groupKey);
    else {
      candidates = candidates.some(candidate => candidate.compatibilityKey === "POT")
        ? candidates.filter(candidate => candidate.compatibilityKey === "POT")
        : new Set(candidates.map(candidate => candidate.compatibilityKey)).size === 1 ? candidates : [];
    }
    if (candidates.length === 1 && Number(candidates[0].taskId) === potTaskId) addonTaskIds.push(Number(addon.taskId));
  }
  return addonTaskIds;
}

async function materializeOrder(connection: PoolConnection, orderId: number) {
  const [items] = await connection.query<SourceRow[]>(`
    SELECT oi.order_item_id AS itemId, oi.parent_order_item_id AS parentItemId,
      oi.menu_id AS menuId, oi.item_type AS itemType, m.kds_kind AS kdsKind,
      m.kds_group_key AS kdsGroupKey, m.kds_completion_timer AS kdsCompletionTimer,
      m.kds_simple_cook AS kdsSimpleCook,
      m.kds_visible AS kdsVisible,
      CASE WHEN oi.item_type='COMPONENT' THEN COALESCE(mc.print_on_kitchen,1) ELSE 1 END AS printOnKitchen
    FROM order_items oi
    INNER JOIN menus m ON m.menu_id=oi.menu_id
    LEFT JOIN order_items parent ON parent.order_item_id=oi.parent_order_item_id
    LEFT JOIN menu_components mc ON mc.parent_menu_id=parent.menu_id AND mc.component_menu_id=oi.menu_id
    WHERE oi.order_id=? ORDER BY oi.order_item_id`, [orderId]);
  const itemIds = items.map(item => Number(item.itemId));
  const optionsByItem = new Map<number, string[]>();
  if (itemIds.length) {
    const [options] = await connection.query<OptionRow[]>(
      "SELECT order_item_id AS itemId,option_name AS optionName,qty FROM order_item_options WHERE order_item_id IN (?) ORDER BY order_item_id,modifier_option_id",
      [itemIds],
    );
    for (const option of options) optionsByItem.set(Number(option.itemId), [...(optionsByItem.get(Number(option.itemId)) ?? []), option.optionName]);
  }
  for (const task of buildKdsTaskDrafts(orderId, items.map(item => ({
    itemId: Number(item.itemId), parentItemId: number(item.parentItemId),
    menuId: Number(item.menuId), itemType: item.itemType, kdsKind: item.kdsKind,
    kdsGroupKey: item.kdsGroupKey, kdsCompletionTimer: Boolean(item.kdsCompletionTimer), kdsSimpleCook: Boolean(item.kdsSimpleCook),
    printOnKitchen: Boolean(item.printOnKitchen), kdsVisible: Boolean(item.kdsVisible),
    cookOptionSignature: kdsCookOptionSignature((optionsByItem.get(Number(item.itemId)) ?? []).map(name => ({ name }))),
  })))) {
    await connection.execute(
      "INSERT IGNORE INTO kds_tasks (order_id,task_key,member_items,kind,compatibility_key,completion_timer) VALUES (?,?,?,?,?,?)",
      [task.orderId, task.taskKey, JSON.stringify(task.members), task.kind, task.compatibilityKey, Number(task.completionTimer)],
    );
  }
}

/** The cursor is locked across tablets. Open sessions at deployment are backfilled safely. */
export async function syncKdsOrders() {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [cursors] = await connection.query<CursorRow[]>(
      "SELECT initial_order_id AS initialOrderId,last_order_id AS lastOrderId FROM kds_sync_cursor WHERE cursor_id=1 FOR UPDATE",
    );
    const cursor = cursors[0];
    if (!cursor) throw new Error("KDS migration is missing");
    const [newOrders] = await connection.query<IdRow[]>(
      // Recheck a small overlap: an order with a lower auto ID can commit
      // after a later order and would otherwise be skipped by the cursor.
      `SELECT o.order_id AS orderId FROM orders o
       INNER JOIN table_sessions s ON s.session_id=o.session_id
       WHERE o.order_id>? AND s.status='OPEN'
         AND NOT EXISTS (SELECT 1 FROM kds_tasks k WHERE k.order_id=o.order_id)
         AND EXISTS (SELECT 1 FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id
           WHERE oi.order_id=o.order_id AND oi.parent_order_item_id IS NULL AND m.kds_kind<>'NONE' AND m.kds_visible=1)
       ORDER BY o.order_id LIMIT 250`,
      [Math.max(Number(cursor.initialOrderId), Number(cursor.lastOrderId) - 100)],
    );
    const [openOldOrders] = await connection.query<IdRow[]>(`
      SELECT o.order_id AS orderId FROM orders o
      INNER JOIN table_sessions s ON s.session_id=o.session_id
      WHERE s.status='OPEN' AND o.order_id<=? AND o.status IN ('ACCEPTED','OPEN','COMPLETED')
        AND NOT EXISTS (SELECT 1 FROM kds_tasks k WHERE k.order_id=o.order_id)
        AND EXISTS (SELECT 1 FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id
          WHERE oi.order_id=o.order_id AND oi.parent_order_item_id IS NULL AND m.kds_kind<>'NONE' AND m.kds_visible=1)
      ORDER BY o.order_id`, [cursor.initialOrderId]);
    for (const orderId of new Set([...openOldOrders, ...newOrders].map(row => Number(row.orderId)))) {
      await materializeOrder(connection, orderId);
    }
    // A newly materialized cross-session add-on may arrive while its unique pot
    // is already cooking. Start that SOLO task in the same persisted state so
    // it never remains hidden as WAITING behind the pot's single status button.
    const [cookingPots] = await connection.query<Array<RowDataPacket & { taskId: number }>>(
      "SELECT task_id AS taskId FROM kds_tasks WHERE kind='POT' AND status='COOKING' ORDER BY task_id FOR UPDATE",
    );
    for (const { taskId: rawPotId } of cookingPots) {
      const potTaskId = Number(rawPotId);
      const pot = await lockCompletionTask(connection, potTaskId);
      if (!pot || pendingCompletion(parseKdsPreviousState(pot.previousState))) continue;
      for (const addonId of await linkedOrderBundleAddonTaskIds(connection, potTaskId)) {
        const addon = await lockCompletionTask(connection, addonId);
        if (!addon || addon.status !== "WAITING" || pendingCompletion(parseKdsPreviousState(addon.previousState))) continue;
        const state = completionState(addon);
        const startedAt = Math.max(Date.now(), (state.changedAtMs ?? 0) + 1);
        const next = transitionKdsLinkedAddonState(state, "START", startedAt);
        if (!next || next.status !== "COOKING" || !next.previousState) continue;
        const previous = { ...next.previousState, startSource: "MENU" as const } as KdsPreviousState;
        const [updated] = await connection.execute<ResultSetHeader>(`UPDATE kds_tasks SET status='COOKING',cooking_group_id=?,
          cooking_started_at_ms=?,cooking_completed_at_ms=NULL,previous_state=?,changed_at_ms=?,
          post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL WHERE task_id=? AND status='WAITING' AND changed_at_ms <=> ?`,
        [next.cookingGroupId, next.cookingStartedAtMs, JSON.stringify(previous), next.changedAtMs, addon.taskId, addon.changedAtMs]);
        if (updated.affectedRows !== 1) throw new KdsActionError("Linked add-on changed during order synchronization.", 409);
      }
    }
    let nextCursor = Number(newOrders.at(-1)?.orderId ?? cursor.lastOrderId);
    if (newOrders.length < 250) {
      const [latestRows] = await connection.query<(RowDataPacket & { latestId: number })[]>(
        "SELECT COALESCE(MAX(order_id),0) AS latestId FROM orders",
      );
      nextCursor = Number(latestRows[0]?.latestId ?? nextCursor);
    }
    if (nextCursor > Number(cursor.lastOrderId)) await connection.execute(
      "UPDATE kds_sync_cursor SET last_order_id=? WHERE cursor_id=1", [nextCursor],
    );
    await connection.commit();
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export type KdsViewTask = {
  taskId: number; orderId: number; sessionId: number; tableId: number | null; groupId: number | null;
  label: string; sessionKind: TaskRow["sessionKind"]; orderedAtMs: number; confirmedAtMs: number; orderBundleKey: string | null;
  kind: "POT" | "SOLO"; compatibilityKey: string; cookSignature: string; status: KdsTaskStatus; completionTimer: boolean;
  simpleCook: boolean; simpleCookUndoUntilMs: number | null;
  postCookTimerEligible: boolean; postCookTimerMinutes: KdsPostCookTimerMinutes | null; postCookTimerStartedAtMs: number | null;
  completionRequestedAtMs: number | null; completionRequestId: string | null; completionRequestScope: "TASK" | "TABLE" | null;
  completionRequestCommand: "TABLE_DOUBLE_CLICK" | null;
  completionCountdownSeconds: number | null;
  pendingPostCookTimerMinutes: KdsPostCookTimerMinutes | null;
  startedAtMs: number | null; completedAtMs: number | null; changedAtMs: number | null;
  previousStatus: KdsTaskStatus | null; bulkStartId: string | null;
  startSource: "MENU" | "STATUS" | "TABLE" | null;
  startUndoWindowMs: number | null;
  cancelled: boolean; partiallyCancelled: boolean;
  orderNote: string | null;
  displayOnlyAsAddon?: boolean;
  displayAddonTaskIds?: number[];
  displayAddonItems?: Array<{ itemId: number; name: string; qty: number; kind: "ADDON"; kdsKind: "ADDON";
    kdsGroupKey: string | null; completionTimer: boolean; note: string | null; options: Array<{ name: string; qty: number }> }>;
  items: Array<{ itemId: number; name: string; qty: number; kind: KdsMember["kind"]; kdsKind: KdsMenuKind; kdsGroupKey: string | null; completionTimer: boolean; note: string | null; options: Array<{ name: string; qty: number }> }>;
};

type KdsPreviousState = KdsStateSnapshot & {
  bulkStartId?: string;
  startSource?: "MENU" | "STATUS" | "TABLE";
  startUndoWindowMs?: number;
  completedTableRequest?: {
    requestId: string; sessionId: number; requestedAtMs: number; confirmedAtMs: number;
    expectedChangedAtMs: number | null; expectedTaskIds?: number[];
    command?: "TABLE_DOUBLE_CLICK";
  };
  completedTaskRequest?: { ownerTaskId: number; requestedAtMs: number };
  simpleCookCompletion?: { completedAtMs: number; previousState: string | null };
  completionRequest?: {
    requestedAtMs: number; postCookTimerMinutes: number | null; completionCountdownSeconds?: number; requestId?: string;
    scope?: "TASK" | "TABLE"; sessionId?: number; ownerTaskId?: number; expectedStatus?: KdsTaskStatus; expectedChangedAtMs?: number | null;
    expectedTaskIds?: number[];
    command?: "TABLE_DOUBLE_CLICK";
    doubleClickRestore?: {
      status: KdsTaskStatus; cookingGroupId: number | null; cookingStartedAtMs: number | null;
      cookingCompletedAtMs: number | null; changedAtMs: number | null; previousState: string | null;
      postCookTimerMinutes: number | null; postCookTimerStartedAtMs: number | null;
    };
  };
};

function parseKdsPreviousState(value: string | null): KdsPreviousState | null {
  if (!value) return null;
  try { return JSON.parse(value) as KdsPreviousState; } catch { return null; }
}

const pendingCompletion = (previous: KdsPreviousState | null) => previous?.completionRequest ?? null;
const stateSnapshotForKds = (state: KdsState): KdsStateSnapshot => ({
  status: state.status, cookingGroupId: state.cookingGroupId,
  cookingStartedAtMs: state.cookingStartedAtMs, cookingCompletedAtMs: state.cookingCompletedAtMs,
});

export async function listKdsTasks(bundleWindowMs = 0): Promise<KdsViewTask[]> {
  await finalizeExpiredKdsTaskCompletions();
  await cleanupUnusedKdsCookingGroups();
  const [tasks] = await pool.query<TaskRow[]>(`
    SELECT k.task_id AS taskId,k.order_id AS orderId,k.member_items AS memberItems,
      k.kind,k.compatibility_key AS compatibilityKey,k.completion_timer AS completionTimer,
      k.post_cook_timer_minutes AS postCookTimerMinutes,k.post_cook_timer_started_at_ms AS postCookTimerStartedAtMs,
      k.status,k.cooking_group_id AS cookingGroupId,k.cooking_started_at_ms AS cookingStartedAtMs,
      k.cooking_completed_at_ms AS cookingCompletedAtMs,k.previous_state AS previousState,
      k.changed_at_ms AS changedAtMs,k.cancel_acknowledged_at_ms AS cancelAcknowledgedAtMs,
      o.status AS orderStatus,o.note AS orderNote,ROUND(UNIX_TIMESTAMP(o.ordered_at)*1000) AS orderedAtMs,
      ROUND(UNIX_TIMESTAMP(COALESCE(o.accepted_at,o.ordered_at))*1000) AS confirmedAtMs,
      s.session_id AS sessionId,s.group_id AS groupId,s.table_id AS tableId,
      s.session_kind AS sessionKind,s.display_name AS displayName,s.status AS sessionStatus,
      dt.table_no AS tableNo
    FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
    INNER JOIN table_sessions s ON s.session_id=o.session_id
    LEFT JOIN dining_tables dt ON dt.table_id=s.table_id
    -- A POS COMPLETE commits orders.COMPLETED and table_sessions.CLOSED together.
    -- Keep the true kitchen status/timestamps; the closed session is the durable KDS exit record.
    WHERE s.status='OPEN'
    ORDER BY orderedAtMs,k.task_id`);
  if (!tasks.length) return [];
  const orderBundleKeys = bundleWindowMs > 0 ? buildKdsOrderBundleKeys(tasks.map(task => ({
    sessionId: Number(task.sessionId), tableId: number(task.tableId), orderId: Number(task.orderId),
    groupId: number(task.groupId), sessionKind: task.sessionKind,
    orderedAtMs: Number(task.orderedAtMs), confirmedAtMs: Number(task.confirmedAtMs),
  })), bundleWindowMs) : new Map<string, string>();
  const membersByTask = new Map<number, KdsMember[]>();
  const itemIds = new Set<number>();
  for (const task of tasks) {
    const members = JSON.parse(task.memberItems) as KdsMember[];
    membersByTask.set(Number(task.taskId), members);
    for (const member of members) itemIds.add(member.itemId);
  }
  const ids = [...itemIds];
  const [items, cancellations, options] = await Promise.all([
    pool.query<ItemRow[]>(`SELECT oi.order_item_id AS itemId,oi.parent_order_item_id AS parentItemId,
      oi.item_name AS itemName,oi.qty,oi.actual_component_qty AS actualComponentQty,oi.status,oi.note,
      m.kds_visible AS kdsVisible,m.kds_kind AS kdsKind,m.kds_group_key AS kdsGroupKey,
      m.kds_post_cook_timer AS kdsPostCookTimer
      FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id
      WHERE oi.order_item_id IN (?)`, [ids]).then(([rows]) => rows),
    pool.query<CancelRow[]>(`SELECT order_item_id AS itemId,SUM(cancelled_qty) AS cancelledQty
      FROM order_item_cancellations WHERE order_item_id IN (?) GROUP BY order_item_id`, [ids]).then(([rows]) => rows),
    pool.query<OptionRow[]>(`SELECT oio.order_item_id AS itemId,oio.option_name AS optionName,oio.qty,mg.pos_name AS groupName
      FROM order_item_options oio LEFT JOIN modifier_options mo ON mo.modifier_option_id=oio.modifier_option_id
      LEFT JOIN modifier_groups mg ON mg.modifier_group_id=mo.modifier_group_id
      WHERE oio.order_item_id IN (?) ORDER BY oio.order_item_id,oio.modifier_option_id`, [ids]).then(([rows]) => rows),
  ]);
  const itemById = new Map(items.map(item => [Number(item.itemId), item]));
  const cancelledById = new Map(cancellations.map(row => [Number(row.itemId), Number(row.cancelledQty)]));
  const optionsById = new Map<number, OptionRow[]>();
  for (const option of options) optionsById.set(Number(option.itemId), [...(optionsById.get(Number(option.itemId)) ?? []), option]);
  const result: KdsViewTask[] = [];
  for (const task of tasks) {
    const members = membersByTask.get(Number(task.taskId)) ?? [];
    const eligibleItem = (itemId: number) => {
      const item = itemById.get(itemId);
      return Boolean(item && isKdsMenuEligible({ kdsKind: item.kdsKind, kdsVisible: Boolean(item.kdsVisible) }));
    };
    const eligibleMember = (member: KdsMember) => {
      if (!eligibleItem(member.itemId)) return false;
      if (member.kind !== "COMPONENT") return true;
      const item = itemById.get(member.itemId);
      return item?.parentItemId !== null && item?.parentItemId !== undefined && eligibleItem(Number(item.parentItemId));
    };
    const parentQty = new Map<number, number>();
    for (const member of members) {
      if (member.kind === "COMPONENT") continue;
      const item = itemById.get(member.itemId);
      if (!item) continue;
      parentQty.set(member.itemId, remainingKdsQuantity(
        Number(item.actualComponentQty ?? item.qty), cancelledById.get(member.itemId) ?? 0,
        item.status === "CANCELLED" || task.orderStatus === "CANCELLED" || task.sessionStatus === "CANCELLED",
      ));
    }
    const active = members.flatMap(member => {
      const item = itemById.get(member.itemId);
      if (!item || !eligibleMember(member)) return [];
      const qty = member.kind === "COMPONENT"
        ? parentQty.get(Number(item.parentItemId)) ? remainingKdsQuantity(Number(item.actualComponentQty ?? item.qty), cancelledById.get(member.itemId) ?? 0, item.status === "CANCELLED") : 0
        : parentQty.get(member.itemId) ?? 0;
      if (!qty) return [];
      const originalQty = Number(item.actualComponentQty ?? item.qty);
      return [{ itemId: member.itemId, name: item.itemName, qty, kind: member.kind,
        kdsKind: item.kdsKind, kdsGroupKey: item.kdsGroupKey,
        // Older tasks have no member snapshot, so keep their persisted task-level setting.
        completionTimer: member.completionTimer ?? Boolean(task.completionTimer), note: item.note,
        options: (optionsById.get(member.itemId) ?? []).map(option => ({
          name: option.optionName, qty: isQrMenuAddonGroupName(option.groupName ?? "")
            ? Number(option.qty) : Math.round(Number(option.qty) * qty / Math.max(1, originalQty)),
        })).filter(option => option.qty > 0) }];
    });
    if (!members.some(member => member.kind !== "COMPONENT" && eligibleMember(member))) continue;
    const cancelled = !members.some(member => member.kind !== "COMPONENT" && eligibleMember(member) && (parentQty.get(member.itemId) ?? 0) > 0);
    if (cancelled && (task.status === "WAITING" || task.cancelAcknowledgedAtMs !== null)) continue;
    const displayItems = cancelled ? members.flatMap(member => {
      if (member.kind === "COMPONENT") return [];
      const item = itemById.get(member.itemId);
      return item && eligibleMember(member) ? [{ itemId: member.itemId, name: item.itemName, qty: Number(item.actualComponentQty ?? item.qty), kind: member.kind,
        kdsKind: item.kdsKind, kdsGroupKey: item.kdsGroupKey,
        completionTimer: member.completionTimer ?? Boolean(task.completionTimer), note: item.note, options: [] }] : [];
    }) : active;
    const previousState = parseKdsPreviousState(task.previousState);
    const completionRequest = pendingCompletion(previousState);
    const activePrimaryMembers = active.filter(item => item.kind !== "COMPONENT").map(item => members.find(member => member.itemId === item.itemId));
    const simpleCook = activePrimaryMembers.length > 0 && activePrimaryMembers.every(member => member?.simpleCook === true);
    result.push({
      taskId: Number(task.taskId), orderId: Number(task.orderId), sessionId: Number(task.sessionId),
      tableId: number(task.tableId), groupId: number(task.groupId),
      label: task.sessionKind === "DINE_IN" ? String(task.tableNo ?? task.tableId ?? "?") : task.displayName ?? (task.sessionKind === "TAKEOUT_PHONE" ? "전화포장" : "방문포장"),
      sessionKind: task.sessionKind, orderedAtMs: Number(task.orderedAtMs), confirmedAtMs: Number(task.confirmedAtMs),
      orderBundleKey: orderBundleKeys.get(`${task.tableId}:${task.orderId}`) ?? null, kind: task.kind,
      compatibilityKey: task.compatibilityKey,
      cookSignature: task.kind === "POT" ? kdsCookOptionSignature(active
        .filter(item => item.kind === "POT").flatMap(item => item.options.map(option => ({ name: option.name })))) : "",
      status: task.status, completionTimer: Boolean(task.completionTimer), simpleCook,
      simpleCookUndoUntilMs: previousState?.simpleCookCompletion ? previousState.simpleCookCompletion.completedAtMs + 3000 : null,
      postCookTimerEligible: !simpleCook && active.some(item => Boolean(itemById.get(item.itemId)?.kdsPostCookTimer)),
      postCookTimerMinutes: task.postCookTimerMinutes !== null && isKdsPostCookTimerMinutes(Number(task.postCookTimerMinutes)) ? Number(task.postCookTimerMinutes) as KdsPostCookTimerMinutes : null,
      postCookTimerStartedAtMs: number(task.postCookTimerStartedAtMs),
      completionRequestedAtMs: completionRequest?.requestedAtMs ?? null,
      completionRequestId: completionRequest?.requestId ?? null,
      completionRequestScope: completionRequest?.scope ?? (completionRequest ? "TASK" : null),
      completionRequestCommand: completionRequest?.command === "TABLE_DOUBLE_CLICK" ? "TABLE_DOUBLE_CLICK" : null,
      completionCountdownSeconds: completionRequest
        ? isKdsCompletionCountdownSeconds(completionRequest.completionCountdownSeconds)
          ? completionRequest.completionCountdownSeconds : DEFAULT_KDS_COMPLETION_COUNTDOWN_SECONDS
        : null,
      pendingPostCookTimerMinutes: completionRequest?.postCookTimerMinutes !== null && isKdsPostCookTimerMinutes(completionRequest?.postCookTimerMinutes)
        ? completionRequest.postCookTimerMinutes : null,
      orderNote: task.orderNote,
      startedAtMs: number(task.cookingStartedAtMs), completedAtMs: number(task.cookingCompletedAtMs),
      changedAtMs: number(task.changedAtMs),
      previousStatus: previousState?.status ?? null,
      bulkStartId: previousState?.bulkStartId ?? null,
      startSource: previousState?.startSource ?? null,
      startUndoWindowMs: isKdsStartUndoWindowMs(previousState?.startUndoWindowMs) ? previousState.startUndoWindowMs : null,
      cancelled,
      partiallyCancelled: !cancelled && members.some(member => eligibleMember(member) && ((cancelledById.get(member.itemId) ?? 0) > 0 || itemById.get(member.itemId)?.status === "CANCELLED")),
      items: displayItems,
    });
  }
  return result;
}

export class KdsActionError extends Error {
  constructor(message: string, readonly statusCode = 409, readonly details?: Record<string, unknown>) { super(message); }
}

type LockedTask = RowDataPacket & Pick<TaskRow,
  "taskId" | "memberItems" | "compatibilityKey" | "kind" | "status" | "cookingGroupId" |
  "cookingStartedAtMs" | "cookingCompletedAtMs" | "postCookTimerMinutes" | "postCookTimerStartedAtMs" | "previousState" | "changedAtMs" | "cancelAcknowledgedAtMs">;

export async function updateKdsTask(
  taskId: number, action: "MENU" | "STATUS" | "TIME" | "ACK",
  expected: { status: KdsTaskStatus; changedAtMs: number | null },
  postCookTimerMinutes?: KdsPostCookTimerMinutes,
  queuedUndoDelayMs?: number,
  startUndoWindowMs = kdsStartUndoWindowMs(),
) {
  if (!isKdsStartUndoWindowMs(startUndoWindowMs)) throw new KdsActionError("조리 시작 취소 시간이 올바르지 않습니다.", 400);
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    if (action === "MENU") await connection.query("SELECT mutex_id FROM kds_group_mutex WHERE mutex_id=1 FOR UPDATE");
    const [rows] = await connection.query<LockedTask[]>(`
      SELECT task_id AS taskId,member_items AS memberItems,compatibility_key AS compatibilityKey,kind,
        status,cooking_group_id AS cookingGroupId,cooking_started_at_ms AS cookingStartedAtMs,
        cooking_completed_at_ms AS cookingCompletedAtMs,post_cook_timer_minutes AS postCookTimerMinutes,
        post_cook_timer_started_at_ms AS postCookTimerStartedAtMs,previous_state AS previousState,
        changed_at_ms AS changedAtMs,cancel_acknowledged_at_ms AS cancelAcknowledgedAtMs
      FROM kds_tasks WHERE task_id=? FOR UPDATE`, [taskId]);
    const row = rows[0];
    if (!row) throw new KdsActionError("조리 작업을 찾을 수 없습니다.", 404);
    if (row.status !== expected.status || number(row.changedAtMs) !== expected.changedAtMs) {
      throw new KdsActionError("다른 주방 화면에서 먼저 변경했습니다. 최신 상태를 확인해 주세요.");
    }
    const linkedAddonIds = row.kind === "POT" ? await linkedOrderBundleAddonTaskIds(connection, taskId) : [];
    const linkedAddonRows: LockedTask[] = [];
    for (const addonId of linkedAddonIds) {
      const [addonRows] = await connection.query<LockedTask[]>(`SELECT task_id AS taskId,member_items AS memberItems,
        compatibility_key AS compatibilityKey,kind,status,cooking_group_id AS cookingGroupId,
        cooking_started_at_ms AS cookingStartedAtMs,cooking_completed_at_ms AS cookingCompletedAtMs,
        post_cook_timer_minutes AS postCookTimerMinutes,post_cook_timer_started_at_ms AS postCookTimerStartedAtMs,
        previous_state AS previousState,changed_at_ms AS changedAtMs,cancel_acknowledged_at_ms AS cancelAcknowledgedAtMs
        FROM kds_tasks WHERE task_id=? FOR UPDATE`, [addonId]);
      if (addonRows[0]) linkedAddonRows.push(addonRows[0]);
    }
    const members = JSON.parse(row.memberItems) as KdsMember[];
    const primaryIds = members.filter(member => member.kind !== "COMPONENT").map(member => member.itemId);
    const memberIds = members.map(member => member.itemId);
    if (!primaryIds.length) throw new KdsActionError("조리 항목을 찾을 수 없습니다.");
    if (members.some(member => member.kind !== "COMPONENT" && member.simpleCook === true)) {
      throw new KdsActionError("단순조리 메뉴는 일반 조리 상태 버튼으로 변경할 수 없습니다.");
    }
    const [activeRows] = await connection.query<RowDataPacket[]>(`
      SELECT oi.order_item_id AS itemId,oi.parent_order_item_id AS parentItemId,oi.status,
        m.kds_post_cook_timer AS kdsPostCookTimer,m.kds_kind AS kdsKind,m.kds_visible AS kdsVisible,
        COALESCE(oi.actual_component_qty,oi.qty)-COALESCE(c.cancelled_qty,0) AS remaining,
        o.status AS orderStatus,s.status AS sessionStatus
      FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id INNER JOIN orders o ON o.order_id=oi.order_id
      INNER JOIN table_sessions s ON s.session_id=o.session_id
      LEFT JOIN (SELECT order_item_id,SUM(cancelled_qty) AS cancelled_qty
        FROM order_item_cancellations WHERE order_item_id IN (?) GROUP BY order_item_id) c ON c.order_item_id=oi.order_item_id
      WHERE oi.order_item_id IN (?)`, [memberIds, memberIds]);
    if (activeRows.some(item => item.sessionStatus === "CLOSED")) {
      throw new KdsActionError("POS에서 종료된 주문입니다. 화면을 갱신해 주세요.");
    }
    const isActive = (item: RowDataPacket) => item.status !== "CANCELLED" && item.orderStatus !== "CANCELLED" && item.sessionStatus !== "CANCELLED" && Number(item.remaining) > 0;
    const activePrimaryIds = new Set(activeRows.filter(item => primaryIds.includes(Number(item.itemId)) && isActive(item)).map(item => Number(item.itemId)));
    const cancelled = activePrimaryIds.size === 0;
    const timerEligible = activeRows.some(item => Boolean(item.kdsPostCookTimer) &&
      isKdsMenuEligible({ kdsKind: item.kdsKind, kdsVisible: Boolean(item.kdsVisible) }) && isActive(item) &&
      (primaryIds.includes(Number(item.itemId)) || activePrimaryIds.has(Number(item.parentItemId))));
    if (action === "TIME" && row.status === "COOKING" && timerEligible && !isKdsPostCookTimerMinutes(postCookTimerMinutes)) {
      throw new KdsActionError("조리 후 타이머를 3분, 5분, 10분 중 선택해 주세요.", 400);
    }
    if (postCookTimerMinutes !== undefined && !(action === "TIME" && row.status === "COOKING" && timerEligible && isKdsPostCookTimerMinutes(postCookTimerMinutes))) {
      throw new KdsActionError("이 조리작업에는 조리 후 타이머를 설정할 수 없습니다.", 400);
    }
    const now = Date.now();
    if (action === "ACK") {
      if (!cancelled) throw new KdsActionError("취소된 주문이 아닙니다.");
      await connection.execute("UPDATE kds_tasks SET cancel_acknowledged_at_ms=? WHERE task_id=?", [now, taskId]);
      await connection.commit();
      return;
    }
    if (cancelled) throw new KdsActionError("POS에서 취소된 주문입니다. 취소 알림을 확인해 주세요.");
    const state: KdsState = {
      status: row.status, cookingGroupId: number(row.cookingGroupId),
      cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
      previousState: parseKdsPreviousState(row.previousState),
      changedAtMs: number(row.changedAtMs),
    };
    // The second tap may occur inside three seconds while the first POST is still in flight.
    // Permit only a short transport grace for that queued tap; the normal undo window is unchanged.
    const storedStartUndoWindowMs = isKdsStartUndoWindowMs(parseKdsPreviousState(row.previousState)?.startUndoWindowMs)
      ? parseKdsPreviousState(row.previousState)!.startUndoWindowMs! : startUndoWindowMs;
    const queuedUndo = (action === "MENU" || action === "STATUS") &&
      state.status === "COOKING" && state.previousState?.status === "WAITING" &&
      canAcceptKdsQueuedUndo(queuedUndoDelayMs, state.changedAtMs, now, storedStartUndoWindowMs);
    if (pendingCompletion(state.previousState)) {
      throw new KdsActionError("테이블 완료 카운트다운 중에는 상태를 변경할 수 없습니다.");
    }
    if ((action === "MENU" || action === "STATUS") && state.status === "COOKING" &&
      state.previousState?.status === "WAITING" && state.changedAtMs !== null && now >= state.changedAtMs &&
      (now - state.changedAtMs <= storedStartUndoWindowMs || queuedUndo)) {
      const startedFrom = parseKdsPreviousState(row.previousState)?.startSource;
      if (startedFrom === "TABLE" || (action === "MENU" && startedFrom !== "MENU") ||
        (action === "STATUS" && startedFrom && startedFrom !== "STATUS")) {
        throw new KdsActionError("조리를 시작한 버튼에서만 3초 취소할 수 있습니다.");
      }
    }
    let newGroup: { groupId: number | null; startedAtMs: number } | undefined;
    let menuStartAtMs: number | null = null;
    if (action === "MENU" && needsNewCookingGroup(state)) {
      const groupNow = Date.now();
      menuStartAtMs = groupNow;
      const [groups] = await connection.query<MenuGroupCandidateRow[]>(`
        SELECT g.group_id AS groupId,g.started_at_ms AS startedAtMs,
          k.changed_at_ms AS lastStartAtMs,k.previous_state AS previousState
        FROM kds_tasks k INNER JOIN kds_cooking_groups g ON g.group_id=k.cooking_group_id
        WHERE k.status='COOKING' AND k.changed_at_ms>=?
        ORDER BY k.changed_at_ms DESC,k.task_id DESC`, [groupNow - KDS_WINDOW_MS]);
      const recentGroup = findKdsRecentMenuGroup(groups.map(candidate => {
        const previous = parseKdsPreviousState(candidate.previousState);
        return {
          groupId: Number(candidate.groupId), startedAtMs: Number(candidate.startedAtMs),
          lastStartAtMs: Number(candidate.lastStartAtMs), startSource: previous?.startSource ?? null,
          previousStatus: previous?.status ?? null, completionPending: Boolean(pendingCompletion(previous)),
        };
      }), groupNow);
      if (recentGroup) {
        newGroup = { groupId: recentGroup.groupId, startedAtMs: recentGroup.startedAtMs };
      }
      if (!newGroup) {
        const [insert] = await connection.execute<ResultSetHeader>(
          "INSERT INTO kds_cooking_groups (compatibility_key,started_at_ms) VALUES (?,?)",
          [row.compatibilityKey, groupNow],
        );
        newGroup = { groupId: insert.insertId, startedAtMs: groupNow };
      }
    }
    if (action === "STATUS" && needsNewCookingGroup(state)) {
      newGroup = { groupId: null, startedAtMs: now };
    }
    const transitionAt = Math.max(menuStartAtMs ?? now, (state.changedAtMs ?? 0) + 1);
    const next = transitionKdsState(state, action === "STATUS" ? "MENU" : action, transitionAt, newGroup,
      queuedUndo, storedStartUndoWindowMs);
    if (!next) throw new KdsActionError("현재 상태에서는 해당 조작을 할 수 없습니다. 화면을 갱신해 주세요.");
    const persistedPreviousState = next.status === "COOKING" && row.status === "WAITING" && next.previousState
      ? { ...next.previousState, startSource: action === "STATUS" ? "STATUS" as const : "MENU" as const,
          startUndoWindowMs }
      : next.previousState;
    await connection.execute(`
      UPDATE kds_tasks SET status=?,cooking_group_id=?,cooking_started_at_ms=?,
        cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,post_cook_timer_minutes=?,post_cook_timer_started_at_ms=? WHERE task_id=?`,
      [next.status, next.cookingGroupId, next.cookingStartedAtMs,
        next.cookingCompletedAtMs, JSON.stringify(persistedPreviousState), next.changedAtMs,
        next.status === "DONE" && row.status === "COOKING" && timerEligible ? postCookTimerMinutes ?? null : null,
        next.status === "DONE" && row.status === "COOKING" && timerEligible ? next.cookingCompletedAtMs : null, taskId]);
    // Cross-session add-ons retain their own task/order/item IDs, but follow an
    // unambiguous pot's state transitions in the same transaction.
    for (const addon of linkedAddonRows) {
      const addonState = completionState(addon);
      if (pendingCompletion(addonState.previousState)) throw new KdsActionError("A linked add-on has a pending completion request.", 409);
      let addonNext: KdsState | null = null;
      if (next.status === "COOKING" && state.status === "WAITING" && addon.status === "WAITING") {
        addonNext = transitionKdsLinkedAddonState(addonState, "START", transitionAt);
      } else if (next.status === "WAITING" && state.status === "COOKING" && addon.status === "COOKING" &&
        addon.changedAtMs === state.changedAtMs && addonState.previousState?.status === "WAITING" && !pendingCompletion(addonState.previousState)) {
        addonNext = transitionKdsLinkedAddonState(addonState, "UNDO_START", transitionAt, storedStartUndoWindowMs);
      } else if (next.status === "COOKING" && state.status === "DONE" && addon.status === "DONE" &&
        addon.changedAtMs === state.changedAtMs && addonState.previousState?.status === "COOKING") {
        addonNext = transitionKdsLinkedAddonState(addonState, "UNDO_COMPLETE", transitionAt);
      } else if (next.status === "DONE" && state.status === "COOKING" && addon.status === "COOKING") {
        addonNext = transitionKdsLinkedAddonState(addonState, "COMPLETE", transitionAt);
      }
      if (!addonNext || addonNext.status === addon.status) continue;
      const addonPrevious = addonNext.status === "COOKING" && addon.status === "WAITING" && addonNext.previousState
        ? { ...addonNext.previousState, startSource: "MENU" as const, startUndoWindowMs } : addonNext.previousState;
      const addonEligibility = addonNext.status === "DONE" ? await taskCookingEligibility(connection, addon.memberItems) : null;
      if (addonEligibility?.timerEligible && !isKdsPostCookTimerMinutes(postCookTimerMinutes)) {
        throw new KdsActionError("A cooking timer is required for the linked add-on.", 409);
      }
      const [addonResult] = await connection.execute<ResultSetHeader>(`UPDATE kds_tasks SET status=?,cooking_group_id=?,cooking_started_at_ms=?,cooking_completed_at_ms=?,
        previous_state=?,changed_at_ms=?,post_cook_timer_minutes=?,post_cook_timer_started_at_ms=? WHERE task_id=? AND status=? AND changed_at_ms <=> ?`,
      [addonNext.status, addonNext.cookingGroupId, addonNext.cookingStartedAtMs, addonNext.cookingCompletedAtMs,
        JSON.stringify(addonPrevious), addonNext.changedAtMs,
        addonNext.status === "DONE" && addonEligibility?.timerEligible ? postCookTimerMinutes ?? null : null,
        addonNext.status === "DONE" && addonEligibility?.timerEligible ? addonNext.cookingCompletedAtMs : null,
        addon.taskId, addon.status, addon.changedAtMs]);
      if (addonResult.affectedRows !== 1) throw new KdsActionError("Linked add-on changed before state synchronization completed.", 409);
    }
    await connection.commit();
    return { status: next.status, changedAtMs: next.changedAtMs, startedAtMs: next.cookingStartedAtMs,
      startUndoWindowMs: next.status === "COOKING" && row.status === "WAITING" ? startUndoWindowMs : null };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

type CompletionLockedTask = RowDataPacket & {
  taskId: number; orderId: number; memberItems: string; kind: "POT" | "SOLO"; compatibilityKey: string; status: KdsTaskStatus; cookingGroupId: number | null;
  cookingStartedAtMs: number | null; cookingCompletedAtMs: number | null; previousState: string | null;
  changedAtMs: number | null; postCookTimerMinutes?: number | null; postCookTimerStartedAtMs?: number | null;
};

async function taskCookingEligibility(connection: PoolConnection, memberItems: string) {
  const members = JSON.parse(memberItems) as KdsMember[];
  const primaryIds = members.filter(member => member.kind !== "COMPONENT").map(member => member.itemId);
  const ids = members.map(member => member.itemId);
  if (!ids.length) return { hasActivePrimary: false, timerEligible: false };
  const [rows] = await connection.query<Array<RowDataPacket & {
    itemId: number; parentItemId: number | null; timerEligible: number; kdsKind: KdsMenuKind; kdsVisible: number;
    itemStatus: string; remaining: number; orderStatus: string; sessionStatus: string;
  }>>(`
    SELECT oi.order_item_id AS itemId,oi.parent_order_item_id AS parentItemId,m.kds_post_cook_timer AS timerEligible,
      m.kds_kind AS kdsKind,m.kds_visible AS kdsVisible,oi.status AS itemStatus,
      COALESCE(oi.actual_component_qty,oi.qty)-COALESCE(c.cancelled_qty,0) AS remaining,
      o.status AS orderStatus,s.status AS sessionStatus
    FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id
    INNER JOIN orders o ON o.order_id=oi.order_id INNER JOIN table_sessions s ON s.session_id=o.session_id
    LEFT JOIN (SELECT order_item_id,SUM(cancelled_qty) AS cancelled_qty
      FROM order_item_cancellations WHERE order_item_id IN (?) GROUP BY order_item_id) c ON c.order_item_id=oi.order_item_id
    WHERE oi.order_item_id IN (?)`, [ids, ids]);
  const active = (row: typeof rows[number]) => row.itemStatus !== "CANCELLED" && row.orderStatus !== "CANCELLED" &&
    row.sessionStatus === "OPEN" && row.kdsKind !== "NONE" && Boolean(row.kdsVisible) && Number(row.remaining) > 0;
  const activePrimaryIds = new Set(rows.filter(row => primaryIds.includes(Number(row.itemId)) && active(row)).map(row => Number(row.itemId)));
  return {
    hasActivePrimary: activePrimaryIds.size > 0,
    timerEligible: rows.some(row => Boolean(row.timerEligible) && active(row) &&
      (primaryIds.includes(Number(row.itemId)) || activePrimaryIds.has(Number(row.parentItemId)))),
  };
}

async function lockCompletionTask(connection: PoolConnection, taskId: number) {
  const [rows] = await connection.query<CompletionLockedTask[]>(`
    SELECT task_id AS taskId,member_items AS memberItems,status,cooking_group_id AS cookingGroupId,
      cooking_started_at_ms AS cookingStartedAtMs,cooking_completed_at_ms AS cookingCompletedAtMs,
      previous_state AS previousState,changed_at_ms AS changedAtMs
    FROM kds_tasks WHERE task_id=? FOR UPDATE`, [taskId]);
  return rows[0] ?? null;
}

function completionState(row: Pick<CompletionLockedTask,
  "status" | "cookingGroupId" | "cookingStartedAtMs" | "cookingCompletedAtMs" | "previousState" | "changedAtMs">): KdsState {
  return {
    status: row.status, cookingGroupId: number(row.cookingGroupId),
    cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
    previousState: parseKdsPreviousState(row.previousState), changedAtMs: number(row.changedAtMs),
  };
}

export async function toggleSimpleCookTaskCompletion(taskId: number, expected: { status: KdsTaskStatus; changedAtMs: number | null }) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [owners] = await connection.query<Array<RowDataPacket & { sessionId: number }>>(
      "SELECT o.session_id AS sessionId FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id WHERE k.task_id=?", [taskId],
    );
    if (!owners[0]) throw new KdsActionError("조리 작업을 찾을 수 없습니다.", 404);
    const [sessions] = await connection.query<Array<RowDataPacket & { status: string }>>(
      "SELECT status FROM table_sessions WHERE session_id=? FOR UPDATE", [owners[0].sessionId],
    );
    if (sessions[0]?.status !== "OPEN") throw new KdsActionError("POS에서 종료된 주문입니다. 화면을 갱신해 주세요.");
    const row = await lockCompletionTask(connection, taskId);
    if (!row || row.status !== expected.status || number(row.changedAtMs) !== expected.changedAtMs) {
      throw new KdsActionError("조리 상태가 변경되었습니다. 화면을 새로고침해 주세요.");
    }
    const previous = parseKdsPreviousState(row.previousState);
    if (row.status === "DONE") {
      const completion = previous?.simpleCookCompletion;
      const now = Date.now();
      if (!completion || now < completion.completedAtMs || now - completion.completedAtMs > 3000) {
        throw new KdsActionError("단순조리 완료 취소 가능 시간이 지났습니다.");
      }
      const [updated] = await connection.execute<ResultSetHeader>(`
        UPDATE kds_tasks SET status='WAITING',cooking_group_id=NULL,cooking_started_at_ms=NULL,
          cooking_completed_at_ms=NULL,previous_state=?,changed_at_ms=?,
          post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL
        WHERE task_id=? AND status='DONE' AND changed_at_ms <=> ?`,
      [completion.previousState, now, taskId, expected.changedAtMs]);
      if (updated.affectedRows !== 1) throw new KdsActionError("조리 상태가 변경되었습니다. 화면을 새로고침해 주세요.");
      await connection.commit();
      return { status: "WAITING" as const, changedAtMs: now, completedAtMs: null, undone: true };
    }
    if (row.status !== "WAITING" || row.previousState && pendingCompletion(previous)) {
      throw new KdsActionError("현재 상태에서는 단순조리를 완료할 수 없습니다.");
    }
    const members = JSON.parse(row.memberItems) as KdsMember[];
    const primaryIds = members.filter(member => member.kind !== "COMPONENT").map(member => member.itemId);
    if (!primaryIds.length || members.some(member => member.kind !== "COMPONENT" && member.simpleCook !== true)) {
      throw new KdsActionError("단순조리 메뉴만 즉시 완료할 수 있습니다.");
    }
    const [items] = await connection.query<Array<RowDataPacket & {
      itemId: number; itemStatus: string; orderStatus: string; sessionStatus: string;
      simpleCook: number; timer: number; kind: KdsMenuKind; visible: number; remaining: number;
    }>>(`
      SELECT oi.order_item_id AS itemId,oi.status AS itemStatus,o.status AS orderStatus,s.status AS sessionStatus,
        m.kds_simple_cook AS simpleCook,m.kds_post_cook_timer AS timer,m.kds_kind AS kind,m.kds_visible AS visible,
        COALESCE(oi.actual_component_qty,oi.qty)-COALESCE(c.cancelled_qty,0) AS remaining
      FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id
      INNER JOIN orders o ON o.order_id=oi.order_id INNER JOIN table_sessions s ON s.session_id=o.session_id
      LEFT JOIN (SELECT order_item_id,SUM(cancelled_qty) AS cancelled_qty FROM order_item_cancellations
        WHERE order_item_id IN (?) GROUP BY order_item_id) c ON c.order_item_id=oi.order_item_id
      WHERE oi.order_item_id IN (?)`, [members.map(member => member.itemId), members.map(member => member.itemId)]);
    const activePrimary = items.filter(item => primaryIds.includes(Number(item.itemId)) && item.itemStatus !== "CANCELLED" &&
      item.orderStatus !== "CANCELLED" && item.sessionStatus === "OPEN" && item.kind !== "NONE" && Boolean(item.visible) && Number(item.remaining) > 0);
    if (!activePrimary.length || activePrimary.some(item => !Boolean(item.simpleCook) || Boolean(item.timer))) {
      throw new KdsActionError("단순조리 설정이 변경되었거나 주문이 취소되었습니다. 화면을 새로고침해 주세요.");
    }
    const now = Date.now();
    const nextPreviousState = JSON.stringify({
      simpleCookCompletion: { completedAtMs: now, previousState: row.previousState },
    });
    const [updated] = await connection.execute<ResultSetHeader>(`
      UPDATE kds_tasks SET status='DONE',cooking_group_id=NULL,cooking_started_at_ms=NULL,
        cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,
        post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL
      WHERE task_id=? AND status='WAITING' AND changed_at_ms <=> ?`,
    [now, nextPreviousState, now, taskId, expected.changedAtMs]);
    if (updated.affectedRows !== 1) throw new KdsActionError("조리 상태가 변경되었습니다. 화면을 새로고침해 주세요.");
    await connection.commit();
    return { status: "DONE" as const, changedAtMs: now, completedAtMs: now, undone: false };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function requestKdsTaskCompletion(
  taskId: number,
  expected: { status: KdsTaskStatus; changedAtMs: number | null },
  postCookTimerMinutes?: KdsPostCookTimerMinutes,
  completionCountdownSeconds = DEFAULT_KDS_COMPLETION_COUNTDOWN_SECONDS,
  completionInputButton?: "MENU" | "STATUS",
) {
  if (!isKdsCompletionCountdownSeconds(completionCountdownSeconds)) throw new KdsActionError("완료 카운트다운은 1~30초 값이어야 합니다.", 400);
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const row = await lockCompletionTask(connection, taskId);
    if (!row || row.status !== expected.status || number(row.changedAtMs) !== expected.changedAtMs) {
      throw new KdsActionError("조리 상태가 바뀌었습니다. 화면을 새로고침해 주세요.");
    }
    if (row.status !== "COOKING") throw new KdsActionError("조리중인 메뉴만 완료 요청할 수 있습니다.");
    const now = Date.now();
    const state = completionState(row);
    const storedPreviousState = parseKdsPreviousState(row.previousState);
    const startUndoWindowMs = isKdsStartUndoWindowMs(storedPreviousState?.startUndoWindowMs)
      ? storedPreviousState.startUndoWindowMs : kdsStartUndoWindowMs(completionCountdownSeconds);
    if (state.previousState?.status === "WAITING" && state.changedAtMs !== null && now >= state.changedAtMs &&
      now - state.changedAtMs <= startUndoWindowMs &&
      !canRequestKdsTaskCompletionDuringStartWindow(storedPreviousState?.startSource ?? null, completionInputButton)) {
      throw new KdsActionError("조리 시작 취소 가능 시간에는 완료 요청을 시작할 수 없습니다.");
    }
    const previous = parseKdsPreviousState(row.previousState) ?? {
      status: row.status, cookingGroupId: number(row.cookingGroupId),
      cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
    };
    if (pendingCompletion(previous)) throw new KdsActionError("완료 요청이 이미 진행 중입니다.");
    const eligibility = await taskCookingEligibility(connection, row.memberItems);
    if (!eligibility.hasActivePrimary) throw new KdsActionError("POS에서 취소되었거나 종료된 주문입니다.");
    const linkedAddonIds = await linkedOrderBundleAddonTaskIds(connection, taskId);
    const linkedRows: CompletionLockedTask[] = [];
    for (const addonId of linkedAddonIds) {
      const addon = await lockCompletionTask(connection, addonId);
      if (!addon || (addon.status !== "WAITING" && addon.status !== "COOKING")) {
        throw new KdsActionError("Linked add-on task changed; refresh KDS.", 409);
      }
      linkedRows.push(addon);
    }
    const linkedStates = linkedRows.map(addon => ({ row: addon, state: completionState(addon) }));
    if (linkedStates.some(({ state }) => pendingCompletion(state.previousState))) {
      throw new KdsActionError("A linked add-on already has a completion request.", 409);
    }
    const timerEligible = eligibility.timerEligible;
    if (timerEligible && !isKdsPostCookTimerMinutes(postCookTimerMinutes)) {
      throw new KdsActionError("외부 끓임 시간을 선택해 주세요.", 400);
    }
    if (!timerEligible && postCookTimerMinutes !== undefined) throw new KdsActionError("이 메뉴에는 외부 끓임 시간을 지정할 수 없습니다.", 400);
    previous.completionRequest = {
      requestedAtMs: now, postCookTimerMinutes: timerEligible ? postCookTimerMinutes! : null,
      completionCountdownSeconds, ownerTaskId: taskId,
    };
    await connection.execute("UPDATE kds_tasks SET previous_state=? WHERE task_id=? AND status='COOKING'", [JSON.stringify(previous), taskId]);
    for (const { row: addon, state } of linkedStates) {
      let cooking = state;
      if (state.status === "WAITING") {
        const startedAt = Math.max(now, (state.changedAtMs ?? 0) + 1);
        cooking = transitionKdsLinkedAddonState(state, "START", startedAt) ?? state;
        if (cooking.status !== "COOKING" || !cooking.previousState) throw new KdsActionError("Could not synchronize linked add-on state.", 409);
        cooking.previousState = { ...cooking.previousState, startSource: "MENU" } as KdsPreviousState;
      }
      const addonEligibility = await taskCookingEligibility(connection, addon.memberItems);
      if (addonEligibility.timerEligible && !isKdsPostCookTimerMinutes(postCookTimerMinutes)) {
        throw new KdsActionError("A cooking timer is required for the linked add-on.", 409);
      }
      const addonPrevious = (cooking.previousState ?? {
        status: cooking.status, cookingGroupId: cooking.cookingGroupId,
        cookingStartedAtMs: cooking.cookingStartedAtMs, cookingCompletedAtMs: cooking.cookingCompletedAtMs,
      }) as KdsPreviousState;
      addonPrevious.completionRequest = {
        requestedAtMs: now, postCookTimerMinutes: addonEligibility.timerEligible ? postCookTimerMinutes! : null,
        completionCountdownSeconds, ownerTaskId: taskId,
      };
      const [addonResult] = await connection.execute<ResultSetHeader>(`UPDATE kds_tasks SET status=?,cooking_group_id=?,cooking_started_at_ms=?,cooking_completed_at_ms=?,
        previous_state=?,changed_at_ms=? WHERE task_id=? AND status=? AND changed_at_ms <=> ?`,
      [cooking.status, cooking.cookingGroupId, cooking.cookingStartedAtMs, cooking.cookingCompletedAtMs,
        JSON.stringify(addonPrevious), cooking.changedAtMs, addon.taskId, addon.status, addon.changedAtMs]);
      if (addonResult.affectedRows !== 1) throw new KdsActionError("Linked add-on changed before completion request was saved.", 409);
    }
    await connection.commit();
    return { requestedAtMs: now, completionCountdownSeconds };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function cancelKdsTaskCompletion(taskId: number, expectedRequestAtMs: number) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const row = await lockCompletionTask(connection, taskId);
    if (!row || row.status !== "COOKING") throw new KdsActionError("조리 상태가 이미 변경되었습니다.");
    const previous = parseKdsPreviousState(row.previousState);
    const request = pendingCompletion(previous);
    if (!previous || !request || request.requestedAtMs !== expectedRequestAtMs) {
      throw new KdsActionError("완료 요청 상태가 이미 변경되었습니다.");
    }
    if (request.scope === "TABLE") throw new KdsActionError("테이블 전체 완료는 테이블 번호 버튼으로 취소해야 합니다.");
    if (Date.now() >= request.requestedAtMs + kdsCompletionCountdownMs(request.completionCountdownSeconds)) {
      await connection.commit();
      return { cancelled: false, expired: true };
    }
    const linkedAddonIds = await linkedOrderBundleAddonTaskIds(connection, taskId);
    const linkedRows: CompletionLockedTask[] = [];
    for (const addonId of linkedAddonIds) {
      const addon = await lockCompletionTask(connection, addonId);
      if (!addon || addon.status !== "COOKING") throw new KdsActionError("Linked add-on task changed before cancellation.", 409);
      linkedRows.push(addon);
    }
    const linkedPrevious = linkedRows.map(addon => ({ row: addon, previous: parseKdsPreviousState(addon.previousState) }));
    if (linkedPrevious.some(({ previous: addonPrevious }) => {
      const addonRequest = pendingCompletion(addonPrevious);
      return addonRequest?.requestedAtMs !== expectedRequestAtMs ||
        (addonRequest.ownerTaskId !== undefined && addonRequest.ownerTaskId !== taskId);
    })) {
      throw new KdsActionError("Linked add-on completion request is inconsistent.", 409);
    }
    delete previous.completionRequest;
    await connection.execute("UPDATE kds_tasks SET previous_state=? WHERE task_id=? AND status='COOKING'", [JSON.stringify(previous), taskId]);
    for (const { row: addon, previous: addonPrevious } of linkedPrevious) {
      if (!addonPrevious) throw new KdsActionError("Linked add-on state history is missing.", 409);
      delete addonPrevious.completionRequest;
      await connection.execute("UPDATE kds_tasks SET previous_state=? WHERE task_id=? AND status='COOKING'", [JSON.stringify(addonPrevious), addon.taskId]);
    }
    await connection.commit();
    return { cancelled: true, expired: false };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function finalizeKdsTaskCompletion(taskId: number, expectedRequestAtMs?: number, immediate = false) {
  const [snapshots] = await pool.query<Array<RowDataPacket & { status: KdsTaskStatus; previousState: string | null }>>(
    "SELECT status,previous_state AS previousState FROM kds_tasks WHERE task_id=?", [taskId],
  );
  const snapshot = snapshots[0];
  if (!snapshot) return false;
  const snapshotPrevious = parseKdsPreviousState(snapshot.previousState);
  const snapshotRequest = pendingCompletion(snapshotPrevious);
  if (snapshot.status === "DONE" && expectedRequestAtMs !== undefined &&
    snapshotPrevious?.completedTaskRequest?.requestedAtMs === expectedRequestAtMs) return true;
  if (snapshotRequest?.scope !== "TABLE" && snapshotRequest?.ownerTaskId !== undefined &&
    snapshotRequest.ownerTaskId !== taskId &&
    (expectedRequestAtMs === undefined || snapshotRequest.requestedAtMs === expectedRequestAtMs)) {
    return finalizeKdsTaskCompletion(snapshotRequest.ownerTaskId, snapshotRequest.requestedAtMs, immediate);
  }
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [taskSessions] = await connection.query<Array<RowDataPacket & { sessionId: number }>>(`
      SELECT o.session_id AS sessionId FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id WHERE k.task_id=?`, [taskId]);
    if (!taskSessions[0]) {
      await connection.commit();
      return false;
    }
    const [sessions] = await connection.query<Array<RowDataPacket & { status: string }>>(
      "SELECT status FROM table_sessions WHERE session_id=? FOR UPDATE", [taskSessions[0].sessionId]);
    if (sessions[0]?.status !== "OPEN") {
      await connection.commit();
      return false;
    }
    const row = await lockCompletionTask(connection, taskId);
    if (!row) {
      await connection.commit();
      return false;
    }
    const previous = parseKdsPreviousState(row.previousState);
    if (row.status === "DONE" && expectedRequestAtMs !== undefined &&
      previous?.completedTaskRequest?.requestedAtMs === expectedRequestAtMs) {
      await connection.commit();
      return true;
    }
    if (row.status !== "COOKING") {
      await connection.commit();
      return false;
    }
    const request = pendingCompletion(previous);
    if (!previous || !request || request.scope === "TABLE" ||
      (request.ownerTaskId !== undefined && request.ownerTaskId !== taskId) ||
      (expectedRequestAtMs !== undefined && request.requestedAtMs !== expectedRequestAtMs)) {
      await connection.commit();
      return false;
    }
    const linkedAddonIds = await linkedOrderBundleAddonTaskIds(connection, taskId);
    const linkedRows: CompletionLockedTask[] = [];
    for (const addonId of linkedAddonIds) {
      const addon = await lockCompletionTask(connection, addonId);
      if (!addon || addon.status !== "COOKING") { await connection.commit(); return false; }
      linkedRows.push(addon);
    }
    const linkedRequests = linkedRows.map(addon => ({ row: addon, previous: parseKdsPreviousState(addon.previousState), state: completionState(addon) }));
    if (linkedRequests.some(({ previous: addonPrevious }) => {
      const addonRequest = pendingCompletion(addonPrevious);
      return !addonRequest || addonRequest.requestedAtMs !== request.requestedAtMs ||
        addonRequest.completionCountdownSeconds !== request.completionCountdownSeconds ||
        (addonRequest.ownerTaskId !== undefined && addonRequest.ownerTaskId !== taskId);
    })) { await connection.commit(); return false; }
    const completedAt = Math.max(Date.now(), (number(row.changedAtMs) ?? 0) + 1,
      ...linkedRows.map(addon => (number(addon.changedAtMs) ?? 0) + 1));
    if (!immediate && completedAt < request.requestedAtMs + kdsCompletionCountdownMs(request.completionCountdownSeconds)) {
      await connection.commit();
      return false;
    }
    const eligibility = await taskCookingEligibility(connection, row.memberItems);
    if (!eligibility.hasActivePrimary) {
      await connection.commit();
      return false;
    }
    const timerEligible = eligibility.timerEligible;
    if (timerEligible && !isKdsPostCookTimerMinutes(request.postCookTimerMinutes)) {
      throw new KdsActionError("완료 시간 선택이 없어 완료하지 않았습니다.");
    }
    const state = completionState(row);
    const next = transitionKdsState(state, "TIME", Math.max(completedAt, (state.changedAtMs ?? 0) + 1));
    if (!next || next.status !== "DONE") {
      await connection.commit();
      return false;
    }
    const completedPreviousState: KdsPreviousState = {
      ...(next.previousState ?? stateSnapshotForKds(state)),
      completedTaskRequest: { ownerTaskId: taskId, requestedAtMs: request.requestedAtMs },
    };
    const timerMinutes = timerEligible ? request.postCookTimerMinutes : null;
    await connection.execute(`
      UPDATE kds_tasks SET status='DONE',cooking_group_id=?,cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,
        post_cook_timer_minutes=?,post_cook_timer_started_at_ms=? WHERE task_id=? AND status='COOKING'`,
    [next.cookingGroupId, next.cookingCompletedAtMs, JSON.stringify(completedPreviousState), next.changedAtMs,
      timerMinutes, timerEligible ? next.cookingCompletedAtMs : null, taskId]);
    for (const { row: addon, previous: addonPrevious, state: addonState } of linkedRequests) {
      const addonRequest = pendingCompletion(addonPrevious);
      const addonEligibility = await taskCookingEligibility(connection, addon.memberItems);
      if (!addonRequest || !addonEligibility.hasActivePrimary) throw new KdsActionError("Linked add-on is no longer eligible for completion.", 409);
      if (addonEligibility.timerEligible && !isKdsPostCookTimerMinutes(addonRequest.postCookTimerMinutes)) {
        throw new KdsActionError("Linked add-on completion timer is invalid.", 409);
      }
      const addonNext = transitionKdsLinkedAddonState(addonState, "COMPLETE", Math.max(completedAt, (addonState.changedAtMs ?? 0) + 1));
      if (!addonNext || addonNext.status !== "DONE") throw new KdsActionError("Linked add-on could not be completed atomically.", 409);
      const addonCompletedPreviousState: KdsPreviousState = {
        ...(addonNext.previousState ?? stateSnapshotForKds(addonState)),
        completedTaskRequest: { ownerTaskId: taskId, requestedAtMs: request.requestedAtMs },
      };
      const addonTimer = addonEligibility.timerEligible ? addonRequest.postCookTimerMinutes : null;
      const [addonResult] = await connection.execute<ResultSetHeader>(`UPDATE kds_tasks SET status='DONE',cooking_group_id=?,cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,
        post_cook_timer_minutes=?,post_cook_timer_started_at_ms=? WHERE task_id=? AND status='COOKING' AND changed_at_ms <=> ?`,
      [addonNext.cookingGroupId, completedAt, JSON.stringify(addonCompletedPreviousState), completedAt,
        addonTimer, addonTimer !== null ? completedAt : null, addon.taskId, addon.changedAtMs]);
      if (addonResult.affectedRows !== 1) throw new KdsActionError("Linked add-on changed before final completion committed.", 409);
    }
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function finalizeExpiredKdsTaskCompletions() {
  const [rows] = await pool.query<Array<RowDataPacket & { taskId: number; previousState: string | null }>>(
    "SELECT task_id AS taskId,previous_state AS previousState FROM kds_tasks",
  );
  const now = Date.now();
  // Table countdowns are finalized by the KDS client timer. Finalizing them
  // while serving a read can race a user's cancel tap against this request.
  for (const row of rows) {
    const request = pendingCompletion(parseKdsPreviousState(row.previousState));
    if (request?.scope === "TABLE") continue;
    if (request && now >= request.requestedAtMs + kdsCompletionCountdownMs(request.completionCountdownSeconds)) {
      try { await finalizeKdsTaskCompletion(Number(row.taskId), request.requestedAtMs); }
      catch (error) { console.error("KDS 완료 카운트다운 확정 실패:", error); }
    }
  }
}

type ExpectedTableTask = { taskId: number; status: KdsTaskStatus; changedAtMs: number | null };

type PotDisplaySourceRow = RowDataPacket & {
  taskId: number; orderId: number; memberItems: string; kind: "POT" | "SOLO"; compatibilityKey: string;
  status: KdsTaskStatus; cookingGroupId: number | null; cookingStartedAtMs: number | null; cookingCompletedAtMs: number | null;
  previousState: string | null; changedAtMs: number | null; sessionId: number; tableId: number;
  groupId: number | null; sessionKind: "DINE_IN" | "TAKEOUT_WALK_IN" | "TAKEOUT_PHONE";
  orderedAtMs: number; confirmedAtMs: number; orderStatus: string; sessionStatus: string;
};

/** Rebuild the same display rows as the KDS client before validating a pot action. */
async function kdsPotDisplayGroupsForSession(connection: PoolConnection, sessionId: number) {
  const [rows] = await connection.query<PotDisplaySourceRow[]>(`
    SELECT k.task_id AS taskId,k.order_id AS orderId,k.member_items AS memberItems,k.kind,
      k.compatibility_key AS compatibilityKey,k.status,k.cooking_group_id AS cookingGroupId,k.cooking_started_at_ms AS cookingStartedAtMs,
      k.cooking_completed_at_ms AS cookingCompletedAtMs,k.previous_state AS previousState,k.changed_at_ms AS changedAtMs,
      s.session_id AS sessionId,s.table_id AS tableId,s.group_id AS groupId,s.session_kind AS sessionKind,
      s.status AS sessionStatus,o.status AS orderStatus,
      ROUND(UNIX_TIMESTAMP(o.ordered_at)*1000) AS orderedAtMs,
      ROUND(UNIX_TIMESTAMP(COALESCE(o.accepted_at,o.ordered_at))*1000) AS confirmedAtMs
    FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
    INNER JOIN table_sessions s ON s.session_id=o.session_id
    WHERE s.status='OPEN' AND s.table_id=(SELECT table_id FROM table_sessions WHERE session_id=?)
    ORDER BY confirmedAtMs,k.task_id`, [sessionId]);
  if (!rows.length) return [];

  const activeItemIds = await getActivePrimaryTaskIds(connection, rows, false);
  const configByItem = await getKdsMenuConfigByItemIds(connection, rows);
  const itemIds = [...new Set(rows.flatMap(row => (JSON.parse(row.memberItems) as KdsMember[])
    .filter(member => member.kind !== "COMPONENT").map(member => member.itemId)))];
  const optionsByItem = new Map<number, string[]>();
  if (itemIds.length) {
    const [options] = await connection.query<OptionRow[]>(
      "SELECT order_item_id AS itemId,option_name AS optionName,qty FROM order_item_options WHERE order_item_id IN (?) ORDER BY order_item_id,modifier_option_id",
      [itemIds],
    );
    for (const option of options) optionsByItem.set(Number(option.itemId), [...(optionsByItem.get(Number(option.itemId)) ?? []), option.optionName]);
  }

  const [bundleSettingRows] = await connection.query<Array<RowDataPacket & { settingKey: string; settingValue: string }>>(
    "SELECT setting_key AS settingKey,setting_value AS settingValue FROM system_settings WHERE setting_key IN ('kds_order_bundle_enabled','kds_order_bundle_minutes')",
  );
  const bundleSettings = new Map(bundleSettingRows.map(row => [row.settingKey, row.settingValue]));
  const bundleMinutes = Number(bundleSettings.get("kds_order_bundle_minutes") ?? DEFAULT_KDS_ORDER_BUNDLE_SETTINGS.minutes);
  const bundleWindowMs = bundleSettings.get("kds_order_bundle_enabled") === "1" && Number.isInteger(bundleMinutes) && bundleMinutes >= 1 && bundleMinutes <= 60
    ? bundleMinutes * 60_000 : 0;
  const orderBundleKeys = bundleWindowMs > 0 ? buildKdsOrderBundleKeys(rows.map(row => ({
    sessionId: Number(row.sessionId), tableId: Number(row.tableId), orderId: Number(row.orderId),
    groupId: row.groupId === null ? null : Number(row.groupId), sessionKind: row.sessionKind,
    orderedAtMs: Number(row.orderedAtMs), confirmedAtMs: Number(row.confirmedAtMs),
  })), bundleWindowMs) : new Map<string, string>();

  const displayTasks = rows.map(row => {
    const members = JSON.parse(row.memberItems) as KdsMember[];
    const items = members.filter(member => member.kind !== "COMPONENT" && activeItemIds.has(member.itemId))
      .map(member => {
        const config = configByItem.get(member.itemId);
        return {
          itemId: member.itemId, name: String(member.itemId), qty: 1, kind: member.kind,
          kdsKind: config?.kdsKind ?? "NONE", kdsGroupKey: config?.kdsGroupKey ?? null,
          completionTimer: Boolean(member.completionTimer), note: null,
          options: (optionsByItem.get(member.itemId) ?? []).map(name => ({ name, qty: 1 })),
        };
      });
    const completion = pendingCompletion(parseKdsPreviousState(row.previousState));
    return {
      taskId: Number(row.taskId), orderId: Number(row.orderId), sessionId: Number(row.sessionId),
      tableId: Number(row.tableId), groupId: row.groupId === null ? null : Number(row.groupId),
      orderBundleKey: orderBundleKeys.get(`${row.tableId}:${row.orderId}`) ?? null,
      orderedAtMs: Number(row.orderedAtMs), confirmedAtMs: Number(row.confirmedAtMs), sessionKind: row.sessionKind,
      kind: row.kind, compatibilityKey: row.compatibilityKey,
      cookSignature: row.kind === "POT" ? kdsCookOptionSignature(items
        .filter(item => item.kind === "POT").flatMap(item => item.options.map(option => ({ name: option.name })))) : "",
      status: row.status, startedAtMs: number(row.cookingStartedAtMs), completedAtMs: number(row.cookingCompletedAtMs),
      changedAtMs: number(row.changedAtMs), completionRequestId: completion?.requestId ?? null,
      completionRequestScope: completion?.scope ?? null, completionRequestedAtMs: completion?.requestedAtMs ?? null,
      displayAddonTaskIds: [] as number[],
      cancelled: !items.some(item => item.kind !== "COMPONENT"), displayOnlyAsAddon: false,
      items,
    };
  });
  return groupKdsPotDisplayRows(attachKdsOrderBundleAddons(displayTasks, bundleWindowMs));
}

export async function requestKdsTableCompletion(
  sessionId: number,
  expected: ExpectedTableTask[],
  defaultPostCookTimerMinutes: KdsPostCookTimerMinutes,
  completionCountdownSeconds = DEFAULT_KDS_COMPLETION_COUNTDOWN_SECONDS,
  selectedPotTasks = false,
) {
  if (!isKdsPostCookTimerMinutes(defaultPostCookTimerMinutes)) throw new KdsActionError("기본 끓임 시간이 올바르지 않습니다.", 400);
  if (!isKdsCompletionCountdownSeconds(completionCountdownSeconds)) throw new KdsActionError("완료 카운트다운은 1~30초 값이어야 합니다.", 400);
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [sessions] = await connection.query<Array<RowDataPacket & { sessionKind: string; status: string; tableId: number | null }>>(
      "SELECT session_kind AS sessionKind,status,table_id AS tableId FROM table_sessions WHERE session_id=? FOR UPDATE", [sessionId]);
    const session = sessions[0];
    if (!session || session.sessionKind !== "DINE_IN" || session.status !== "OPEN" || session.tableId === null) {
      throw new KdsActionError("진행 중인 매장 테이블 주문만 전체 완료할 수 있습니다.");
    }
    const expectedById = new Map(expected.map(item => [item.taskId, item]));
    if (expectedById.size !== expected.length || expected.some(item => item.status === "DONE")) {
      throw new KdsActionError("테이블 작업 목록이 올바르지 않습니다.", 400);
    }
    const [rows] = await connection.query<CompletionLockedTask[]>(`
      SELECT k.task_id AS taskId,k.order_id AS orderId,k.member_items AS memberItems,k.kind,k.compatibility_key AS compatibilityKey,k.status,k.cooking_group_id AS cookingGroupId,
        k.cooking_started_at_ms AS cookingStartedAtMs,k.cooking_completed_at_ms AS cookingCompletedAtMs,
        k.previous_state AS previousState,k.changed_at_ms AS changedAtMs
      FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
      WHERE o.session_id=? AND k.status<>'DONE' ORDER BY k.task_id FOR UPDATE`, [sessionId]);
    const activeRows: Array<{ row: CompletionLockedTask; timerEligible: boolean }> = [];
    for (const row of rows) {
      if (row.status !== "COOKING") continue;
      const eligibility = await taskCookingEligibility(connection, row.memberItems);
      if (eligibility.hasActivePrimary) activeRows.push({ row, timerEligible: eligibility.timerEligible });
    }
    if (selectedPotTasks) {
      const selected = activeRows.filter(({ row }) => expectedById.has(Number(row.taskId)));
      const firstPot = selected.find(({ row }) => row.kind === "POT")?.row;
      const displayGroup = firstPot ? (await kdsPotDisplayGroupsForSession(connection, sessionId))
        .find(group => group.some(task => task.taskId === Number(firstPot.taskId))) : undefined;
      const selectedIds = selected.map(({ row }) => Number(row.taskId));
      const displayedTaskIds = displayGroup?.flatMap(task => [task.taskId, ...(task.displayAddonTaskIds ?? [])]) ?? [];
      if (!firstPot || selected.length !== expected.length || !displayGroup ||
        !matchesKdsTableStartBatch(selectedIds, displayedTaskIds)) {
        throw new KdsActionError("같은 냄비 조리 작업 목록이 변경되었습니다. 화면을 새로고침해 주세요.", 409, {
          expectedTaskIds: [...expectedById.keys()].sort((a, b) => a - b),
          actualTaskIds: displayedTaskIds.slice().sort((a, b) => a - b),
        });
      }
      activeRows.splice(0, activeRows.length, ...selected);
    }
    if (!activeRows.length || !activeRows.some(({ row }) => row.status === "COOKING")) {
      throw new KdsActionError("조리 중인 작업이 없어 테이블 전체 완료를 시작할 수 없습니다.");
    }
    if (activeRows.some(({ row }) => {
      const item = expectedById.get(Number(row.taskId));
      return !item || item.status !== row.status || item.changedAtMs !== number(row.changedAtMs);
    }) || expectedById.size !== activeRows.length) {
      throw new KdsActionError("테이블 주문 상태가 변경되었습니다. KDS 화면을 새로고침해 주세요.");
    }
    if (activeRows.some(({ row }) => pendingCompletion(parseKdsPreviousState(row.previousState)))) {
      throw new KdsActionError("개별 완료 카운트다운이 진행 중입니다. 먼저 해당 요청을 취소해 주세요.");
    }
    const requestedAtMs = Date.now();
    const requestId = randomUUID();
    const expectedTaskIds = activeRows.map(({ row }) => Number(row.taskId)).sort((a, b) => a - b);
    for (const { row, timerEligible } of activeRows) {
      const previous = parseKdsPreviousState(row.previousState) ?? {
        status: row.status, cookingGroupId: number(row.cookingGroupId),
        cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
      };
      previous.completionRequest = {
        scope: "TABLE", requestId, sessionId, requestedAtMs,
        completionCountdownSeconds,
        expectedStatus: row.status, expectedChangedAtMs: number(row.changedAtMs),
        expectedTaskIds,
        postCookTimerMinutes: timerEligible ? defaultPostCookTimerMinutes : null,
      };
      await connection.execute("UPDATE kds_tasks SET previous_state=? WHERE task_id=? AND status=? AND changed_at_ms <=> ?",
        [JSON.stringify(previous), row.taskId, row.status, row.changedAtMs]);
    }
    await connection.commit();
    return { requestId, requestedAtMs, taskCount: activeRows.length, completionCountdownSeconds };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

/**
 * A table-button double-click is one server transaction: WAITING tasks start,
 * already cooking tasks keep their start timestamps, and all active work gets
 * the same configured completion deadline. The request also captures the
 * exact pre-command state so a timely double-click cancellation can restore a
 * mixed WAITING/COOKING table without guessing from the optimistic client.
 */
export async function requestKdsTableDoubleClickCompletion(
  sessionId: number,
  expected: ExpectedTableTask[],
  defaultPostCookTimerMinutes: KdsPostCookTimerMinutes,
  completionCountdownSeconds = DEFAULT_KDS_COMPLETION_COUNTDOWN_SECONDS,
) {
  if (!isKdsPostCookTimerMinutes(defaultPostCookTimerMinutes)) throw new KdsActionError("기본 끓임 시간이 올바르지 않습니다.", 400);
  if (!isKdsCompletionCountdownSeconds(completionCountdownSeconds)) throw new KdsActionError("완료 카운트다운은 1~30초 값이어야 합니다.", 400);
  if (!expected.length || new Map(expected.map(task => [task.taskId, task])).size !== expected.length) {
    throw new KdsActionError("테이블 작업 목록이 올바르지 않습니다.", 400);
  }
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    await lockOpenDiningSession(connection, sessionId);
    const [rows] = await connection.query<CompletionLockedTask[]>(`
      SELECT k.task_id AS taskId,k.order_id AS orderId,k.member_items AS memberItems,k.kind,k.compatibility_key AS compatibilityKey,
        k.status,k.cooking_group_id AS cookingGroupId,k.cooking_started_at_ms AS cookingStartedAtMs,
        k.cooking_completed_at_ms AS cookingCompletedAtMs,k.previous_state AS previousState,k.changed_at_ms AS changedAtMs,
        k.post_cook_timer_minutes AS postCookTimerMinutes,k.post_cook_timer_started_at_ms AS postCookTimerStartedAtMs
      FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
      WHERE o.session_id=? AND k.status<>'DONE' ORDER BY k.task_id FOR UPDATE`, [sessionId],
    );
    const activeRows: Array<{ row: CompletionLockedTask; timerEligible: boolean }> = [];
    for (const row of rows) {
      if (row.status !== "WAITING" && row.status !== "COOKING") continue;
      const eligibility = await taskCookingEligibility(connection, row.memberItems);
      if (eligibility.hasActivePrimary) activeRows.push({ row, timerEligible: eligibility.timerEligible });
    }
    const expectedById = new Map(expected.map(task => [task.taskId, task]));
    const actualTaskIds = activeRows.map(({ row }) => Number(row.taskId)).sort((a, b) => a - b);
    const expectedTaskIds = [...expectedById.keys()].sort((a, b) => a - b);
    const versionsMatch = activeRows.every(({ row }) => {
      const snapshot = expectedById.get(Number(row.taskId));
      return snapshot?.status === row.status && snapshot.changedAtMs === number(row.changedAtMs);
    });
    if (!matchesKdsTableStartBatch(expectedTaskIds, actualTaskIds) || !versionsMatch) {
      throw new KdsActionError("테이블 주문 상태가 변경되었습니다. KDS 화면을 새로고침해 주세요.", 409, {
        expectedTaskIds, actualTaskIds,
      });
    }
    if (activeRows.some(({ row }) => pendingCompletion(parseKdsPreviousState(row.previousState)))) {
      throw new KdsActionError("이미 완료 요청 또는 취소 카운트다운이 진행 중입니다.", 409);
    }
    if (!activeRows.length) throw new KdsActionError("완료할 조리 작업이 없습니다.");

    const requestId = randomUUID();
    const requestedAtMs = Date.now();
    const waitingStartedAtMs = Math.max(requestedAtMs,
      ...activeRows.filter(({ row }) => row.status === "WAITING").map(({ row }) => (number(row.changedAtMs) ?? 0) + 1));
    const taskIds = actualTaskIds;
    for (const { row, timerEligible } of activeRows) {
      const originalPreviousState = row.previousState;
      const originalState = parseKdsPreviousState(originalPreviousState) ?? {
        status: row.status, cookingGroupId: number(row.cookingGroupId),
        cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
      };
      const restoring = {
        status: row.status, cookingGroupId: number(row.cookingGroupId),
        cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
        changedAtMs: number(row.changedAtMs), previousState: originalPreviousState,
        postCookTimerMinutes: number(row.postCookTimerMinutes ?? null),
        postCookTimerStartedAtMs: number(row.postCookTimerStartedAtMs ?? null),
      };
      const startAtMs = row.status === "WAITING" ? waitingStartedAtMs : number(row.cookingStartedAtMs);
      const changedAtMs = row.status === "WAITING" ? waitingStartedAtMs : number(row.changedAtMs);
      const previous: KdsPreviousState = row.status === "WAITING"
        ? { status: "WAITING", cookingGroupId: restoring.cookingGroupId,
            cookingStartedAtMs: restoring.cookingStartedAtMs, cookingCompletedAtMs: restoring.cookingCompletedAtMs,
            startSource: "TABLE" }
        : { ...originalState };
      previous.completionRequest = {
        scope: "TABLE", command: "TABLE_DOUBLE_CLICK", requestId, sessionId, requestedAtMs,
        completionCountdownSeconds, expectedStatus: "COOKING", expectedChangedAtMs: changedAtMs,
        expectedTaskIds: taskIds,
        // The auto-selected boil time applies to eligible POT work only.
        postCookTimerMinutes: row.kind === "POT" && timerEligible ? defaultPostCookTimerMinutes : null,
        doubleClickRestore: restoring,
      };
      const [result] = await connection.execute<ResultSetHeader>(`
        UPDATE kds_tasks SET status='COOKING',cooking_started_at_ms=?,cooking_completed_at_ms=NULL,
          previous_state=?,changed_at_ms=?,post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL
        WHERE task_id=? AND status=? AND changed_at_ms <=> ?`,
      [startAtMs, JSON.stringify(previous), changedAtMs, row.taskId, row.status, row.changedAtMs]);
      if (result.affectedRows !== 1) throw new KdsActionError("테이블 작업 상태가 요청 중 변경되었습니다. 화면을 새로고침해 주세요.", 409);
    }
    await connection.commit();
    return { requestId, requestedAtMs, taskCount: taskIds.length, taskIds,
      startedAtMs: waitingStartedAtMs, completionCountdownSeconds, command: "TABLE_DOUBLE_CLICK" as const };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function cancelKdsTableCompletionOnce(sessionId: number, requestId: string, requestedAtMs: number) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [sessions] = await connection.query<Array<RowDataPacket & { status: string }>>(
      "SELECT status FROM table_sessions WHERE session_id=? FOR UPDATE", [sessionId]);
    if (!sessions[0]) throw new KdsActionError("테이블 주문을 찾을 수 없습니다.", 404);
    const [rows] = await connection.query<Array<RowDataPacket & {
      taskId: number; status: KdsTaskStatus; previousState: string | null;
      cookingGroupId: number | null; cookingStartedAtMs: number | null; cookingCompletedAtMs: number | null;
      changedAtMs: number | null; postCookTimerMinutes: number | null; postCookTimerStartedAtMs: number | null;
    }>>(`
      SELECT k.task_id AS taskId,k.status,k.previous_state AS previousState,k.cooking_group_id AS cookingGroupId,
        k.cooking_started_at_ms AS cookingStartedAtMs,k.cooking_completed_at_ms AS cookingCompletedAtMs,
        k.changed_at_ms AS changedAtMs,k.post_cook_timer_minutes AS postCookTimerMinutes,
        k.post_cook_timer_started_at_ms AS postCookTimerStartedAtMs
      FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
      WHERE o.session_id=? ORDER BY k.task_id FOR UPDATE`, [sessionId]);
    const matching = rows.flatMap(row => {
      if (row.status === "DONE") return [];
      const previous = parseKdsPreviousState(row.previousState);
      const request = pendingCompletion(previous);
      return request?.scope === "TABLE" && request.requestId === requestId &&
        request.sessionId === sessionId && request.requestedAtMs === requestedAtMs
        ? [{ row, previous: previous!, request }] : [];
    });
    if (!matching.length) {
      const now = Date.now();
      const recentlyCompleted = rows.flatMap(row => {
        if (row.status !== "DONE") return [];
        const previous = parseKdsPreviousState(row.previousState);
        const completedRequest = previous?.completedTableRequest;
        return completedRequest?.requestId === requestId && completedRequest.sessionId === sessionId &&
          completedRequest.requestedAtMs === requestedAtMs &&
          completedRequest.command !== "TABLE_DOUBLE_CLICK" &&
          previous?.status === "COOKING" &&
          canRecoverKdsTableCompletionCancellation(completedRequest.confirmedAtMs, now)
          ? [{ row, previous: previous!, completedRequest }] : [];
      });
      if (!recentlyCompleted.length) {
        const completed = rows.flatMap(row => {
          if (row.status !== "DONE") return [];
          const previous = parseKdsPreviousState(row.previousState);
          const marker = previous?.completedTableRequest;
          return marker?.requestId === requestId && marker.sessionId === sessionId &&
            marker.requestedAtMs === requestedAtMs &&
            (marker.command === "TABLE_DOUBLE_CLICK" || previous?.status === "COOKING")
            ? [{ taskId: Number(row.taskId), marker }] : [];
        }).sort((a, b) => a.taskId - b.taskId);
        const actualTaskIds = completed.map(item => item.taskId);
        const snapshots = completed.map(item => item.marker.expectedTaskIds).filter((ids): ids is number[] => Array.isArray(ids));
        const expectedTaskIds = snapshots[0]?.slice().sort((a, b) => a - b) ?? actualTaskIds;
        const snapshotsAgree = snapshots.every(ids => matchesKdsTableStartBatch(expectedTaskIds, ids));
        if (completed.length > 0 && snapshotsAgree && matchesKdsTableStartBatch(expectedTaskIds, actualTaskIds)) {
          await connection.commit();
          return { cancelled: false, alreadyCompleted: true, outcome: "ALREADY_COMPLETED" as const,
            taskCount: actualTaskIds.length, expectedTaskIds, actualTaskIds };
        }
      }
      if (!recentlyCompleted.length) throw new KdsActionError("테이블 완료 요청이 이미 처리되었거나 취소되었습니다.");
      if (sessions[0].status !== "OPEN") throw new KdsActionError("종료된 테이블 주문은 조리 상태로 복구할 수 없습니다.");
      for (const { row, previous, completedRequest } of recentlyCompleted) {
        delete previous.completedTableRequest;
        await connection.execute(`UPDATE kds_tasks SET status='COOKING',cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,
          post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL
          WHERE task_id=? AND status='DONE' AND cooking_completed_at_ms <=> ?`,
        [previous.cookingCompletedAtMs, JSON.stringify(previous), completedRequest.expectedChangedAtMs,
          row.taskId, row.cookingCompletedAtMs]);
      }
      await connection.commit();
      return { cancelled: true, expired: false, recovered: true, taskCount: recentlyCompleted.length };
    }
    const recentlyCompletedAlongsidePending = rows.flatMap(row => {
      if (row.status !== "DONE") return [];
      const previous = parseKdsPreviousState(row.previousState);
      const completedRequest = previous?.completedTableRequest;
      return completedRequest?.requestId === requestId && completedRequest.sessionId === sessionId &&
        completedRequest.requestedAtMs === requestedAtMs && previous?.status === "COOKING" &&
        completedRequest.command !== "TABLE_DOUBLE_CLICK" &&
        canRecoverKdsTableCompletionCancellation(completedRequest.confirmedAtMs, Date.now())
        ? [{ row, previous: previous!, completedRequest }] : [];
    });
    if (!canCancelKdsTableCompletion(requestedAtMs, Date.now(), matching[0].request.completionCountdownSeconds) &&
      !recentlyCompletedAlongsidePending.length) {
      await connection.commit();
      return { cancelled: false, expired: true };
    }
    if (matching.some(({ request }) => request.command === "TABLE_DOUBLE_CLICK")) {
      const expectedTaskIds = matching[0].request.expectedTaskIds?.slice().sort((a, b) => a - b) ?? [];
      const actualTaskIds = matching.map(({ row }) => Number(row.taskId)).sort((a, b) => a - b);
      if (!matching.every(({ request }) => request.command === "TABLE_DOUBLE_CLICK") ||
        !matchesKdsTableStartBatch(expectedTaskIds, actualTaskIds)) {
        throw new KdsActionError("테이블 더블클릭 작업 구성이 변경되어 원래 상태로 복구할 수 없습니다. 화면을 갱신해 주세요.", 409, {
          expectedTaskIds, actualTaskIds,
        });
      }
      for (const { row, request } of matching) {
        const restore = request.doubleClickRestore;
        if (!restore) throw new KdsActionError("테이블 더블클릭의 원래 상태를 확인할 수 없어 취소하지 못했습니다.", 409);
        const [result] = await connection.execute<ResultSetHeader>(`
          UPDATE kds_tasks SET status=?,cooking_group_id=?,cooking_started_at_ms=?,cooking_completed_at_ms=?,
            previous_state=?,changed_at_ms=?,post_cook_timer_minutes=?,post_cook_timer_started_at_ms=?
          WHERE task_id=? AND status='COOKING' AND changed_at_ms <=> ?`,
        [restore.status, restore.cookingGroupId, restore.cookingStartedAtMs, restore.cookingCompletedAtMs,
          restore.previousState, restore.changedAtMs, restore.postCookTimerMinutes, restore.postCookTimerStartedAtMs,
          row.taskId, row.changedAtMs]);
        if (result.affectedRows !== 1) throw new KdsActionError("테이블 작업이 복구 도중 변경되었습니다. 화면을 갱신해 주세요.", 409);
      }
      await connection.commit();
      return { cancelled: true, expired: false, restoredOriginalStates: true,
        taskCount: matching.length, taskIds: actualTaskIds };
    }
    for (const { row, previous } of matching) {
      delete previous.completionRequest;
      await connection.execute("UPDATE kds_tasks SET previous_state=? WHERE task_id=? AND status=?",
        [JSON.stringify(previous), row.taskId, row.status]);
    }
    if (recentlyCompletedAlongsidePending.length && sessions[0].status !== "OPEN") {
      throw new KdsActionError("Cannot restore completed table work after the session has closed.", 409);
    }
    for (const { row, previous, completedRequest } of recentlyCompletedAlongsidePending) {
      delete previous.completedTableRequest;
      const [result] = await connection.execute<ResultSetHeader>(`UPDATE kds_tasks SET status='COOKING',cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,
        post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL
        WHERE task_id=? AND status='DONE' AND cooking_completed_at_ms <=> ?`,
      [previous.cookingCompletedAtMs, JSON.stringify(previous), completedRequest.expectedChangedAtMs,
        row.taskId, row.cookingCompletedAtMs]);
      if (result.affectedRows !== 1) throw new KdsActionError("Table completion changed before cancellation finished.", 409);
    }
    await connection.commit();
    return { cancelled: true, expired: false, recovered: recentlyCompletedAlongsidePending.length > 0,
      taskCount: matching.length + recentlyCompletedAlongsidePending.length };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function cancelKdsTableCompletion(sessionId: number, requestId: string, requestedAtMs: number) {
  for (let attempt = 0; ; attempt += 1) {
    try {
      return await cancelKdsTableCompletionOnce(sessionId, requestId, requestedAtMs);
    } catch (error) {
      const code = error && typeof error === "object" ? String((error as { code?: unknown }).code ?? "") : "";
      const retryable = code === "ER_LOCK_DEADLOCK" || code === "ER_LOCK_WAIT_TIMEOUT";
      if (!retryable || attempt >= 2) throw error;
      await new Promise(resolve => setTimeout(resolve, 40 * (attempt + 1)));
    }
  }
}

export async function finalizeKdsTableCompletion(sessionId: number, requestId: string, requestedAtMs: number, immediate = false) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [sessions] = await connection.query<Array<RowDataPacket & { status: string }>>(
      "SELECT status FROM table_sessions WHERE session_id=? FOR UPDATE", [sessionId]);
    if (sessions[0]?.status !== "OPEN") {
      await connection.commit();
      return { completed: 0, outcome: "SESSION_NOT_OPEN" as const, expectedTaskIds: [], actualTaskIds: [], serverNowMs: Date.now() };
    }
    const [rows] = await connection.query<CompletionLockedTask[]>(`
      SELECT k.task_id AS taskId,k.member_items AS memberItems,k.status,k.cooking_group_id AS cookingGroupId,
        k.cooking_started_at_ms AS cookingStartedAtMs,k.cooking_completed_at_ms AS cookingCompletedAtMs,
        k.previous_state AS previousState,k.changed_at_ms AS changedAtMs
      FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
      WHERE o.session_id=? ORDER BY k.task_id FOR UPDATE`, [sessionId]);
    const matching = rows.flatMap(row => {
      if (row.status === "DONE") return [];
      const previous = parseKdsPreviousState(row.previousState);
      const request = pendingCompletion(previous);
      return request?.scope === "TABLE" && request.requestId === requestId && request.sessionId === sessionId &&
        request.requestedAtMs === requestedAtMs ? [{ row, previous, request }] : [];
    });
    const actualTaskIds = matching.map(({ row }) => Number(row.taskId)).sort((a, b) => a - b);
    const storedSnapshots = matching.map(({ request }) => request.expectedTaskIds).filter((ids): ids is number[] => Array.isArray(ids));
    const expectedTaskIds = storedSnapshots[0]?.slice().sort((a, b) => a - b) ?? actualTaskIds;
    const snapshotsAgree = storedSnapshots.every(ids => matchesKdsTableStartBatch(expectedTaskIds, ids));
    if (!matching.length) {
      const completed = rows.flatMap(row => {
        if (row.status !== "DONE") return [];
        const marker = parseKdsPreviousState(row.previousState)?.completedTableRequest;
        return marker?.requestId === requestId && marker.sessionId === sessionId && marker.requestedAtMs === requestedAtMs
          ? [{ taskId: Number(row.taskId), marker }] : [];
      }).sort((a, b) => a.taskId - b.taskId);
      const actualCompletedIds = completed.map(item => item.taskId);
      const completedSnapshots = completed.map(item => item.marker.expectedTaskIds).filter((ids): ids is number[] => Array.isArray(ids));
      const completedExpectedIds = completedSnapshots[0]?.slice().sort((a, b) => a - b) ?? actualCompletedIds;
      const completedSnapshotsAgree = completedSnapshots.every(ids => matchesKdsTableStartBatch(completedExpectedIds, ids));
      if (completed.length > 0 && completedSnapshotsAgree &&
        matchesKdsTableStartBatch(completedExpectedIds, actualCompletedIds)) {
        await connection.commit();
        return { completed: actualCompletedIds.length, outcome: "ALREADY_COMPLETED" as const,
          alreadyCompleted: true, expectedTaskIds: completedExpectedIds, actualTaskIds: actualCompletedIds, serverNowMs: Date.now() };
      }
      await connection.commit();
      return { completed: 0, outcome: "REQUEST_NOT_FOUND" as const, expectedTaskIds, actualTaskIds, serverNowMs: Date.now() };
    }
    if (!snapshotsAgree || !matchesKdsTableStartBatch(expectedTaskIds, actualTaskIds)) {
      // A request snapshot is immutable. Cancel only its still-pending members and keep
      // the transaction/version checks intact; never complete a partial group.
      for (const { row, previous } of matching) {
        if (previous) delete previous.completionRequest;
        await connection.execute("UPDATE kds_tasks SET previous_state=? WHERE task_id=? AND status=?",
          [JSON.stringify(previous), row.taskId, row.status]);
      }
      await connection.commit();
      return { completed: 0, outcome: "TASK_SET_CHANGED" as const, expectedTaskIds, actualTaskIds, serverNowMs: Date.now() };
    }
    const serverNowMs = Date.now();
    const finalizeAtMs = kdsTableCompletionFinalizeAtMs(requestedAtMs, matching[0].request.completionCountdownSeconds);
    if (!immediate && !canFinalizeKdsTableCompletion(requestedAtMs, serverNowMs, matching[0].request.completionCountdownSeconds)) {
      await connection.commit();
      return { completed: 0, outcome: "COUNTDOWN_PENDING" as const, expectedTaskIds, actualTaskIds,
        finalizeAtMs, serverNowMs };
    }
    let changedGroup = false;
    for (const { row, request } of matching) {
      const unchanged = row.status === request.expectedStatus && number(row.changedAtMs) === request.expectedChangedAtMs;
      const eligibility = unchanged ? await taskCookingEligibility(connection, row.memberItems) : { hasActivePrimary: false, timerEligible: false };
      if (!unchanged || !eligibility.hasActivePrimary) { changedGroup = true; break; }
    }
    if (changedGroup) {
      for (const { row, previous } of matching) {
        if (previous) delete previous.completionRequest;
        await connection.execute("UPDATE kds_tasks SET previous_state=? WHERE task_id=? AND status=?",
          [JSON.stringify(previous), row.taskId, row.status]);
      }
      await connection.commit();
      return { completed: 0, outcome: "TASK_STATE_CHANGED" as const, expectedTaskIds, actualTaskIds, serverNowMs: Date.now() };
    }
    let completed = 0;
    const completedAtMs = Date.now();
    for (const { row, previous, request } of matching) {
      const eligibility = await taskCookingEligibility(connection, row.memberItems);
      const timerMinutes = eligibility.timerEligible && isKdsPostCookTimerMinutes(request.postCookTimerMinutes)
        ? request.postCookTimerMinutes : null;
      const originalState: KdsPreviousState = {
        ...previous,
        status: row.status, cookingGroupId: number(row.cookingGroupId),
        cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
        completedTableRequest: {
          requestId: request.requestId!, sessionId, requestedAtMs: request.requestedAtMs,
          confirmedAtMs: completedAtMs, expectedChangedAtMs: request.expectedChangedAtMs ?? null,
          expectedTaskIds,
          ...(request.command === "TABLE_DOUBLE_CLICK" ? { command: "TABLE_DOUBLE_CLICK" as const } : {}),
        },
      };
      delete originalState.completionRequest;
      const [result] = await connection.execute<ResultSetHeader>(`
        UPDATE kds_tasks SET status='DONE',cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,
          post_cook_timer_minutes=?,post_cook_timer_started_at_ms=?
        WHERE task_id=? AND status=? AND changed_at_ms <=> ?`,
      [completedAtMs, JSON.stringify(originalState), completedAtMs, timerMinutes,
        timerMinutes !== null ? completedAtMs : null, row.taskId, row.status, row.changedAtMs]);
      if (result.affectedRows !== 1) throw new KdsActionError("조리 작업 상태가 확정 도중 변경되었습니다.", 409);
      completed += 1;
    }
    await connection.commit();
    return { completed, outcome: "COMPLETED" as const, expectedTaskIds, actualTaskIds, serverNowMs: completedAtMs };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function cleanupUnusedKdsCookingGroups() {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const expiredBefore = Date.now() - KDS_WINDOW_MS;
    const [expiredDone] = await connection.query<Array<RowDataPacket & { taskId: number; previousState: string | null }>>(
      "SELECT task_id AS taskId,previous_state AS previousState FROM kds_tasks WHERE status='DONE' AND cooking_group_id IS NOT NULL AND changed_at_ms<=? FOR UPDATE",
      [expiredBefore],
    );
    for (const row of expiredDone) {
      const completedRequest = parseKdsPreviousState(row.previousState)?.completedTableRequest;
      if (completedRequest && canRecoverKdsTableCompletionCancellation(completedRequest.confirmedAtMs, Date.now())) continue;
      await connection.execute("UPDATE kds_tasks SET cooking_group_id=NULL,previous_state=NULL WHERE task_id=? AND status='DONE'", [row.taskId]);
    }
    const [recentWaiting] = await connection.query<Array<RowDataPacket & { previousState: string | null }>>(
      "SELECT previous_state AS previousState FROM kds_tasks WHERE status='WAITING' AND changed_at_ms>? FOR UPDATE", [expiredBefore],
    );
    const protectedGroupIds = new Set<number>();
    for (const row of recentWaiting) {
      const previous = parseKdsPreviousState(row.previousState);
      if (previous?.cookingGroupId !== null && previous?.cookingGroupId !== undefined) protectedGroupIds.add(previous.cookingGroupId);
    }
    const [groups] = await connection.query<GroupRow[]>(`
      SELECT g.group_id AS groupId,g.started_at_ms AS startedAtMs FROM kds_cooking_groups g
      WHERE NOT EXISTS (SELECT 1 FROM kds_tasks k WHERE k.cooking_group_id=g.group_id) FOR UPDATE`);
    for (const group of groups) {
      if (protectedGroupIds.has(Number(group.groupId))) continue;
      await connection.execute("DELETE FROM kds_cooking_groups WHERE group_id=? AND NOT EXISTS (SELECT 1 FROM kds_tasks WHERE cooking_group_id=?)",
        [group.groupId, group.groupId]);
    }
    await connection.commit();
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

type LockedTableTask = RowDataPacket & {
  taskId: number; orderId: number; memberItems: string; kind: "POT" | "SOLO"; compatibilityKey: string;
  status: KdsTaskStatus; cookingGroupId: number | null; cookingStartedAtMs: number | null;
  cookingCompletedAtMs: number | null; previousState: string | null; changedAtMs: number | null;
};

async function getActivePrimaryTaskIds(connection: PoolConnection, rows: LockedTableTask[], lockItems = true) {
  const regularRows = rows.filter(row => !(JSON.parse(row.memberItems) as KdsMember[])
    .some(member => member.kind !== "COMPONENT" && member.simpleCook === true));
  const itemIds = [...new Set(regularRows.flatMap(row =>
    (JSON.parse(row.memberItems) as KdsMember[]).filter(member => member.kind !== "COMPONENT").map(member => member.itemId),
  ))];
  if (!itemIds.length) return new Set<number>();
  const [items] = await connection.query<Array<RowDataPacket & {
    itemId: number; itemStatus: string; remaining: number; orderStatus: string; sessionStatus: string;
    kdsKind: KdsMenuKind; kdsVisible: number;
  }>>(`
    SELECT oi.order_item_id AS itemId,oi.status AS itemStatus,
      COALESCE(oi.actual_component_qty,oi.qty)-COALESCE(c.cancelled_qty,0) AS remaining,
      o.status AS orderStatus,s.status AS sessionStatus,m.kds_kind AS kdsKind,m.kds_visible AS kdsVisible
    FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id
    INNER JOIN orders o ON o.order_id=oi.order_id INNER JOIN table_sessions s ON s.session_id=o.session_id
    LEFT JOIN (SELECT order_item_id,SUM(cancelled_qty) AS cancelled_qty
      FROM order_item_cancellations WHERE order_item_id IN (?) GROUP BY order_item_id) c ON c.order_item_id=oi.order_item_id
    WHERE oi.order_item_id IN (?) ${lockItems ? "FOR UPDATE" : ""}`, [itemIds, itemIds],
  );
  return new Set(items.filter(item => item.itemStatus !== "CANCELLED" && item.orderStatus !== "CANCELLED" &&
    item.sessionStatus === "OPEN" && item.kdsKind !== "NONE" && Boolean(item.kdsVisible) && Number(item.remaining) > 0)
    .map(item => Number(item.itemId)));
}

async function getKdsMenuConfigByItemIds(
  connection: PoolConnection,
  rows: Array<{ memberItems: string }>,
) {
  const itemIds = [...new Set(rows.flatMap(row =>
    (JSON.parse(row.memberItems) as KdsMember[]).filter(member => member.kind !== "COMPONENT").map(member => member.itemId),
  ))];
  if (!itemIds.length) return new Map<number, { kdsKind: KdsMenuKind; kdsGroupKey: string | null }>();
  const [items] = await connection.query<Array<RowDataPacket & {
    itemId: number; kdsKind: KdsMenuKind; kdsGroupKey: string | null;
  }>>(`SELECT oi.order_item_id AS itemId,m.kds_kind AS kdsKind,m.kds_group_key AS kdsGroupKey
      FROM order_items oi INNER JOIN menus m ON m.menu_id=oi.menu_id WHERE oi.order_item_id IN (?) FOR UPDATE`, [itemIds]);
  return new Map(items.map(item => [Number(item.itemId), {
    kdsKind: item.kdsKind, kdsGroupKey: item.kdsGroupKey?.trim() || null,
  }]));
}

async function lockOpenDiningSession(connection: PoolConnection, sessionId: number) {
  const [sessions] = await connection.query<(RowDataPacket & { sessionKind: string; status: string; tableId: number | null })[]>(
    "SELECT session_kind AS sessionKind,status,table_id AS tableId FROM table_sessions WHERE session_id=? FOR UPDATE", [sessionId],
  );
  const session = sessions[0];
  if (!session || session.sessionKind !== "DINE_IN" || session.status !== "OPEN" || session.tableId === null) {
    throw new KdsActionError("현재 진행 중인 매장 테이블 주문이 아닙니다.");
  }
}

export async function startKdsTable(
  sessionId: number, requestedTaskIds?: number[], startUndoWindowMs = kdsStartUndoWindowMs(),
  startSource: "MENU" | "STATUS" | "TABLE" = "TABLE",
) {
  if (!isKdsStartUndoWindowMs(startUndoWindowMs)) throw new KdsActionError("조리 시작 취소 시간이 올바르지 않습니다.", 400);
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    await lockOpenDiningSession(connection, sessionId);
    const [rows] = await connection.query<LockedTableTask[]>(`
      SELECT k.task_id AS taskId,k.order_id AS orderId,k.member_items AS memberItems,
        k.kind,k.compatibility_key AS compatibilityKey,k.status,k.cooking_group_id AS cookingGroupId,
        k.cooking_started_at_ms AS cookingStartedAtMs,k.cooking_completed_at_ms AS cookingCompletedAtMs,
        k.previous_state AS previousState,k.changed_at_ms AS changedAtMs
      FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
      WHERE o.session_id=? AND k.status='WAITING' ORDER BY k.task_id FOR UPDATE`, [sessionId],
    );
    const activeItemIds = await getActivePrimaryTaskIds(connection, rows);
    const waitingRows = rows.filter(row => (JSON.parse(row.memberItems) as KdsMember[])
      .some(member => member.kind !== "COMPONENT" && activeItemIds.has(member.itemId)));
    const selectedRows = requestedTaskIds
      ? waitingRows.filter(row => requestedTaskIds.includes(Number(row.taskId))) : waitingRows;
    if (requestedTaskIds) {
      const firstPot = selectedRows.find(row => row.kind === "POT");
      const displayGroup = firstPot ? (await kdsPotDisplayGroupsForSession(connection, sessionId))
        .find(group => group.some(task => task.taskId === Number(firstPot.taskId))) : undefined;
      const selectedIds = selectedRows.map(row => Number(row.taskId));
      if (new Set(requestedTaskIds).size !== requestedTaskIds.length ||
        selectedRows.length !== requestedTaskIds.length || !firstPot ||
        !displayGroup || !matchesKdsTableStartBatch(selectedIds, displayGroup.map(task => task.taskId))) {
        throw new KdsActionError("같은 냄비의 대기 중 메뉴 구성이 변경되었습니다. 화면을 갱신해 주세요.");
      }
    }
    if (!selectedRows.length) {
      await connection.commit();
      return { batchStartId: null, taskCount: 0 };
    }
    const startedAtMs = Math.max(Date.now(), ...selectedRows.map(row => (number(row.changedAtMs) ?? 0) + 1));
    const batchStartId = randomUUID();
    for (const row of selectedRows) {
      const state: KdsState = {
        status: row.status, cookingGroupId: number(row.cookingGroupId),
        cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
        previousState: row.previousState ? JSON.parse(row.previousState) as KdsStateSnapshot : null,
        changedAtMs: number(row.changedAtMs),
      };
      const previousState = { ...stateSnapshotForKds(state), bulkStartId: batchStartId,
        startSource, startUndoWindowMs };
      await connection.execute(`
        UPDATE kds_tasks SET status='COOKING',cooking_group_id=?,cooking_started_at_ms=?,
          cooking_completed_at_ms=NULL,previous_state=?,changed_at_ms=?,
          post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL WHERE task_id=?`,
      [null, startedAtMs, JSON.stringify(previousState), startedAtMs, row.taskId]);
    }
    await connection.commit();
     return { batchStartId, taskCount: selectedRows.length, taskIds: selectedRows.map(row => Number(row.taskId)),
       startedAtMs, startUndoWindowMs };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function undoKdsTableStart(
  sessionId: number, batchStartId: string, expectedTaskIds: number[], queuedUndoDelayMs?: number,
  fallbackStartUndoWindowMs = kdsStartUndoWindowMs(),
) {
  if (!isKdsStartUndoWindowMs(fallbackStartUndoWindowMs)) throw new KdsActionError("조리 시작 취소 시간이 올바르지 않습니다.", 400);
  const connection = await pool.getConnection();
  try {
    const uniqueExpectedTaskIds = [...new Set(expectedTaskIds)];
    if (!uniqueExpectedTaskIds.length || uniqueExpectedTaskIds.length !== expectedTaskIds.length ||
      uniqueExpectedTaskIds.some(taskId => !Number.isSafeInteger(taskId) || taskId <= 0)) {
      throw new KdsActionError("테이블 조리 시작 그룹 정보를 확인할 수 없습니다.", 400);
    }
    await connection.beginTransaction();
    await lockOpenDiningSession(connection, sessionId);
    const [rows] = await connection.query<LockedTableTask[]>(`
      SELECT k.task_id AS taskId,k.order_id AS orderId,k.member_items AS memberItems,
        k.compatibility_key AS compatibilityKey,k.status,k.cooking_group_id AS cookingGroupId,
        k.cooking_started_at_ms AS cookingStartedAtMs,k.cooking_completed_at_ms AS cookingCompletedAtMs,
        k.previous_state AS previousState,k.changed_at_ms AS changedAtMs
      FROM kds_tasks k INNER JOIN orders o ON o.order_id=k.order_id
      WHERE o.session_id=? AND k.status='COOKING' ORDER BY k.task_id FOR UPDATE`, [sessionId],
    );
    const activeItemIds = await getActivePrimaryTaskIds(connection, rows);
    const batchRows = rows.filter(row => parseKdsPreviousState(row.previousState)?.bulkStartId === batchStartId);
    const batchTaskIds = batchRows.map(row => Number(row.taskId));
    if (!matchesKdsTableStartBatch(uniqueExpectedTaskIds, batchTaskIds)) {
      throw new KdsActionError("테이블 전체 조리 시작 그룹이 변경되었습니다. 화면을 새로고침해 주세요.");
    }
    const now = Date.now();
    const validatedRows = batchRows.map(row => {
      const previous = row.previousState
        ? JSON.parse(row.previousState) as KdsStateSnapshot & { bulkStartId?: string; startUndoWindowMs?: number }
        : null;
      const changedAtMs = number(row.changedAtMs);
      const undoWindowMs = isKdsStartUndoWindowMs(previous?.startUndoWindowMs)
        ? previous.startUndoWindowMs : fallbackStartUndoWindowMs;
      const queuedUndo = canAcceptKdsQueuedUndo(queuedUndoDelayMs, changedAtMs, now, undoWindowMs);
      if (previous?.bulkStartId !== batchStartId || previous.status !== "WAITING" || changedAtMs === null ||
        now < changedAtMs || (now - changedAtMs > undoWindowMs && !queuedUndo) ||
        !(JSON.parse(row.memberItems) as KdsMember[]).some(member => member.kind !== "COMPONENT" && activeItemIds.has(member.itemId))) {
        throw new KdsActionError("테이블 전체 조리 시작 취소 가능 시간이 지났거나 주문 상태가 변경되었습니다.");
      }
      return { row, previous, changedAtMs, queuedUndo, undoWindowMs };
    });
    for (const { row, previous, changedAtMs, queuedUndo, undoWindowMs } of validatedRows) {
      const state: KdsState = {
        status: row.status, cookingGroupId: number(row.cookingGroupId),
        cookingStartedAtMs: number(row.cookingStartedAtMs), cookingCompletedAtMs: number(row.cookingCompletedAtMs),
        previousState: previous, changedAtMs,
      };
      const next = transitionKdsState(state, "MENU", now, undefined, queuedUndo, undoWindowMs);
      if (!next) throw new KdsActionError("테이블 조리 시작 그룹을 모두 복구할 수 없습니다.");
      await connection.execute(`
        UPDATE kds_tasks SET status=?,cooking_group_id=?,cooking_started_at_ms=?,
          cooking_completed_at_ms=?,previous_state=?,changed_at_ms=?,
          post_cook_timer_minutes=NULL,post_cook_timer_started_at_ms=NULL WHERE task_id=?`,
      [next.status, next.cookingGroupId, next.cookingStartedAtMs,
        next.cookingCompletedAtMs, JSON.stringify(next.previousState), next.changedAtMs, row.taskId]);
    }
    await connection.commit();
    return { taskCount: validatedRows.length, taskIds: batchTaskIds.sort((a, b) => a - b) };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}
