export function canProcessQrOrder(status: string): boolean {
  return status === "PENDING";
}

export function shouldBlockQrTokenCancellation(pendingOrderCount: number): boolean {
  return pendingOrderCount > 0;
}
