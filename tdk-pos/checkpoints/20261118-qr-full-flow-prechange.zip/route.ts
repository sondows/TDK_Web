import { and, asc, desc, eq, inArray, isNull, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { diningTables, qrCodes, qrOrderItemOptions, qrOrderItems, qrOrders, qrSessions, qrTableLinks, tableSessions } from "@/db/schema";
import { getCurrentStaff } from "@/lib/auth";
import { getCurrentHosStaff } from "@/lib/hos-auth";
import { totalQrOrderAmount } from "@/lib/qr-order-history-model";
import { QR_ORDER_ACCESS_MAX_AGE_SECONDS } from "@/lib/qr-order-auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const staff = await getCurrentStaff() ?? await getCurrentHosStaff();
  if (!staff) return Response.json({ success: false }, { status: 401, headers: { "Cache-Control": "no-store" } });

  const tableId = Number(new URL(request.url).searchParams.get("tableId"));
  if (!Number.isSafeInteger(tableId) || tableId <= 0) {
    return Response.json({ success: false, message: "유효한 테이블을 지정해 주세요." }, { status: 400, headers: { "Cache-Control": "no-store" } });
  }

  try {
    const orders = await db.select({ qrOrderId: qrOrders.qrOrderId, status: qrOrders.status,
      totalAmount: qrOrders.totalAmount, orderedAt: sql<string>`DATE_FORMAT(${qrOrders.orderedAt}, '%Y-%m-%dT%H:%i:%s')`,
      acceptedAt: sql<string | null>`DATE_FORMAT(${qrOrders.acceptedAt}, '%Y-%m-%dT%H:%i:%s')`,
      rejectedAt: sql<string | null>`DATE_FORMAT(${qrOrders.rejectedAt}, '%Y-%m-%dT%H:%i:%s')`, note: qrOrders.note })
      .from(qrOrders).innerJoin(qrSessions, eq(qrSessions.qrSessionId, qrOrders.qrSessionId))
      .leftJoin(tableSessions, eq(tableSessions.sessionId, qrSessions.sessionId))
      .innerJoin(diningTables, eq(diningTables.tableId, sql`COALESCE(${tableSessions.tableId}, ${qrSessions.tableId})`))
      .innerJoin(qrTableLinks, eq(qrTableLinks.tableId, diningTables.tableId))
      .innerJoin(qrCodes, eq(qrCodes.qrCodeId, qrTableLinks.qrCodeId))
      .where(and(eq(diningTables.tableId, tableId), eq(diningTables.isActive, 1), eq(qrSessions.status, "ACTIVE"),
        sql`${qrSessions.createdAt} >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ${QR_ORDER_ACCESS_MAX_AGE_SECONDS} SECOND)`,
        or(and(isNull(qrSessions.sessionId), eq(qrSessions.tableId, tableId)),
          and(eq(tableSessions.tableId, tableId), eq(tableSessions.status, "OPEN"), eq(tableSessions.sessionKind, "DINE_IN"))),
        eq(qrCodes.targetType, "TABLE_ORDER"), eq(qrCodes.status, "IN_USE")))
      .orderBy(desc(qrOrders.orderedAt), desc(qrOrders.qrOrderId));

    const orderIds = orders.map(order => Number(order.qrOrderId));
    const items = orderIds.length ? await db.select({ qrOrderId: qrOrderItems.qrOrderId,
      qrOrderItemId: qrOrderItems.qrOrderItemId, itemName: qrOrderItems.itemName, qty: qrOrderItems.qty,
      unitPrice: qrOrderItems.unitPrice, totalAmount: qrOrderItems.totalAmount, note: qrOrderItems.note })
      .from(qrOrderItems).where(inArray(qrOrderItems.qrOrderId, orderIds))
      .orderBy(asc(qrOrderItems.qrOrderItemId)) : [];
    const itemIds = items.map(item => Number(item.qrOrderItemId));
    const options = itemIds.length ? await db.select({ qrOrderItemId: qrOrderItemOptions.qrOrderItemId,
      optionName: qrOrderItemOptions.optionName, qty: qrOrderItemOptions.qty, totalAmount: qrOrderItemOptions.totalAmount })
      .from(qrOrderItemOptions).where(inArray(qrOrderItemOptions.qrOrderItemId, itemIds)) : [];

    const resultOrders = orders.map(order => ({ ...order, qrOrderId: Number(order.qrOrderId),
      items: items.filter(item => Number(item.qrOrderId) === Number(order.qrOrderId)).map(item => ({
        ...item, qrOrderItemId: Number(item.qrOrderItemId), qty: Number(item.qty),
        options: options.filter(option => Number(option.qrOrderItemId) === Number(item.qrOrderItemId))
          .map(option => ({ ...option, qty: Number(option.qty) })),
      })),
    }));

    return Response.json({ success: true, orders: resultOrders,
      orderCount: resultOrders.length, totalAmount: totalQrOrderAmount(orders) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("QR staff order history unavailable", { code: (error as { code?: string }).code });
    return Response.json({ success: false, message: "QR 주문내역을 불러오지 못했습니다." }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
