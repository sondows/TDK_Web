import "server-only";

import type { RowDataPacket } from "mysql2/promise";
import { pool } from "@/db";
import { QR_ORDER_ACCESS_MAX_AGE_SECONDS } from "@/lib/qr-order-auth";

export type QrTableIndicator = {
  tableId: number;
  tableNo: string;
  issuedAt: string;
  adultCount: number | null;
  babyCount: number | null;
  hasActiveQrToken: boolean;
  hasPendingQrOrder: boolean;
};

type QrTableIndicatorRow = RowDataPacket & {
  tableId: number | string;
  tableNo: string;
  issuedAt: string;
  adultCount: number | string | null;
  babyCount: number | string | null;
  hasPendingQrOrder: number | string;
};

/** Uses the same active-session, current-sticker, and token-age rules as customer QR auth. */
export async function loadQrTableIndicators(): Promise<Map<number, QrTableIndicator>> {
  const [rows] = await pool.query<QrTableIndicatorRow[]>(`
    SELECT t.table_id AS tableId, t.table_no AS tableNo,
      DATE_FORMAT(MIN(qs.created_at), '%Y-%m-%d %H:%i:%s') AS issuedAt,
      MAX(COALESCE(ts.person_count, active_ts.person_count)) AS adultCount,
      MAX(COALESCE(ts.baby_count, active_ts.baby_count)) AS babyCount,
      MAX(CASE WHEN qo.qr_order_id IS NOT NULL THEN 1 ELSE 0 END) AS hasPendingQrOrder
    FROM qr_sessions qs
    LEFT JOIN table_sessions ts ON ts.session_id = qs.session_id
    INNER JOIN dining_tables t ON t.table_id = COALESCE(ts.table_id, qs.table_id)
    INNER JOIN qr_table_links qtl ON qtl.table_id = t.table_id
    INNER JOIN qr_codes qc ON qc.qr_code_id = qtl.qr_code_id
    LEFT JOIN table_sessions active_ts ON active_ts.table_id = t.table_id
      AND active_ts.status = 'OPEN' AND active_ts.session_kind = 'DINE_IN'
    LEFT JOIN qr_orders qo ON qo.qr_session_id = qs.qr_session_id AND qo.status = 'PENDING'
    WHERE qs.status = 'ACTIVE'
      AND qs.created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? SECOND)
      AND (qs.session_id IS NULL OR (ts.status = 'OPEN' AND ts.session_kind = 'DINE_IN'))
      AND t.is_active = 1
      AND qc.target_type = 'TABLE_ORDER'
      AND qc.status = 'IN_USE'
    GROUP BY t.table_id, t.table_no`, [QR_ORDER_ACCESS_MAX_AGE_SECONDS]);

  return new Map(rows.map(row => {
    const adultCount = row.adultCount === null ? null : Number(row.adultCount);
    const babyCount = row.babyCount === null ? null : Number(row.babyCount);
    const hasRegisteredPeople = adultCount !== null && (adultCount > 0 || (babyCount ?? 0) > 0);
    return [Number(row.tableId), {
    tableId: Number(row.tableId),
    tableNo: String(row.tableNo),
    issuedAt: row.issuedAt,
    adultCount: hasRegisteredPeople ? adultCount : null,
    babyCount: hasRegisteredPeople ? babyCount : null,
    hasActiveQrToken: true,
    hasPendingQrOrder: Number(row.hasPendingQrOrder) === 1,
  }];
  }));
}
