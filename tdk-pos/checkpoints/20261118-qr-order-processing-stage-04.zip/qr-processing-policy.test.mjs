import assert from "node:assert/strict";
import test from "node:test";
import { canProcessQrOrder, shouldBlockQrTokenCancellation } from "./qr-processing-policy.ts";

test("only pending QR orders can be approved or rejected", () => {
  assert.equal(canProcessQrOrder("PENDING"), true);
  for (const status of ["ACCEPTED", "REJECTED", "CANCELLED", "CLOSED"]) {
    assert.equal(canProcessQrOrder(status), false);
  }
});

test("token cancellation is blocked while any unprocessed QR order remains", () => {
  assert.equal(shouldBlockQrTokenCancellation(0), false);
  assert.equal(shouldBlockQrTokenCancellation(1), true);
  assert.equal(shouldBlockQrTokenCancellation(3), true);
});
