export type QrTableIndicatorState = "NONE" | "TOKEN" | "PENDING_ORDER";

export function qrTableIndicatorState(status: { hasActiveQrToken: boolean; hasPendingQrOrder: boolean }): QrTableIndicatorState {
  if (!status.hasActiveQrToken) return "NONE";
  return status.hasPendingQrOrder ? "PENDING_ORDER" : "TOKEN";
}
