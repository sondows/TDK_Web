import assert from "node:assert/strict";
import test from "node:test";
import { qrTableIndicatorState } from "./qr-table-indicators-model.ts";

test("no valid token leaves the table indicator empty", () => {
  assert.equal(qrTableIndicatorState({ hasActiveQrToken: false, hasPendingQrOrder: false }), "NONE");
});

test("an active token without a pending order shows the blue-token state", () => {
  assert.equal(qrTableIndicatorState({ hasActiveQrToken: true, hasPendingQrOrder: false }), "TOKEN");
});

test("a pending QR order shows red QR only while its token is active", () => {
  assert.equal(qrTableIndicatorState({ hasActiveQrToken: true, hasPendingQrOrder: true }), "PENDING_ORDER");
  assert.equal(qrTableIndicatorState({ hasActiveQrToken: false, hasPendingQrOrder: true }), "NONE");
});

test("states stay isolated per table and reset independently", () => {
  const statuses = new Map([
    [1, { hasActiveQrToken: true, hasPendingQrOrder: true }],
    [2, { hasActiveQrToken: true, hasPendingQrOrder: false }],
    [3, { hasActiveQrToken: false, hasPendingQrOrder: false }],
  ]);
  assert.deepEqual([...statuses].map(([, status]) => qrTableIndicatorState(status)), ["PENDING_ORDER", "TOKEN", "NONE"]);
});
