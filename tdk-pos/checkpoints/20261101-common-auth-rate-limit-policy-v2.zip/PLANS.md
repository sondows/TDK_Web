# TDKON 단계별 개발 계획

## 사용법과 상태 기준

새 개발 목표를 받으면 현재 코드와 DB 의존성을 먼저 분석하고 이 표를 목표에 맞게 갱신한다. 각 단계에는 코드 분석, 최소 수정, 관련 테스트, 결과 확인을 순서대로 기록한다. `PASS`는 실제 검증 결과와 복구 지점을 남긴 경우에만 부여한다. 문제가 나면 해당 단계에서 원인을 수정하고 다시 검증한다. 같은 문제가 두 번 반복되면 다음 기능 단계로 넘어가지 않고 실행 코드·DB·API·화면·인증 로직·환경·배포 상태를 확인한다.

현재 목표: ADM 최초 인증 문제를 해결하고 POS·ADM·KDS 인증 흐름을 순차적으로 검증한다. HOS는 향후 개발 대상이다. 운영 DB `TDK_POS`의 변경, 인증 보안 정책 변경, 대규모 삭제, 운영 배포는 사용자 승인 후 진행한다. 개발 DB는 `TDK_POS_TEST`이다.

## 현재 기준선

- 2026-10-30: 기존 작업 트리에 프로그램 신뢰 토큰·마스터 비밀번호 복구 관련 수정 및 미추적 파일이 다수 존재한다. 이 코드는 단계별 검증 기록이 없어 완료로 간주하지 않는다.
- 앞선 점검에서 프로덕션 빌드와 TypeScript 검사는 통과했다. 변경 파일 대상 ESLint는 통과했으며, 전체 소스 ESLint에는 기존 파일의 오류가 남아 있다. 이 결과는 아래 개별 단계의 `PASS` 근거가 아니다.
- 인증 흐름과 DB 전환 설명은 `docs/program-trust-rollout.md`에 있다. 운영 DB와 NAS 배포는 진행하지 않았다.

## ADM 최초 인증 단계

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 ADM 계정 및 마스터 비밀번호 상태 확인 | `scripts/check-owner-first-auth-test.cjs`, `TDK_POS_TEST` 읽기 전용 조회, 계획 기록 | 개발 DB 연결 및 계정 식별 | 조회 결과와 이후 복구 분기 | 대상 계정·최고관리자 권한·비밀번호 해시·PIN·잠금·복구 권한 상태를 확인하고 결과 기록 | 읽기 전용 스크립트 실행 및 조회 항목 확인 | PASS |
| 2 | ID 입력과 서버 상태 조회 연결 | `ProgramTrustGate.tsx`, ADM 신뢰·복구 상태 API | 1 PASS | ADM 최초 인증 화면·API | ID 입력 후 서버 상태가 의도된 화면 전환에 반영되고 계정 정보가 무단 노출되지 않음 | 관련 상태 전환 단위 테스트와 개발 환경 API 확인 | PASS |
| 3 | 마스터 비밀번호 미등록 시 등록 버튼 표시 | `ProgramTrustGate.tsx`, 복구 상태 API | 2 PASS | ADM 화면 분기 | 유효한 복구 권한이 있을 때만 등록 버튼이 표시됨 | 유효·만료·부재 복구 권한 화면/API 테스트 | PASS |
| 4 | 마스터 비밀번호 등록 및 저장 | 복구 등록 API, `staff` 해시, 개발 DB 스키마 | 3 PASS, 개발 DB 스키마 확인 | 최고관리자 인증 정보·기존 세션 | 유효한 권한으로 해시가 저장되고 권한이 일회용으로 소비되며 세션이 무효화됨 | 개발 DB 통합 테스트, 재사용·만료·실패 경로 확인 | PASS |
| 5 | ID + 마스터 비밀번호 인증 | ADM 신뢰 등록 API, 비밀번호 검증 로직 | 4 PASS | ADM 최초 인증·시도 제한 | 올바른 자격만 통과하고 오류·잠금 정책이 유지됨 | 성공·실패·잠금 테스트와 개발 환경 API 확인 | PASS |
| 6 | 프로그램별 보안토큰 발급 및 검증 | 신뢰 토큰 API·쿠키·DB·호스트 접근 검사 | 5 PASS | POS·ADM·KDS 신뢰 상태 | 토큰이 프로그램별로 분리되고 서버 검증·폐기가 작동함 | 토큰 발급·교차 사용 거절·폐기 테스트 | PASS |
| 7 | 개인 PIN 등록 또는 기존 PIN 인증 | PIN API, 개인 PIN 정책, 로그인 화면 | 6 PASS | 직원 PIN·업무 화면 진입 | 새 PIN 등록 또는 기존 PIN 확인 후에만 세션이 생성됨 | PIN 등록·오입력·재시도·세션 생성 테스트 | PASS |
| 8 | 재접속 시 토큰 + PIN 로그인 | POS·ADM·KDS 로그인 API·화면 | 7 PASS | 재접속 인증 | 유효 토큰에 개인 PIN을 요구하고 무효 토큰은 최초 인증으로 돌아감 | 재접속·쿠키 만료·토큰 폐기 테스트 | PASS |
| 9 | 퇴사·프로그램 권한 변경 시 인증 무효화 | 직원 변경·퇴사 API, 토큰·세션 조회 | 8 PASS | 직원 권한·기존 세션 | 퇴사 또는 권한 해제 직후 해당 토큰과 세션이 거절됨 | 퇴사·비활성화·권한 해제 통합 테스트 | PASS |
| 10 | POS·ADM·KDS 통합 회귀 검증 | 관련 API·화면·테스트, 배포 준비 기록 | 1~9 PASS | 세 프로그램 인증 및 기존 기능 | 개발 환경에서 전체 흐름과 기존 정상 기능을 확인하고 결과·DB 변경·배포 필요 여부 기록 | 관련 테스트 모음, 빌드, 개발 환경 시나리오 점검 | PASS |

## 단계 기록

### 1단계 — PASS

- 분석: 기존 `check-owner-first-auth-test.cjs`는 `DB_NAME=TDK_POS_TEST`를 강제하고 `sondows` 계정의 권한·마스터 비밀번호 해시 존재 여부·PIN·로그인 잠금·복구 권한 수만 읽기 전용으로 조회한다.
- 검증: `node scripts/check-owner-first-auth-test.cjs` 실행 성공. `TDK_POS_TEST`에서 `sondows`는 단일 행(`staff_id=1`)이며 활성 최고관리자이고 ADM 권한과 개인 PIN, 관리자 2차 비밀번호가 있다. 마스터 비밀번호 해시는 `NULL`, 로그인 잠금은 없고 활성 복구 권한은 0건이다. 만료 1건·폐기 3건이다. 해시나 토큰 값은 출력하지 않았다.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-01.md`에 읽기 전용 검증 결과와 다음 분기를 기록했다. 계정 및 운영 DB 데이터는 변경하지 않았다.

### 2단계 — PASS

- 분석: 기존 화면은 복구 링크의 서버 상태 조회 결과로 ID를 읽기 전용으로 채우고 즉시 등록 단계로 이동했다. 상태 API는 유효한 복구 권한과 일치하는 ID를 함께 검증한다.
- 수정: 복구 화면에서 ID 확인 단계를 추가하고, 제출한 ID와 복구 권한으로 상태 API를 다시 호출한다. 다른 ID·무효 권한은 다음 단계로 진행하지 않는다. API 요청·응답 처리는 `master-recovery-client.ts`에 둔다.
- 검증: 상태 전환과 클라이언트 API 계약 단위 테스트 5건 통과, 변경 파일 ESLint 및 TypeScript 통과. `TDK_POS_TEST` 스키마 확인 통과. `integration-master-recovery-test.cjs`는 유효·다른 ID·무효 권한의 API 응답을 확인하고 임시 계정 정리를 완료했다. 브라우저 클릭 경로는 10단계 통합 검증에서 다시 확인한다.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-02.md`에 수정 파일과 검증 결과를 기록했다.

### 3단계 — PASS

- 분석: 서버는 `passwordConfigured`를 반환하지만 기존 화면 버튼은 그 값을 사용하지 않았다. 만료 검증은 DB 현지 시각의 `DATETIME`을 앱 서버 시각과 비교해 약 9시간 어긋났다.
- 수정: ID 확인 응답의 비밀번호 상태에 따라 등록/재설정 버튼과 안내를 구분했다. 복구 상태 조회와 등록 API의 만료 판정을 DB `NOW()`로 통일했다. 상태 쿠키 유효기간도 DB의 남은 시간으로 계산한다.
- 검증: 관련 단위 테스트 6건, TypeScript, 변경 파일 ESLint 통과. 개발 DB 통합 검사에서 무효·다른 ID·만료 권한이 거절되고 유효 권한이 처리됐다. 헤드리스 Chrome에서 ID 확인, 미등록 계정의 등록 버튼, 만료 링크 차단, 기존 비밀번호 계정의 재설정 버튼을 확인했다.
- 오류 분석: 개발 DB의 복구 상태 조회 제한 키가 55회로 누적돼 429가 화면 검사를 가렸다. 테스트가 해당 키를 검사 동안 분리하고 원래 값으로 복원하도록 수정했다. 검사 후 55회 복원 확인.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-03.zip`에 이 단계의 코드·테스트·계획 스냅샷을 저장했다.

### 4단계 — PASS

- 분석: 복구 등록 API는 복구 권한을 잠근 트랜잭션 안에서 직원 해시·권한 사용 시각·토큰 폐기·세션 종료·감사 로그를 갱신한다. 개발 DB의 관련 스키마는 준비 상태다.
- 검증: `integration-master-recovery-test.cjs`에서 약한 비밀번호와 무효·만료·재사용 권한은 거절됐고, 거절 후 해시는 여전히 비어 있었다. 정상 등록 뒤 `scrypt$` 해시와 권한 사용 표식을 확인했다. 재설정 뒤 활성 토큰·세션이 각각 0건이었다. 임시 계정·권한 정리 완료.
- 체크포인트: `checkpoints/20261030-adm-auth-stage-04.zip`에 이 단계의 복구 API·통합 검사·계획 파일을 저장한다.

### 5단계 — PASS

- 분석: ADM 최초 인증은 `enrollProgramTrust`에서 ID·마스터 비밀번호를 검증한다. 실패 횟수는 계정별/검증된 IP별로 기록하며 15분 동안 5회부터 잠근다.
- 검증: `TDK_POS_TEST` 임시 계정의 잘못된 비밀번호 1~4회는 401, 5회와 잠금 중 올바른 비밀번호는 429였다. 검사에서 저장된 실패 횟수 5회와 15분 이내 시각을 확인한 뒤 임시 계정·잠금 데이터를 정리했다. 관련 단위 테스트 1건 및 변경 파일 ESLint 통과.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-05.zip`에 이 단계의 인증 코드·통합 검사·계획 파일을 저장한다.

### 6단계 — PASS

- 분석: POS·ADM·KDS 토큰 쿠키 이름은 분리돼 있다. 서버는 토큰 해시·프로그램·직원 활성 상태·해당 권한·폐기 상태를 함께 확인하고, 폐기 시 연결된 세션을 종료한다.
- 검증: 호스트 접근·토큰·등록 단위 테스트 11건 통과. `integration-program-trust-test.cjs`에서 세 프로그램의 잘못된 비밀번호 401, 정상 발급 200, 타 프로그램 토큰 사용 거절, PIN 로그인 200, 토큰 폐기 뒤 페이지/API·세션 차단을 확인했다. 임시 직원 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-06.zip`에 관련 코드·계획을 저장한다.

### 7단계 — PASS

- 분석: 신규 PIN은 프로그램 신뢰 토큰을 먼저 검증한 뒤 저장한다. 마스터 비밀번호 없이 최초 PIN을 등록할 수 있는 시간은 토큰 발급 후 10분이며, 기존 PIN 변경에는 재인증이 필요하다. 기존 코드의 10분 판정은 DB `DATETIME`과 앱 시각을 섞어 사용했다.
- 수정: 최초 PIN 허용 시간을 DB `NOW()` 기준으로 계산하고 트랜잭션 안에서도 다시 확인한다. 개발 DB 통합 검사에 11분 지난 토큰의 재인증 요구를 추가했다.
- 검증: PIN 정책·인증 상태 테스트 4건, TypeScript, 변경 파일 ESLint 통과. POS·ADM·KDS 각각 신규 PIN 등록 후 로그인 200과 잘못된 PIN 401을 확인했다. ADM에서 11분 지난 토큰의 무비밀번호 등록 403, 마스터 비밀번호 재인증 후 등록 200을 확인했다. 모든 임시 직원 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-07.zip`에 PIN API·통합 검사·계획을 저장한다.

### 8단계 — PASS

- 분석: 로그아웃은 직원 세션만 종료하고 프로그램 신뢰 토큰은 유지한다. PIN 로그인 API는 해당 프로그램의 유효 토큰을 먼저 확인한다.
- 검증: 인증 상태 단위 테스트 3건과 검사 스크립트 ESLint 통과. 개발 DB 임시 직원으로 POS·ADM·KDS 각각 로그아웃 뒤 토큰이 유지됨을 확인했다. 토큰 없는 PIN 로그인은 403, 유효 토큰+PIN 재접속은 200, 토큰 폐기 후 기존 세션·PIN 재로그인은 차단됐다. 임시 계정 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-08.zip`에 재접속 검사와 관련 코드를 저장한다.

### 9단계 — PASS

- 분석: 직원 수정 API는 해제한 프로그램의 토큰과 관련 세션을 폐기하고, 비활성화 시 모든 프로그램 접근을 끊는다. 퇴사 API는 모든 토큰·세션과 프로그램 권한을 종료한다. 두 API 모두 최고관리자 2차 인증을 요구한다.
- 검증: 직원 수정 단위 테스트 6건 및 새 통합 검사 ESLint 통과. `integration-staff-access-lifecycle-test.cjs`에서 2차 인증 없는 수정 428, 인증 후 KDS 권한 해제, 계정 비활성화, 퇴사 API의 토큰·세션·권한 차단을 개발 DB에서 확인했다. 임시 최고관리자와 직원 정리 완료.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-09.zip`에 관련 API·검사·계획을 저장한다.

### 10단계 — PASS

- 분석: 단계 1~9 변경의 통합 회귀, 개발 DB 상태, 빌드와 배포 필요 여부를 확인했다.
- 검증: 인증 관련 단위 테스트 51건, 변경 파일 ESLint, 프로덕션 빌드 및 TypeScript 검사가 통과했다. 개발 DB에서 마스터 복구, POS·ADM·KDS 토큰/PIN/재접속, 최고관리자 2차 인증을 거친 직원 권한 생애주기, 임시 비밀번호 교체를 실제 API로 검사했다. 헤드리스 Chrome에서 ADM 복구 화면의 ID 확인·등록·만료·재설정 분기를 검사했다. 각 통합 검사는 임시 데이터를 정리했다.
- DB 상태: 이 작업에서 마이그레이션을 적용하지 않았다. `TDK_POS_TEST`의 인증 스키마는 준비 상태이며 검증 후 기존 직원 4명, 활성 신뢰 토큰 0건이다. 기존 `sondows`의 마스터 비밀번호 해시는 여전히 `NULL`이고 활성 복구 권한은 0건이다. 운영 DB `TDK_POS`는 변경하지 않았다.
- 배포: 코드 변경을 실제 운영에 반영하려면 NAS 배포와 운영 DB 마이그레이션이 필요하다. 두 작업은 사용자 승인 후 진행한다. 기존 최고관리자의 실제 최초 인증은 본인의 일회용 복구 링크 사용과 비밀번호 등록 후 별도로 확인해야 한다.
- 체크포인트: `checkpoints/20261031-adm-auth-stage-10.zip`에 최종 소스·마이그레이션·스크립트·계획 스냅샷을 저장한다.

## 실제 계정 수용 및 운영 전환

| 항목 | 현재 상태 | 다음 조건 |
| --- | --- | --- |
| 기존 `TDK_POS_TEST` 최고관리자 `sondows`의 직접 최초 인증 | BLOCKED | 본인이 15분 유효한 일회용 복구 링크에서 마스터 비밀번호를 등록하고 ADM 로그인·개인 PIN·2차 인증을 확인해야 한다. 현재 활성 링크는 없다. |
| 운영 DB `TDK_POS` 마이그레이션 및 NAS 배포 | BLOCKED | 사용자 승인과 운영 백업 확인이 필요하다. 승인 전에는 운영 데이터를 변경하지 않는다. |

전체 저장소의 기존 ESLint 오류는 이번 인증 변경과 별개로 남아 있다. 이번 변경 파일만 대상으로 한 ESLint는 통과했다. 빌드의 메뉴 이미지 저장 경로 경고 2건도 기존 파일에서 발생한다.

## ADM 로그인 ID 입력값 전달 재확인 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `sondows` 입력의 화면 상태·입력 이벤트·기존 API 전달 확인 | ADM 로그인 화면 및 기존 복구 상태 조회 경로의 진단, 필요 시 ID 전달 부분만 | 개발 서버 및 기존 코드 확인 | ADM ID 입력과 상태 조회 | 실제 브라우저 입력·Enter·자동입력 유사 이벤트·기존 API 요청과 응답을 구분해 기록 | 개발 서버 브라우저 검사, 관련 단위 테스트, 서버 라우트 확인 | PASS |

이 단계에서는 마스터 비밀번호, PIN, 토큰, 권한, DB 구조, 인증 정책, POS·KDS 기능을 수정하지 않는다. 유효한 복구 권한이 없는 일반 로그인에서 계정 상태가 노출되지 않는 기존 정책은 유지한다.

### 1단계 — PASS: 진단 완료

- `src/components/ProgramTrustGate.tsx`의 ID 입력은 `value={loginId}`와 `onChange`의 `setLoginId(event.target.value)`로 연결된다. 앱 전용 `onBlur` 처리기는 없으며, 포커스 해제로 계정 조회를 시작하지 않는다.
- 개발 서버의 실제 `/tdkadm/login`에서 `sondows`를 입력한 뒤 화면 값과 React 렌더 속성 값이 모두 `sondows`임을 확인했다. 브라우저 이벤트는 `input` 3회, `change` 1회, `blur` 1회, Enter 1회였다. 포커스 해제와 Enter 후에도 ID가 유지됐다. 자동완성에 준하는 native setter + `input` 이벤트 후에도 두 값이 일치했다. 브라우저에 저장된 자격 증명의 실제 자동완성은 재현하지 않았다.
- 일반 ADM 로그인은 최초 로딩에 `GET /api/admin-center/trust`, `GET /api/admin-center/trust/initialize`를 호출한다. 이 요청은 ID를 포함하지 않는다. ID 입력·포커스 해제·비밀번호 없는 Enter 중 계정 상태 `POST` 호출은 없었다. 따라서 일반 화면에서 ID만 입력해도 계정 상태가 반영될 것이라는 기대는 현재 코드와 다르다.
- 기존 `POST /api/program-trust/master-recovery/status`는 유효한 일회용 복구 링크가 있을 때 `계정 상태 확인` 제출로만 호출된다. `master-recovery-client.test.mjs` 3건 통과: `sondows`를 요청 본문에 담는 동작, 다른 ID·권한 부재 응답 거절, 응답에 따른 분기를 확인했다. 서버 라우트는 본문 ID를 읽어 유효한 복구 권한과 계정을 함께 조회한다. 실제 `sondows` 계정의 유효한 복구 권한이 없어 이번 진단에서 해당 계정에 대한 서버 상태 응답은 검증하지 않았다.
- 수정: 진단 전용 `scripts/check-adm-id-input-test.cjs`와 이 계획 기록만 추가했다. 인증 코드와 DB 구조·데이터는 변경하지 않았다. 진단 스크립트 ESLint 통과. 운영 로그는 추가하지 않았다.
- 체크포인트: `checkpoints/20261031-adm-id-input-stage-01.zip`.

## ADM 마스터 비밀번호 최초 등록 및 화면 복귀 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | NAS 승인 권한으로 해시 미등록 계정의 마스터 비밀번호만 저장하고 최초 인증 화면으로 복귀 | ADM `ProgramTrustGate`, 전용 최초 등록 API, 격리 DB 브라우저/API 테스트 | ADM ID 전달 진단 PASS, 기존 복구 권한/해시 저장 방식 확인 | ADM 승인된 최초 등록 분기만 | 승인 없는 등록 거절, 해시 NULL 계정에만 scrypt 해시 저장, PIN·권한·세션·토큰 보존, 브라우저에서 지정 화면 복귀 | `TDK_POS_TEST` 임시 계정으로 API·DB·Chrome 검증 | PASS |

작업 제한: 실제 `sondows` 자격 증명 변경 금지. 운영 DB `TDK_POS`와 DB 구조 변경 금지. 최초 등록 API는 기존 비밀번호 재설정 API와 분리하고 세션·토큰·PIN을 변경하지 않는다. 성공 후에는 로그인이나 다음 인증 단계를 실행하지 않는다.

### 1단계 — PASS

- 분석: 기존 NAS 발급 복구 링크는 직원 계정과 일회용 권한을 묶고, 상태 조회는 ID와 비밀번호 해시 등록 여부를 확인한다. 기존 비밀번호 재설정 API는 세션·신뢰 토큰까지 폐기하므로 최초 등록에서는 재사용하지 않는다. `/api/admin-center/trust/initialize`는 기존 직원이 없는 신규 설치 전용이라 `sondows`에 적용할 수 없다.
- 권한: 기존 `TDK_POS_TEST`의 `sondows`는 활성 최고관리자이고 별도 소유자 2차 인증 상태는 `ACTIVE`지만 `security_password_hash`는 `NULL`이다. 현재 활성 NAS 복구 권한은 0건이다. 따라서 실제 계정 비밀번호는 설정하지 않았으며, 테스트에서는 NAS 발급 권한을 모사한 일회용 grant를 임시 계정에만 발급했다.
- 구현: ID blur 또는 Enter에서 기존 상태 API를 호출한다. NAS 승인 grant와 ID가 일치하고 마스터 해시가 없으면 `마스터 비밀번호 등록` 창을 자동으로 연다. 별도 `register-initial` API가 서버에서도 grant 유효성·계정 연결·해시 NULL을 재검증한 뒤 `scrypt` 해시를 `staff.security_password_hash`에 최초 한 번만 저장하고 grant를 소비한다. 해시가 이미 있거나 승인 토큰이 없으면 등록을 거절한다. 입력창은 길이·영문·숫자·특수문자·일치 조건을 화면과 서버 양쪽에서 검사한다.
- 완료 화면: 성공 시 등록창을 닫고 복구 URL 상태를 지운 뒤 동일 ID, 빈 마스터 비밀번호 입력창, `인증` 버튼으로 돌아온다. 인증 API, PIN, 토큰, 세션은 호출·발급하지 않는다.
- 검증: `check-adm-initial-master-registration-test.cjs`가 `TDK_POS_TEST` 임시 최고관리자와 실제 Chrome에서 blur·Enter 양쪽의 창 전환, 약한/불일치 비밀번호 차단, 승인 없는 요청 거절, 상태 및 등록 API 응답 200, 해시 저장, grant 재사용 거절, ID 유지·빈 비밀번호·`인증` 표시를 확인했다. 임시 계정은 cleanup 완료했다. 테스트 행은 기존 PIN 센티널과 ACTIVE 소유자 2차 인증 정보를 그대로 보존했으며 토큰·세션은 생성되지 않았다. 인증 관련 단위 테스트 12건, 변경 파일 ESLint, TypeScript 검사 모두 통과했다.
- DB/배포: 테이블 구조 및 운영 DB `TDK_POS`를 변경하지 않았다. 테스트는 격리된 `TDK_POS_TEST` 임시 행만 사용 후 삭제했다. 실제 `sondows` 화면 등록은 NAS 관리자가 15분 일회용 권한을 발급한 뒤 별도 수행해야 한다. 이 단계에서 실제 로그인·PIN·토큰 단계로 진행하지 않았다.
- 체크포인트: `checkpoints/20261031-adm-master-password-initial-stage-01.zip`.

## 개발 서버 HMR 404 및 수정 반영 재확인 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Next.js 개발 서버 HMR 연결·자동 반영을 확인하고 실행 상태를 재시작 | `server.cjs`, Next 설정·Proxy, HMR 진단 스크립트, 계획 기록 | 현재 3000 포트 서버 식별 | 개발 서버와 ADM 화면 갱신 | 개발 모드·올바른 프로젝트 경로·WebSocket 101·실제 소스 자동 반영·일반 새로고침·POS/ADM/KDS 경로 확인 | 재시작 전후 Chrome CDP와 임시 문구 변경 및 복구 | PASS |

### 1단계 — PASS

- 조사: `npm run dev`는 `node server.cjs`를 실행하며 `NODE_ENV`가 production이 아닐 때 `next({dev:true})`로 동작한다. 설치 버전은 Next.js 16.3.5, Turbopack이다. `getRequestHandler()`가 첫 요청의 Node HTTP 서버에서 Next 업그레이드 핸들러를 등록한다. `src/proxy.ts`와 인증 분기는 일반 HTTP 요청에 적용되며 정상 HMR WebSocket 업그레이드를 차단하지 않는다.
- 원인: 유효한 HMR은 `GET /_next/hmr?id=...` 형태의 WebSocket Upgrade이고 응답 `101`이 정상이다. Upgrade 헤더 없이 같은 경로를 일반 HTTP GET으로 요청하면 `404`가 반환된다. 재시작 직후 개발 로그에는 진단용 새 Chrome과 별개인 HMR `GET` 404가 한 차례 있었지만, 해당 요청 헤더와 출처는 수집하지 않아 오래된 세션 ID인지 비 Upgrade 요청인지 구분할 수 없었다. 진단용 새 Chrome의 WebSocket은 `101`을 받았고 HTTP 응답 404는 없었다. 서버 설정 오류는 재현되지 않았다. 기존 브라우저 탭에서 오류가 남으면 새로고침해 새 HMR 연결을 만든다.
- 경로: 포트 3000 소유 트리는 `npm run dev` → `node server.cjs`였고, Next가 시작 로그에서 현재 `D:\10_프로그래밍_소스\01_TDK_Web\tdk-pos`를 사용함을 확인했다. 실제 파일을 임시 변경해 브라우저 화면에서 읽어들인 것으로 소스·서버 경로가 일치함도 검증했다. 재시작 전후 임시 문구를 복구했다.
- 캐시/PWA: 프로젝트에 Service Worker 등록 코드나 서비스 워커 파일이 없다. 새 Chrome 프로필에서 localhost 서비스 워커 0개, Cache Storage 키 0개를 확인했다. 기존 사용자 프로필의 잔존 SW는 직접 접근하지 않았으며 이번 새 브라우저 검증에서는 PWA 캐시 영향이 없었다.
- 재시작 및 검증: 기존 터미널 세션에 연결할 수 없어 Ctrl-C와 비강제 종료를 시도했으나 종료되지 않았다. 포트 소유 트리를 재확인한 뒤 해당 개발 서버 프로세스만 종료하고 `npm run dev`를 다시 실행했다. 새 서버는 현재 실행 중이다. Chrome에서 `http://localhost:3000` 및 허용된 `http://192.168.0.54:3000` 모두 HMR 연결 101, 임시 텍스트의 자동 재컴파일·화면 반영, 원문 복구, 일반 새로고침 최신 화면 표시를 확인했다. Next 로그에 `Compiled in 2.5–2.8s`가 기록됐다. `/tdkadm/login`, `/tdkpos/login`, `/tdkkds`는 HTTP 200이었다.
- 변경/DB/운영: 런타임 서버·Proxy·인증 코드는 변경하지 않았다. `scripts/check-dev-hmr-test.cjs`는 임시 소스 문구를 자동 복구하는 개발 진단용으로 추가했다. `.next` 캐시를 삭제하지 않았고 DB·운영 빌드·Docker·NAS는 건드리지 않았다.
- 체크포인트: `checkpoints/20261031-dev-hmr-stage-01.zip`.

## ADM 최초 마스터 비밀번호 등록 흐름 단순화 — 2026-10-31

이 단계는 사용자의 최신 지시가 기존의 일회용 복구 링크 기반 최초 등록 정책을 대체한다. 별도 비밀번호 재설정용 복구 링크는 유지한다.

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 최초 설치·복구 경로와 개발 DB 계정 상태 분석 | 초기화 API, 복구 API, ADM 화면, `TDK_POS_TEST` | 기존 코드와 개발 DB 읽기 | ADM 최초 등록 | `sondows` 해시 NULL 및 기존 권한·PIN 상태 확인 | 읽기 전용 `check-owner-first-auth-test.cjs` | PASS |
| 2 | NAS 로컬 초기 설정 경계 구현 | `kds-ingress.cjs`, `nas-owner-setup.ts`, 외부 Host 접근 정책 | 1 PASS | 최초 등록 API | 모드 미설정·LAN·외부 Host·위조 헤더 차단 | 입구 단위 테스트와 실제 HTTP Host 요청 | PASS |
| 3 | 최초 설치와 기존 최고관리자 NULL 해시 등록 | 초기화 API, 상태 API, 최초 등록 API | 2 PASS | 최고관리자 최초 비밀번호 | 1회 완료 표식, NULL 해시에만 해시 저장, 기존 PIN·권한 유지 | 최초 설치 API 단위 테스트, 개발 DB 격리 계정 통합 테스트 | PASS |
| 4 | ADM 등록창 및 인증 화면 복귀 | `ProgramTrustGate.tsx`, 인증 단계 흐름 | 3 PASS | ADM 로그인 화면 | ID blur·등록창·저장·ID 유지·빈 비밀번호·인증 버튼 | 실제 Chrome, `sondows` 읽기 전용 등록창과 격리 계정 저장 | PASS |
| 5 | 회귀 검증·운영 절차·복구 지점 | 관련 테스트, 문서, 체크포인트 | 4 PASS | 배포 전 검증 | 일반 모드 차단, 경로 200, 문서와 결과 기록 | TypeScript·ESLint·단위 테스트·일반 서버 API | PASS |

검증 결과: `TDK_POS_TEST`의 실제 `sondows`는 테스트 전후 모두 활성 최고관리자이며 `security_password_hash=NULL`, PIN·소유자 2차 인증 상태 유지. NAS 로컬 설정 모드에서 `sondows` ID의 blur와 Enter 후 실제 Chrome 등록창 표시를 확인했으며 비밀번호는 입력하거나 변경하지 않았다. 격리 계정에서는 실제 Chrome 등록·해시 저장·재등록 409·권한과 PIN 유지·ID 유지 및 빈 비밀번호와 `인증` 버튼 복귀를 확인하고 임시 행을 정리했다. 외부 Host는 403, 모드 종료 후 로컬 상태·등록 API도 403이다. 관련 단위 테스트 18건, TypeScript, ESLint 통과. 일반 모드에서 ADM·POS·KDS 경로는 모두 HTTP 200.

최초 설치 분기: 서버 1회 완료 표식과 중복 차단은 단위 테스트 통과. Chrome에서는 초기 설치 가능 API 응답을 모의해 ID·마스터 비밀번호·확인 입력 화면을 확인했다. 실제 빈 DB를 이용한 최초 최고관리자 생성은 기존 개발 데이터 보존 때문에 미검증이다. 운영 DB `TDK_POS`, DB 테이블 구조, 실제 `sondows` 비밀번호, PIN·토큰·세션, NAS 운영 배포는 변경하지 않았다.

복구 지점: `checkpoints/20261031-adm-nas-initial-setup.zip`에 이 단계에서 수정한 코드·테스트·문서·계획을 저장했다.

## ADM ID 입력 후 계정 상태 조회 루틴 점검 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 입력·조회·접근 제어와 개발 DB 상태 확인 | `ProgramTrustGate.tsx`, 기존 상태 API, `TDK_POS_TEST` | 이전 최초 등록 단계 PASS | ADM 최초 인증 화면 | 일반 모드와 NAS 설정 모드의 응답 차이, `sondows`·토큰 상태 확인 | 코드 추적·읽기 전용 DB/API·Chrome 요청 기록 | PASS |
| 2 | 누락된 입력값 확정 연결만 수정 | ADM ID 입력 이벤트 | 1 PASS | ADM ID 자동완성·초기값 | DOM 값과 React 상태를 일치시키고 최신 ID만 반영 | Chrome 입력·자동완성·연속 변경 | PASS |
| 3 | 실제 브라우저 및 회귀 검증 | Chrome, TypeScript, ESLint | 2 PASS | ADM 화면 | 조회 요청·응답·화면 상태와 일반 모드 차단 확인 | Chrome CDP·관련 정적 검사 | PASS |

운영 DB `TDK_POS`, 개발 DB의 계정·비밀번호·PIN·보안토큰 데이터와 스키마, 마스터 비밀번호 등록·PIN·보안토큰 발급 로직은 변경하지 않는다. 기존 상태 조회 API의 시도 제한 기록은 요청에 따라 증가한다.

- 원인: 일반 입력의 `onChange`·`onBlur`·Enter와 기존 상태 조회 POST는 실행됐다. 일반 개발 서버는 `TDK_NAS_OWNER_SETUP` 미설정이어서 `POST /api/admin-center/trust/initial-master/status`에 403/`available:false`를 반환하므로 화면 변경이 없는 것은 기존 접근 제어의 결과다. 자동완성으로 DOM에만 ID가 채워지고 `onChange`가 없으면 기존 함수가 빈 React 상태를 읽어 조회를 생략하는 누락도 있었다.
- 수정: ADM ID 확정 시 실제 입력 DOM 값을 React 상태와 기존 조회 함수에 전달하고, 화면이 처음 나타날 때 미리 입력된 DOM 값을 확인한다. 동일 ID 중복 조회를 억제하며 ID 변경·로그인 진행 시 이전 응답을 무시한다. 새 API와 등록 권한은 추가하지 않았다.
- 개발 DB 읽기 전용 확인: `sondows`는 활성 OWNER·ADM 허용·해시 NULL이며 최초 설치 완료 표식은 이미 완료 상태다. `sondows`의 ADM 토큰 행은 0건, 새 Chrome 프로필의 신뢰 토큰 상태는 `trusted:false`였다. 테스트 전후 해시·PIN·2차 인증 상태는 유지됐다.
- 실제 Chrome 일반 모드: `sondows` 입력·blur·Enter, 다른 ID로 변경, DOM 값만 채운 초기 자동 입력에서 상태 조회 요청을 확인했다. 요청 ID·서버 403/`available:false`·React 표시값 일치·등록창 미표시를 확인했다.
- 실제 Chrome NAS 설정 모드: `sondows` 요청의 200/`available:true`와 등록창 표시를 확인했다. 이후 개발 DB의 기존 15분 상태 조회 제한 버킷이 31회가 되어 다음 요청은 429였다. 제한 행을 삭제하거나 초기화하지 않았다.
- Chrome 모의 API 응답: 200/`available:true`·200/`available:false`로 ID 재조회, 초기 자동 입력, 늦게 도착한 이전 ID 응답 무시를 확인했다. 이 세부 동작의 연속 실서버 재검증은 429 때문에 미실시다.
- TypeScript, 변경 파일 ESLint, 브라우저 테스트 통과. NAS 설정 모드를 종료한 일반 개발 서버에서 상태 API 403과 `trusted:false`를 재확인했다. 복구 지점: `checkpoints/20261031-adm-id-status-stage-01.zip`.

## ADM ID → 다음 로그인 화면 전환 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 ID·토큰·등록 상태 API 분석 | ProgramTrustGate, trust/status, initialize, initial-master/status | 이전 ID 조회 단계 PASS | ADM 최초 인증 화면 | 기존 API로 PIN·비밀번호·등록 화면을 분기할 수 있음 | 코드 추적·읽기 전용 개발 DB 조회 | IN_PROGRESS |
| 2 | ID 입력 → 다음 버튼 → 기존 상태 API 연결 | ProgramTrustGate, ADM PIN 화면의 선택 ID 전달 | 1 PASS | ADM 화면 전환 | 자동 조회 제거, 중복 제출 방지, 오류·뒤로가기·ID 유지 | Chrome 및 기존 화면 회귀 | PASS |
| 3 | 조건별 전환 검증 및 기록 | ADM UI 단위·브라우저 검증, PLANS | 2 PASS | ADM 화면 | 토큰·비밀번호·등록 권한 분기 확인 | Chrome, 테스트 계정/모의 응답, TypeScript·ESLint | PASS |

마스터 비밀번호 저장·검증 API, PIN 인증 API, 토큰 발급, DB 스키마·기존 계정·권한은 이 단계에서 수정하지 않는다. 운영 DB `TDK_POS`는 변경하지 않는다.
## ADM 로그인 ID → 다음 화면 전환 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 상태 조회 API와 화면 흐름 확인 | ProgramTrustGate, 기존 trust/initialize/initial-master/status API | ID 상태 조회 단계 PASS | ADM 최초 인증 화면 | 기존 API와 권한 검증 유지 | 코드 추적 및 일반 모드 응답 확인 | PASS |
| 2 | ID 입력 후 다음 버튼에서만 상태 조회하고 결과별 화면 이동 | ProgramTrustGate, AdminLoginForm, program-auth-flow | 1 PASS | ADM 최초 인증 및 PIN 진입 화면 | 자동 조회 제거, 중복 요청 차단, ID 유지 및 뒤로가기 | Chrome에서 입력·요청·분기 검증 | PASS |
| 3 | 오류 및 접근 권한 차단 검증과 기록 | Chrome 검사 스크립트, PLANS | 2 PASS | ADM 로그인 화면 | 일반 모드 등록 거부, 실패 안내, 기존 계정 데이터 보존 | 실제 일반 모드 요청과 모의 상태별 응답을 구분해 확인 | PASS |

- ID 입력 중 onChange/onBlur 및 자동완성 동기화는 상태 조회를 호출하지 않는다. 다음 버튼 제출만 기존 상태 API 세 곳(trust, initialize, initial-master/status)을 호출한다. 요청 중 버튼을 비활성화하고 동기화 잠금도 적용한다.
- 상태에 따라 유효 토큰은 기존 PIN 화면, 토큰이 없으면 기존 마스터 비밀번호 화면, 서버가 허가한 최초 등록은 기존 등록창, 초기 설치는 기존 최고관리자 등록 화면으로 이동한다. 실패 시 ID 화면에 오류를 표시한다. 화면 뒤로가기와 PIN 진입 시 ID를 유지한다.
- 일반 개발 모드 Chrome 요청에서 ID `sondows`가 상태 API에 전달되고 최초 등록 상태 API가 403을 반환하며 비밀번호 화면으로 이동하는 것을 확인했다. 따라서 ID만으로 비밀번호 등록창이 열리지 않는다.
- Chrome headless CDP 검증에서 입력만으로 API가 호출되지 않는 점, 응답 대기 중 중복 요청 차단, 토큰/PIN 분기, 초기 설치 분기, 서버 허가 등록창 분기, 서버 오류 안내, ID 유지 및 뒤로가기를 확인했다. 이 분기들의 응답은 격리된 브라우저 요청 모의 응답으로 검증했으며, 실제 NAS 초기 설정 권한으로 DB를 변경하지 않았다.
- TypeScript `tsc --noEmit`, 변경 파일 ESLint, 검증 스크립트 `node --check`, Chrome 검증을 통과했다. API, DB 스키마/데이터, 운영 DB `TDK_POS`는 변경하지 않았다.
- 복구 체크포인트: `checkpoints/20261031-adm-id-next-stage-01.zip`.

## ADM ID 다음 이후 화면 분기 오분기 수정 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | TDK_POS_TEST 계정, bootstrap latch, 초기 설정 모드/API 상태 확인 | TDK_POS_TEST 및 기존 상태 API | ADM ID 다음 화면 기존 구현 | ADM 로그인 분기 | DB/API 응답을 읽기 전용으로 확인 | MySQL SELECT 및 실제 로컬 API 요청 | PASS |
| 2 | 등록 허용·비허용·비밀번호 등록 상태별 분기 수정 | 기존 initial-master/status API 응답, ProgramTrustGate | 1 PASS | ADM ID 다음 이후 화면 | 미등록·비허가 계정이 비밀번호 인증으로 오분기하지 않음 | TypeScript, ESLint, Chrome 분기 검사 | IN_PROGRESS |
| 3 | 실제 승인 초기 설정에서 sondows 등록 화면 검증 | 개발 서버, Chrome, TDK_POS_TEST | 2 구현 | ADM 최초 설정 화면 | 실제 API 200/available:true 및 등록창 표시 | Chrome에서 API와 화면을 함께 확인 | BLOCKED |

- 읽기 전용 DB 확인: TDK_POS_TEST에서 sondows 계정 존재, master hash NULL, OWNER, 활성, ADM 허용, 미퇴사, owner 레코드 존재. security_bootstrap_state.completed_at은 설정 완료 상태.
- 최초 설정 모드는 기본 서버에서 비활성. 일반 모드 실 API는 initial-master/status 403 available:false, initialize 200 available:false, trust 200 trusted:false를 반환했다. 기존 화면은 setup status 403을 정상 분기로 취급한 다음 무조건 LOGIN_PASSWORD로 이동한 것이 오분기 원인.
- 수정: 승인 모드 응답에서만 기존 상태 API가 계정 존재/비밀번호 설정 여부를 함께 반환하도록 하고, 유효 owner의 미등록 계정은 기존 등록창, 등록된 계정은 비밀번호 화면, 등록 권한이 없는 미등록 계정은 안내만 표시한다. setup status 403도 ID 화면의 권한 안내로 남긴다. 등록 API, PIN/토큰, DB 구조·데이터 변경 없음.
- 일반 모드 실제 Chrome에서는 403 뒤 등록 권한 안내가 표시되고 비밀번호 입력 화면으로 이동하지 않는 것까지 확인했다. 격리된 응답 모의로 다른 분기도 확인했으나 실제 모드 검증의 대체 PASS로 취급하지 않는다.
- 실제 승인 모드 검증을 위해 개발 서버를 로컬 설정 모드로 재시작했으나, 상태 API가 기존 DB 요청 제한으로 429를 반환했다. 카운터는 33회였으며 초기화·우회하지 않았다. 검증 후 서버를 일반 모드로 재시작했다. 실제 available:true 및 등록창 노출은 미검증이므로 전체 단계 완료/PASS로 표시하지 않는다.
- 검증: TypeScript, 변경 파일 ESLint, 검증 스크립트 구문 검사, 일반 모드 Chrome 검증 통과. 개발 DB/운영 DB 데이터는 변경하지 않았다.
- 복구 체크포인트: checkpoints/20261031-adm-id-next-branch-fix.zip.
- 정정: API 검증은 기존 admin_auth_attempts 상태 조회 제한 카운터를 정상 증가시켰다. 계정/비밀번호/최초 설정 데이터는 변경하지 않았으며 이 카운터를 초기화하거나 우회하지 않았다. 승인 모드 검증은 카운터 33회로 429가 반환되어 실제 등록 가능 응답까지 미완료다.

## ADM 최초 설정 차단 원인 및 Windows 개발 모드 — 2026-10-31

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | NAS/DB/계정/초기화/API/요청 제한의 호출 순서와 차단 원인 확인 | ProgramTrustGate, setup status, initialize, ingress, auth limit | 이전 ID 분기 수정 | ADM 최초 등록만 | 계정 상태와 권한 정책, limiter 동작 확정 | 코드 추적 및 TDK_POS_TEST 읽기 전용 조회 | PASS |
| 2 | 최초 설정 계정 상태 판정 공통화, UI 분기 명확화 | 기존 status 및 register-initial API, 공통 정책 모듈, ProgramTrustGate | 1 PASS | ADM 최초 설정/인증 분기 | 최초 설치·비밀번호 미등록·등록됨·복구를 구분하고 권한 gate 유지 | 단위 테스트 및 typecheck | PASS |
| 3 | Windows 관리자용 TDK_POS_TEST 전용 개발 초기 설정 실행 절차 | Windows PowerShell 실행 스크립트, ingress attestation, 설정 문서 | 2 PASS | Windows 개발 환경 로컬 localhost만 | 상승된 관리자 토큰, 개발 모드, TDK_POS_TEST를 모두 확인; production 거부 | 스크립트 구문/비관리자 거부/ingress 단위 테스트 | IN_PROGRESS |
| 4 | 실제 Windows Chrome에서 sondows 등록창 표시 | dev 서버, Chrome, TDK_POS_TEST | 2·3 PASS 및 상태 조회 제한 해제 | ADM 최초 등록 화면 | 실제 DB 응답 available:true와 등록창 표시 | Chrome CDP 실제 API 확인, 비밀번호는 입력/저장하지 않음 | BLOCKED |

- 차단 원인: 일반 Windows npm run dev에는 NAS setup 플래그가 없어 기존 status API가 403을 반환했다. 이전 로컬 설정 모드 확인은 동일 IP 15분 상태조회 제한기에 걸려 429가 났다. DB의 admin_auth_attempts 해당 카운터는 기존 33회였으며 초기화/우회하지 않았다.
- TDK_POS_TEST 읽기 전용 조회에서는 sondows가 활성 OWNER/ADM 허용, 마스터 hash NULL, bootstrap latch 완료로 확인됐다. 그러므로 빈 DB 최초 관리자 분기가 아니라 기존 owner 비밀번호 미등록 분기가 적용되어야 한다.
- 최초 설정 상태 판단을 공통 분류 함수로 모으고 initialize GET/POST, 초기 마스터 상태 API 및 기존 초기 등록 write API가 같은 계정 판정 함수를 사용하게 했다. 복구 토큰 흐름은 별도로 유지했다.
- Windows 개발 절차는 관리자 토큰, NODE_ENV=development, DB_NAME=TDK_POS_TEST 조건을 검사한다. Node ingress는 localhost loopback 요청에만 내부 attestation을 붙이며, 브라우저 위조 헤더, LAN 요청, 운영 모드는 거부한다. NAS setup 경로는 유지했다.
- 검증: 일반 모드 실제 Chrome은 실 API 403 뒤 안내를 표시하고 마스터 비밀번호 인증 화면으로 이동하지 않았다. 분류 단위 테스트 2개, ingress 테스트 9개, TypeScript, ESLint, PowerShell 구문 검사를 통과했다. 비관리자 실행은 명시적으로 거부됐다.
- 현재 실행 환경의 Windows 관리자 토큰은 비상승 상태다. 따라서 안전 스크립트로 설정 모드를 시작할 수 없어 실제 설정 모드 DB 응답과 Chrome 등록창은 검증하지 못했다. 모의 응답 분기는 통과했지만 PASS로 계산하지 않는다. 등록창 검증 단계는 BLOCKED로 남기고, 사용자 비밀번호 입력/DB 저장은 수행하지 않았다.
- 운영 DB TDK_POS 및 계정/해시/PIN/권한/최초 설정 데이터 변경 없음. 복구 체크포인트: checkpoints/20261031-adm-windows-owner-setup.zip.
- 일반 Chrome 검증 후 이 작업에서 실행한 일반 모드 개발 서버를 종료해 3000 포트를 비웠다. 관리자 PowerShell에서 전용 스크립트를 바로 시작할 수 있다. 제한 카운터는 마지막 읽기 전용 조회 시 33회/984초 경과로 15분 창을 지난 상태였다.

## Windows 개발 초기 설정의 불필요한 상태조회 제한 분리 — 2026-11-01

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 현재 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | ADM 진입 시 자동 호출 여부와 429 발생 조건 확인 | ProgramTrustGate, initial-master/status, admin-auth-limit | Windows 초기 설정 모드 지원 | ADM 최초 ID 다음 | 자동 호출 및 limiter 위치 확인 | 코드 추적, 기존 30회/15분 제한 동작 확인 | PASS |
| 2 | Windows 관리자·개발 DB·localhost 설정 흐름에 한해 상태조회 limiter 충돌 제거 | owner setup mode, initial-master/status | 1 PASS | Windows 개발 초기 등록 상태 조회 | local dev는 반복 조회 차단 오류 없음, NAS/일반 경로 limiter 유지 | 정책 단위 테스트, TypeScript, ESLint | PASS |
| 3 | 제한 이력 보존 및 결과 문서화 | PLANS, checkpoint | 2 PASS | 문서 | limiter 카운터 삭제/초기화 없이 검증 | 관련 테스트 및 코드 검사 | PASS |

- 실제 원인: ADM 첫 화면 진입 자체는 계정 상태 API를 호출하지 않는다. ID 입력 후 다음을 누를 때 initial-master/status가 호출된다. 상태 API는 승인된 설정 모드 요청마다 15분 IP 제한 카운터를 증가시키며 30회를 넘으면 429를 반환한다. 이전 조회 시 34회로 제한 창 안에 있었다.
- 수정: 인증 정책이나 카운터 기록을 지우지 않고, Windows 개발 전용 모드(NODE_ENV=development, DB_NAME=TDK_POS_TEST, TDK_WINDOWS_DEV_OWNER_SETUP=1)에서는 기존 loopback setup attestation 검사 이후에만 이 읽기 전용 상태조회 rate limit을 생략한다. NAS setup 및 다른 경로의 30회/15분 제한은 유지한다. 비밀번호 등록 write 실패 제한과 OWNER/hash NULL 검사도 그대로 유지.
- 기존 제한 카운터는 변경/삭제하지 않았다. production, 운영 DB, NAS 모드에서는 제한 로직이 유지됨을 정책 테스트로 확인.
- 검증: TypeScript, ESLint, 상태 정책 테스트 3건, ingress 보안 테스트 9건 통과. Chrome 실화면 검증은 이번 변경 범위에서 수행하지 않았다.
- 복구 체크포인트: checkpoints/20261101-adm-windows-status-limit.zip.

## 3000번 ADM 최초 설정 요청 제한 오류의 런타임 원인 — 2026-11-01

- 재현: 현재 `http://localhost:3000/api/admin-center/trust/initial-master/status`에 `sondows`를 1회 요청했고 HTTP 429, `{"available":false}`를 확인했다. DB·계정·마스터 비밀번호 저장 API는 호출하거나 변경하지 않았다.
- 코드 원인: 429는 기존 15분 요청 제한을 Windows 개발 설정 모드가 해제하지 못할 때 반환된다. 소스에는 개발 DB `TDK_POS_TEST`와 `TDK_WINDOWS_DEV_OWNER_SETUP=1`이 모두 설정된 경우 제한을 면제하는 로직이 있으며, 해당 정책 단위 테스트는 통과한다.
- 실행 원인: 현 요청이 429인 점으로 미루어 현재 응답 프로세스의 유효 런타임 환경은 Windows 설정 모드가 아니다. 실제로 포트 3000에 기존 PID 533464가 LISTENING 중이며, 프로세스 정보 조회는 권한 거부되어 어느 터미널에서 어떤 환경으로 시작됐는지는 확인할 수 없었다. 기존 프로세스가 일반 `npm run dev`로 시작된 상태에서 설정 스크립트 실행이 포트 충돌로 실패했거나, 브라우저가 그 서버에 계속 접속하는 상황이 root cause다. 제한 카운터나 초기 설정 latch를 지우지 않았다.
- 수정: `scripts/start-windows-owner-setup.ps1`는 기존 개발 서버를 종료하지 않고 첫 빈 포트(기본 3000, 현재처럼 점유 중이면 3001)를 선택해 전용 설정 서버를 띄운다. 시작 URL과 설정 모드/DB 이름을 출력한다. `server.cjs`도 개발 서버 시작 시 DB 이름과 Windows owner setup 활성 여부만 출력한다(비밀값 출력 없음).
- 검증: PowerShell 파서 PASS, `node --check server.cjs` PASS, TypeScript `tsc --noEmit` PASS, 변경 관련 ESLint PASS, `node --experimental-strip-types --test src/lib/initial-admin-setup.test.mjs` 3/3 PASS. 직접 브라우저 설정 모드의 등록 화면 검증은 현재 서버 프로세스를 재시작하지 못해 BLOCKED이며 PASS 처리하지 않는다.
- DB 변경 없음. 운영 DB `TDK_POS` 변경 없음. 테스트용 비밀번호 저장 없음.
- 다음 재개 시: 관리자 PowerShell에서 기존 3000 개발 서버를 실행한 터미널에서 Ctrl+C로 종료하고, `Set-Location 'D:\10_프로그래밍_소스\01_TDK_Web\tdk-pos'; .\scripts\start-windows-owner-setup.ps1` 실행. 서버 시작 시 `DB_NAME=TDK_POS_TEST, Windows owner setup=enabled`를 확인하고 브라우저에서 `http://localhost:3000/tdkadm` 새로고침 후 `sondows` 조회 결과를 확인한다.
## 마스터 비밀번호 → 프로그램 토큰 → PIN 연결 — 2026-11-01

| 단계 | 목표 | 수정 대상 | 선행 조건 | 완료 기준 | 검증 | 상태 |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 마스터 비밀번호 인증 결과가 다음 단계로 연결 | ProgramTrustGate, trust enrollment API | 기존 인증/계정 확인 | 일반 설정 모드에서 setup 전용 403은 등록 거절로 유지하면서 일반 비밀번호 인증은 진행; 실패 시 토큰 없음 | `TDK_POS_TEST` 임시 직원 실 API: 잘못된 비밀번호 401, 정답 200 | PASS |
| 2 | 프로그램 토큰 해시 저장 및 안전 쿠키 발급/사용 | program trust API, DB, 쿠키 | 1 PASS | 무작위 토큰, DB SHA-256, Secure·HttpOnly·SameSite 쿠키, 프로그램 간 분리, 기존 유효 토큰 재사용 | 실제 ADM API/DB 통합 검사 통과. 브라우저의 실제 쿠키 저장은 Chrome 검증 차단 | IN_PROGRESS |
| 3 | PIN 상태에 따른 등록/입력 분기 | ProgramTrustGate, trust status | 2 PASS | DB PIN 상태가 화면 분기와 일치 | 임시 계정 API는 pinSetupRequired=true; sondows는 기존 PIN 등록 | PASS |
| 4 | 최초 PIN 등록과 세션 생성 | `/api/program-trust/pin`, 세션 | 3 PASS | 6자리 정책, 해시 저장, 세션 쿠키/DB 행 | 임시 계정 실제 ADM API 통과, Chrome 화면은 미검증 | PASS |
| 5 | 기존 PIN 인증 및 로그인 | ADM 로그인 API/UI | 4 PASS | PIN 성공 시 세션, 실패 거부 | 임시 계정 실제 API 성공/실패 통과, Chrome 화면은 미검증 | IN_PROGRESS |
| 6 | 재접속 토큰 + PIN 흐름 | trust status, PIN login | 5 PASS | 유효 쿠키 후 PIN 재로그인, 폐기/퇴사 토큰 거부 | 임시 계정 API 재접속 통과, Chrome 쿠키 자동 저장은 미검증 | TODO |

- sondows 읽기 전용 상태: TDK_POS_TEST, staff_id=1, 활성 OWNER, ADM 권한, 퇴사 아님, 마스터 해시 등록(scrypt), 개인 PIN 등록, 활성 ADM 토큰 1건, 최근 마스터 로그인 잠금 없음. 그러므로 이 계정에서 `ID + PIN` 화면은 유효 토큰과 기존 PIN에 따른 정상 분기이며 PIN 등록 화면으로 바뀌면 안 된다.
- 차단 원인: ADM ID 다음 분기는 등록 권한 전용 `initial-master/status` API가 일반 로그인에서 반환하는 403을 전체 인증 실패로 처리했다. 이 때문에 마스터 해시가 있는 일반 계정도 비밀번호 인증 단계에 도달하지 못했다.
- 수정: setup status 403은 계정/해시 정보를 노출하지 않고 `LOGIN_PASSWORD`로 진행한다. API가 일반 계정의 마스터 해시를 검증하며, 미등록/없는/비활성/권한 없는 계정은 기존 generic 실패 응답으로 거부된다. 최초 등록 허용 판정은 기존처럼 setup status의 승인 응답에만 의존한다.
- 실제 통합 검사(개발 DB에 임시 직원 1명 생성 후 정리): 잘못된 마스터 비밀번호 401 및 쿠키 없음, 올바른 비밀번호 ADM 토큰 발급 200, DB SHA-256 해시 일치 및 원문 미저장, HttpOnly+Secure+SameSite=Strict, 상태 API trusted=true, 최초 PIN 등록과 세션, 잘못된 PIN 401, PIN 로그인·재접속·페이지 200을 확인했다. `cleanup=complete`; 기존 sondows 행/비밀번호/PIN/토큰은 변경하지 않았다.
- 단위 테스트 8건, TypeScript, ESLint, Node 구문 검사는 통과했다. Chrome CDP 검증은 새 격리 프로필에서도 `Page.enable timeout`으로 실패해 실제 UI 화면 및 브라우저 쿠키 자동 저장을 확인하지 못했다. 이를 PASS로 기록하지 않는다. 이 이유로 2단계에 머물며 3~6단계는 진행하지 않는다.
- 운영 DB TDK_POS, 스키마, 기존 직원 데이터 변경 없음. 테스트 계정은 개발 DB에서 제거 완료. 테스트 비밀번호/PIN은 로그에 출력하지 않았다.
## ADM 마스터 비밀번호 인증 단일화 — 2026-11-01

| 단계 | 목표 | 대상 | 선행 | 완료 기준 | 테스트 | 상태 |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 인증 API·검증 함수·저장 컬럼·호출처와 TDK_POS_TEST 상태 조사 | trust routes, owner-security routes, schema, read-only query | 없음 | 두 경로의 저장/검증 차이 및 이전 영향 범위 기록 | 코드 추적, 비밀값 없는 SELECT | PASS |
| 2 | OWNER 보안 확인이 직원 마스터 해시를 사용하게 전환 | admin-auth.ts, owner-password route | 1 PASS | 소유자 멤버십 검사는 별도로 유지, old owner hash fallback 없음 | helper/route tests, TypeScript | PASS |
| 3 | 보안 메뉴 비밀번호 변경을 직원 마스터 해시 변경으로 연결 | owner-password route/UI | 2 PASS | 새 비밀번호가 ADM 인증과 보안 재인증에 동일, 세션·토큰 수명 정책 보존 | 개발 DB 임시 OWNER 통합 테스트 | PASS |
| 4 | OWNER 관리 흐름에서 레거시 비밀번호 인증 의존 제거 | owners route/UI, owner helper | 2 PASS | 권한 관리는 membership 기반, 레거시 hash는 인증·가용성 판정에 미사용 | owner management/role tests | PASS |
| 5 | 문구 변경 및 POS·ADM·KDS 회귀 | OwnerSecurityPrompt, auth routes/tests | 2~4 PASS | 보안 확인에 ‘마스터 비밀번호’, 일반 직원 차단, 기존 PIN·토큰 보존 | 실제 API/DB + Chrome 가능한 항목, full relevant suite | IN_PROGRESS |

- 조사 결과: ADM trust enrollment(`src/lib/program-trust-routes.ts`)는 `staff.security_password_hash`를 `verifySecurityPassword`로 확인한다. ADM 보안 메뉴(`/api/admin-center/security/owner-password`, `getOwnerSecurityState`)는 `admin_security_owners.password_hash`와 `credential_state`를 별도로 확인한다. 직원 관리·토큰 관리·OWNER 관리 API는 `requireOwnerSecurityAccess`로 이 별도 상태에 의존한다.
- 저장: `staff.security_password_hash`는 직원별 마스터 비밀번호이며, `admin_security_owners.password_hash`는 기존 OWNER 전용 확인값이다. `admin_security_settings.owner_security_password_hash` 컬럼도 있으나 현재 런타임 코드에서는 참조되지 않는다. 두 scrypt 해시가 모두 설정된 것은 읽기 전용으로 확인했지만 해시 비교만으로 원문 비밀번호 동일/상이 여부를 단정하지 않는다.
- TDK_POS_TEST sondows: staff_id=1, 활성 OWNER/ADM 허용, 직원 마스터 해시 설정, OWNER 전용 해시 설정/ACTIVE, 개인 PIN 및 활성 ADM 토큰 존재. 두 해시 원문은 읽거나 기록하지 않았다.
- 정책: OWNER 여부는 `admin_security_owners` 멤버십으로 계속 판정하고, 인증만 `staff.security_password_hash`로 통합한다. 레거시 OWNER 해시는 삭제·덮어쓰기하지 않고 인증 fallback에도 쓰지 않는다. DB 스키마와 운영 DB `TDK_POS`는 변경하지 않는다.

- Implementation: ADM master login and OWNER security reauthentication both verify `staff.security_password_hash`. OWNER access is still gated separately by `admin_security_owners` membership. Legacy OWNER hash and status are no longer used for verification or availability; stored values and schema are preserved. Changing the master password updates only the staff master hash and clears OWNER reauthentication freshness. Existing PIN, program trust tokens, and login sessions remain active. Temporary master-password issuance can target another OWNER but blocks self-targeting.
- Actual TDK_POS_TEST API integration: temporary OWNER master login 200, master password change 200 and changed password ADM login 200, legacy OWNER password 401, master reauthentication 200, owner management 200, trust-token management 200, regular ADM employee owner-management access 403. Existing OWNER PIN hash and active token count stayed unchanged across password change; legacy OWNER hash stayed unchanged. Regular employee PIN setup/login/re-entry also passed. Temporary rows, tokens, sessions, and logs were cleaned (`cleanup=complete`).
- Read-only sondows state after test: TDK_POS_TEST; active OWNER with ADM access; master password and PIN configured; one active ADM token. No sondows credential or token data was changed.
- Verification: `tsc --noEmit` PASS, changed-file ESLint PASS, owner-password route/helper tests 7/7 PASS, program-trust tests 5/5 PASS, live development-server + TDK_POS_TEST API integration PASS. Direct Chrome UI inspection was unavailable, so visual rendering remains unverified and stage 5 stays IN_PROGRESS. No production DB, schema, or sondows data was changed.

- Screenshot follow-up: corrected the OWNER security prompt Korean strings that had been written as question marks. The source now contains UTF-8 Korean for the title, description, input label, and button. TypeScript and ESLint pass; post-fix visual browser confirmation is still pending.

## 공통 마스터 비밀번호 검증 함수 통합 — 2026-11-01

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 기존 비밀번호 검증 함수·API·해시 저장 위치 조사 | program-trust-routes, owner-password, temporary-password, PIN setup | 없음 | POS/ADM/KDS 최초 인증 및 ADM 보안 재인증 | 검증 코드가 분산된 위치와 레거시 저장소 사용 여부 기록 | 코드 추적, 스키마 확인, 읽기 전용 조회 | PASS |
| 2 | 직원 활성/퇴사 상태와 scrypt 해시를 확인하는 서버 공통 함수 구현 | src/lib/master-password.ts, 단위 테스트 | 1 PASS | 서버 내부 인증만 | 정상·오류·미등록·비활성·퇴사 계정 결과 검증 | 격리된 단위 테스트, TypeScript, ESLint | PASS |
| 3 | 프로그램 최초 인증 및 기존 마스터 검증 호출을 공통 함수로 교체 | program-trust-routes, temporary-password, PIN setup | 2 PASS | POS/ADM/KDS/HOS 공용 라우트 | 공통 함수 사용, 토큰/쿠키/PIN 로직 유지 | route tests, TDK_POS_TEST 임시 계정 통합 | PASS |
| 4 | ADM 보안 메뉴 재인증과 비밀번호 변경 검증을 공통 함수로 교체 | owner-password, 관리자 보안 route guards | 2 PASS | 직원·신뢰토큰·OWNER 관리 및 기타 OWNER 전용 API | 세션 직원 ID만 인증 대상으로 사용, OWNER 권한 분리 유지 | API 테스트, TDK_POS_TEST 임시 OWNER | PASS |
| 5 | 구형 OWNER 비밀번호 경로가 인증에 사용되지 않는지 확인 | auth helpers, owners route, 전체 참조 | 3~4 PASS | 레거시 데이터 보존 | 구형 해시 fallback 없음, 런타임 참조 제거 | 저장소 검색, 테스트 | PASS |
| 6 | 통합 회귀 검증 및 단계 결과 기록 | 관련 API와 기존 통합 테스트 | 3~5 PASS | POS/ADM/KDS | 공통 인증, 권한 차단, 기존 토큰/PIN 동작 확인 | TypeScript, ESLint, 단위·실제 API 통합 테스트 | PASS |

- 조사 결과: 현재 scrypt 비교 원시 함수는 `src/lib/auth.ts`의 `verifySecurityPassword(password, storedHash)`이며, 프로그램 trust enrollment와 PIN 재인증, 임시 비밀번호 변경, OWNER 재인증/변경에서 각각 직원 해시를 직접 가져와 호출한다.
- 저장 위치: 활성 직원 마스터 해시는 `staff.security_password_hash`이다. 구형 OWNER 비밀번호는 `admin_security_owners.password_hash`에 남아있을 수 있으며, 구형 전역 컬럼 `admin_security_settings.owner_security_password_hash`는 런타임 검증 경로에서 참조되지 않는다. 현재 인증 경로는 모두 직원별 해시를 향하도록 이미 전환되어 있으며 저장된 레거시 값은 보존한다.
- Stage 2 PASS: added server-only `verifyMasterPassword(employeeId, password)`; validates employee ID, active status, non-terminated status, configured staff master hash, and delegates scrypt comparison to the existing verifier. Unit tests 3/3, TypeScript, and ESLint passed.
- Stage 3 PASS: shared verifier applied to POS/ADM/KDS trust enrollment, temporary master-password replacement, and PIN reauthentication. Targeted tests, TypeScript, ESLint, and live TDK_POS_TEST integration passed; token, cookie, and PIN flows were retained.
- Stage 4 PASS: OWNER security reauthentication and password change use the shared verifier with the session actor staff ID; OWNER membership and route authorization remain separate. Route tests and live TDK_POS_TEST integration passed.
- Stage 5 PASS: runtime search shows `admin_security_owners.password_hash` and `credential_state` are not used for authentication; the only `owner_security_password_hash` reference is the preserved schema column. Removed the unused OWNER-only password hash/policy helpers. The generic scrypt comparator remains used only by `verifyMasterPassword`.
- Stage 6 PASS: 20 targeted unit/route tests passed. TDK_POS_TEST live program-trust integration passed for POS, ADM, and KDS: wrong master password 401, enrollment 200, wrong PIN 401, login/reconnect/page 200; temporary test data cleanup completed. Live OWNER integration passed: master login/change/re-auth, legacy OWNER password rejected, owner/trust-token management accepted, regular employee blocked, PIN/token hashes retained; cleanup completed. TypeScript and ESLint passed.
- No production DB or schema changes. No sondows credentials, PIN, trust tokens, or permissions were modified.



## sondows authentication reset and first-login retest preparation ? 2026-11-01

- Database guard and read-only preflight confirmed the connected database was exactly TDK_POS_TEST and the unique target was staff_id 1 / staff_code 001, role OWNER, active, ADM enabled, with one OWNER membership. No production database was accessed.
- Reset only staff.security_password_hash and staff.employee_pin_hash to NULL; set security_password_change_required to 0. No password or PIN was generated. Employee identity, OWNER membership/role, ADM permission, activation state, and work data were retained.
- Revoked the target employee's one active ADM program trust token and logged out the two active ADMIN sessions. No other program token/session counts changed.
- Post-transaction read-only verification: account present; OWNER membership 1; ADM enabled; master password and PIN unset; active ADM tokens 0; active ADMIN sessions 0. The first-owner bootstrap latch remains completed and unchanged.
- Recovery checkpoint: checkpoints/20261101-sondows-auth-reset-20261031230923182.dpapi. It contains only pre-reset credential hashes/flag and the affected ADM-token/session state, encrypted with Windows DPAPI for the current Windows user. Restore/decrypt only under that same Windows user if recovery is needed; never commit or share this file.
- Registration readiness: the existing-account route classifies an active OWNER with ADM access and a NULL master hash as MASTER_PASSWORD_REQUIRED. The one-way first-owner latch is not reset. Status/registration still require server setup attestation. The dedicated script enables it only for NODE_ENV=development, DB_NAME=TDK_POS_TEST, and TDK_WINDOWS_DEV_OWNER_SETUP=1.
- To start the isolated local setup server, open an elevated PowerShell in the project directory and run: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\start-windows-owner-setup.ps1. The script selects an available localhost port and prints the URL. Use that printed URL on this PC only, open /tdkadm, enter sondows, then choose Next. Enter the new master password and PIN directly in the browser. Stop the setup server with Ctrl+C after the test; the script's process-local setup mode ends with it.
- Verification limit: DB state and server route preconditions were checked. The setup server was not started and Chrome registration, token cookie, PIN enrollment, and re-entry were not browser-verified.
- No schema or authentication API/UI code changed.


## ADM ID validation and access-control inspection ? 2026-11-01

| Check | Result | Evidence / limits |
| --- | --- | --- |
| ID existence | PASS | Read-only TDK_POS_TEST status API returned MASTER_PASSWORD_SET for sondows and ACCOUNT_NOT_FOUND for a valid-format typo ID. |
| Active account | PASS (code/unit) | Classifier rejects inactive accounts as ACCOUNT_UNAVAILABLE; a DB inactive fixture exists but has no admin_login_id, so it cannot be exercised through the login-ID endpoint. |
| Terminated account blocked | UNVERIFIED | Status/classifier and token lookup filter terminated accounts; TDK_POS_TEST contains no terminated employee fixture. |
| ADM permission | PASS (code) | Status classifier and trust enrollment/token lookup enforce admin_enabled; one DB no-ADM fixture exists but has no admin_login_id, so no live ID API case was possible. |
| Same generic error | FAIL | In authorized setup mode the missing ID falls through to a generic account-status message, while ACCOUNT_UNAVAILABLE has a distinct message. The requested exact generic copy is not used. |
| Invalid ID cannot enter authentication | FAIL in ordinary mode | ProgramTrustGate intentionally treats initial-master/status HTTP 403 as normal-login fallback and changes to LOGIN_PASSWORD without establishing whether the ID exists. In authorized setup mode, ACCOUNT_NOT_FOUND does not advance. |
| Direct API bypass | PASS (guards verified; no valid-credential exploit attempted) | Initial master registration requires server-attested setup and an eligible OWNER with an unset hash. Trust enrollment filters active/non-terminated/ADM-enabled staff and verifies the master password. PIN setup requires a current program trust token and rechecks permission. Safe live malformed requests returned ID-only registration 400, malformed trust enrollment 401, and malformed PIN setup 400. |
| Existing token invalidation | PASS (DB + unit logic) | sondows has zero active ADM tokens and zero active ADMIN sessions in TDK_POS_TEST. The isolated trust unit test confirms a revoked token is not accepted. A browser holding the old raw cookie was not available for live replay. |

- Frontend analysis: ID is sent from the submit handler to three requests (ADM trust GET, bootstrap GET, and initial-master status POST). It preserves the typed ID on status errors and renders an aria-live alert below the form, but no code focuses the ID input after an error.
- Actual server/API: localhost /tdkadm/login returned HTTP 200. Read-only trust GET returned trusted=false. Initial-master status returned MASTER_PASSWORD_SET for sondows and ACCOUNT_NOT_FOUND for the typo. Safe malformed direct API probes were rejected. No valid password/PIN/token was sent, and no token or account data was changed.
- Browser: scripts/check-adm-id-next-test.cjs was attempted with headless Chrome, but Chrome DevTools Protocol timed out at Page.enable before navigation; browser behavior is therefore UNVERIFIED. This is not recorded as a PASS.
- Isolated tests: initial-admin-setup, program-trust, and program-trust-enrollment tests passed 8/8. No application code, DB schema, employee credential, token, or permission was modified. The task remains limited to inspection; the ordinary-mode fallback and generic-message mismatches are findings only.


## ADM master-password screen prompt and autofocus ? 2026-11-01

| Step | Goal | Target | Prerequisite | Impact | Completion criteria | Test | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Remove ADM password-stage back link, change stage-specific helper copy, and focus password input after phase render | src/components/ProgramTrustGate.tsx | Existing ADM ID-to-password flow | ADM login UI only | ADM password phase has no back link, correct helper text, and password input receives focus after transition | TypeScript, changed-file ESLint, actual Chrome focus check | IN_PROGRESS |

- Implemented the ADM-only link removal and password-stage copy; ID-stage guidance, other program screens, and bootstrap back navigation are preserved. Added a password input ref and an effect keyed only to program/phase, so ordinary rerenders do not refocus or clear the password value.
- TypeScript PASS; ESLint for the changed component PASS.
- Chrome verification remains unverified: the installed Chrome 156 opened the debug endpoint but did not return Page.enable responses; temporary headless and UI-mode extension automation also returned no result. The app route itself returned HTTP 200. No password was entered or submitted. Do not mark this stage PASS until focus is observed in Chrome.
- No authentication API, credential verification, token, PIN, or database code was changed.


## ADM initial PIN setup helper text ? 2026-11-01

| Step | Goal | Target | Prerequisite | Impact | Completion criteria | Test | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Show the requested helper under the ADM initial PIN registration button | src/components/ProgramTrustGate.tsx | SETUP_PIN with ADM and no PIN reset | ADM initial PIN setup only | Centered text-xs slate-500 copy under button, natural existing form/card spacing | TypeScript, ESLint, actual Chrome screen | IN_PROGRESS |

- Added ??? ??? ?? 6?? PIN?? ??????.? only when program=ADM, phase=SETUP_PIN, and pinReset=false. Existing form space-y-4 and card padding provide button-to-copy and bottom spacing; input/button styles are unchanged. POS/KDS and PIN reset screens do not render this copy.
- TypeScript PASS; ESLint for ProgramTrustGate.tsx PASS. No auth/API/DB changes.
- Actual Chrome screen rendering was not verified. Chrome DevTools automation in this environment times out on Page.enable; do not mark this UI step PASS until the text is observed in Chrome.


## ADM staff master-password and PIN reset ? 2026-11-01

| Step | Goal | Target | Prerequisite | Impact | Completion criteria | Test | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Inspect existing staff reset, master registration, program token, session, and PIN flows; create source checkpoint | Existing routes/components/schema | None | Read-only | Reuse existing fields/tables and document dependencies | Source inspection, schema review | PASS |
| 2 | Replace temporary-password endpoint with OWNER-confirmed atomic credential reset | Staff modal, owner action, security-password route | 1 PASS | Target employee only | Master/PIN unset, reset authorization set, all-program tokens and sessions revoked, audit row recorded in one transaction | Live endpoint, authenticated non-owner denial, DB effect inspection | PASS |
| 3 | Allow one-time master-password re-registration only for explicitly reset employees | Initial-master status/register route, shared program login flow | 2 PASS | Reset-flagged account only | Status prompts registration; successful registration consumes flag; NULL hash alone never grants permission | Live status/register API, ordinary account denied | PASS |
| 4 | Verify program-specific token and shared PIN behavior after re-registration | Trust enrollment, PIN flow | 3 PASS | POS/ADM/KDS, HOS token records if present | Current-program token issued; shared PIN enrolled; stale tokens/sessions rejected | Live API and DB inspection | PASS |
| 5 | Run isolated end-to-end validation in TDK_POS_TEST and clean temporary fixtures | Test script, all relevant APIs/DB rows | 2-4 PASS | Temporary test OWNER and employee only | Reset, state, registration, master auth, token, PIN, session, permissions and other-employee isolation all verified; cleanup complete | Guarded live integration against TDK_POS_TEST only | PASS |
| 6 | Record outcomes and retain a recoverable checkpoint | PLANS.md, .codex-backups | 1-5 results | Documentation | Results accurately distinguish PASS/unverified; test fixtures removed | Read-only post-check | PASS |

- Stage 1 findings: existing staff.security_password_change_required can serve as the one-time reset authorization when paired with a NULL master hash; staff.employee_pin_hash is the current shared PIN; program_trust_tokens records POS/ADM/KDS/HOS tokens; staff_sessions stores active POS/ADMIN/KDS sessions. No schema change is currently needed.
- Pre-change source checkpoint: .codex-backups/20261101-staff-credential-reset-before.zip.
- Production DB TDK_POS is out of scope. Live testing is guarded to TDK_POS_TEST and temporary fixtures only.
- Stage 2 PASS: replaced the former temporary-password action with an OWNER-reauthenticated confirmation and one DB transaction. The target's unified and legacy POS/ADM/KDS PIN hashes are cleared, the master hash is NULL, the one-time reset flag is set, all POS/ADM/KDS/HOS trust rows are revoked, all active staff sessions are logged out, and the actor/target/time are audited. Account identity, role, activation, and available permission fields are not updated. No password is returned.
- Stage 3 PASS: reset state is accepted only for active, non-terminated, non-shared target staff with `security_password_change_required=1` and a NULL master hash. This explicit state takes priority over initial-owner setup mode. An ordinary account with a NULL hash was rejected (HTTP 409); successful re-registration saved the hash and cleared the flag. POS/KDS trust enrollment returns a registration prompt only for the same explicit reset state.
- Stage 4 PASS: the live TDK_POS_TEST flow issued a new ADM token after the newly registered master password, detected the shared PIN as unset, registered one PIN, and created a session. Revoked POS/ADM/KDS cookies were rejected; HOS trust-row revocation was verified directly in DB.
- Stage 5 PASS: isolated live integration passed OWNER reset, authenticated non-OWNER denial (403), all four token revocations, zero active target sessions, unchanged active status/role/POS/KDS/ADM permissions, one reset audit row, reset status, unauthorized registration denial, new master authentication, and PIN registration. The temporary OWNER/employee, trust tokens, sessions, and audit rows were cleaned. TDK_POS was not accessed.
- Verification: TypeScript `tsc --noEmit` PASS; targeted ESLint PASS; related unit tests 8/8 PASS; guarded TDK_POS_TEST live integration PASS. Chrome visual inspection was not run. The test DB lacks `staff.hos_enabled` even though the current source schema declares it; no schema change was made, so HOS permission preservation could not be directly queried. HOS token-row revocation was verified.
- Post-implementation checkpoint retained at `.codex-backups/20261101-staff-credential-reset-after.zip`.


## KDS employee master-password, trust-token, and PIN login integration — 2026-11-01

| Step | Goal | Target | Prerequisite | Impact | Completion criteria | Test | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Inspect KDS login, common auth, API/page gates, real-time transport, and test DB schema | KDS auth/UI/API/server files | None | Read-only | Existing flows and gaps recorded without changing ADM/POS | Source and schema inspection | PASS |
| 2 | Make KDS login ID-first and connect ID → KDS trust check → master/password or PIN phase | KDS-only branch of ProgramTrustGate, KitchenLogin | 1 PASS | KDS login UI only | ID persists across phases, KDS token checked for that ID, KDS-specific focus and guidance | TypeScript, ESLint, auth-flow tests | PASS |
| 3 | Verify server master auth, KDS token, shared PIN enrollment/login, and KDS permission enforcement | Existing shared trust/PIN/KDS session routes | 2 PASS | KDS auth only | Active/non-terminated/KDS-enabled checks; KDS-only token; PIN shared across programs | Unit and live TDK_POS_TEST API integration | PASS |
| 4 | Audit protected page, every KDS data/action API, session invalidation, and real-time transport | KDS page, APIs, server ingress | 3 PASS | KDS access boundary | Stale/revoked token and session denied; all data/action routes guarded; real-time transport documented | Route tests and direct API probes | PASS |
| 5 | End-to-end KDS login, reconnect, permission denial, reset invalidation, and regression tests | Isolated fixture and KDS surfaces | 3-4 PASS | Temporary test employee only | Valid and invalid flows pass; order data untouched; cleanup complete | TDK_POS_TEST live API and browser/tablet | IN_PROGRESS |
| 6 | Record results and checkpoint | PLANS.md, `.codex-backups` | 1-5 results | Documentation | Accurate PASS/unverified reporting and recoverable checkpoint | Read-only post-check | PASS |

- Stage 1 findings: `ProgramTrustGate` already uses shared `enrollProgramTrust`, `verifyMasterPassword`, program-specific cookies, and shared PIN setup. KDS PIN login creates a `staff_sessions` KDS session linked to the KDS trust token. `getCurrentKdsStaff` checks active account, KDS permission, active session, PIN presence, and current non-revoked KDS trust; protected KDS order read and mutation routes call it. No WebSocket or EventSource transport exists; `KitchenClient` polls `/api/kitchen` and uses authenticated POST actions. ADM/POS code and KDS work/order logic remain out of scope.
- Existing UI gap: KDS opens in `LOGIN_PASSWORD`/trust auto-check and shows ID + master password together when untrusted; the nested PIN form independently asks for ID and does not consume the ID already checked by `ProgramTrustGate`. KDS also lacks explicit stage focus transitions.
- KDS-only edits to the shared gate are permitted only behind `program === "KDS"`; preserve ADM and POS behavior.
- Production DB `TDK_POS` is out of scope. Live fixtures must assert `DB_NAME === TDK_POS_TEST` and be removed in `finally`.
- Stage 2 PASS: KDS now starts with ID and Next, queries the KDS trust status for that ID, preserves the ID, then shows the password or PIN phase from the server result. Password/PIN inputs receive stage-specific focus; the nested KDS PIN screen consumes the gate's ID context. ADM/POS flows are unchanged. TypeScript and targeted ESLint pass.
- Stage 3 PASS: the shared trust enrollment verifies the common master password and issues only a KDS-scoped trust token. KDS ID status checks active, non-terminated, non-shared, KDS-enabled staff; token enrollment and PIN login retain server-side permission/session checks. Live TDK_POS_TEST standard-PIN and first-PIN flows passed, including wrong password/PIN, login, reconnect, and page response. POS/ADM/HOS trust cookies did not cross-authenticate as KDS.
- Stage 4 PASS: KDS page session validation and `/api/kitchen`, task mutation, table start, and table completion handlers call `getCurrentKdsStaff`; live calls to the read and three action APIs returned 401 after trust revocation. KDS reset-token invalidation uses the existing all-program reset route. No WebSocket or EventSource endpoint exists; KitchenClient polls `/api/kitchen` and sends authenticated action requests, so no live socket remains to revoke.
- Stage 5 partial: live fixture tests covered KDS ID status, inactive/terminated/KDS-OFF denial, token issuance, shared PIN registration, PIN login, reconnect, logout, and revoked-token data/action API denial. All fixture data was removed and no order data was changed. Chrome verification is UNVERIFIED: the Chrome DevTools Page.enable request timed out, and headless DOM capture exited with code 2147483651 before rendering. No browser PASS is claimed.
- Related unit tests: 13/13 PASS; TypeScript `tsc --noEmit`, targeted ESLint, integration script syntax, and `git diff --check` PASS. The live TDK_POS_TEST API integration passed with cleanup; production DB was not accessed and KDS order/cooking data was not modified.
- Browser limitation: Chrome DevTools `Page.enable` timed out; headless DOM capture exited with code 2147483651 before rendering. Chrome/tablet visual and focus behavior remain UNVERIFIED, so stage 5 remains IN_PROGRESS.
- Post-change source checkpoint: `.codex-backups/20261101-kds-auth-after.zip` (KDS gate/UI/routes/tests and PLANS.md). Stage 6 documentation and checkpoint PASS.


## KDS login replacement using the verified ADM flow — 2026-11-01

| Step | Goal | Target | Prerequisite | Impact | Completion criteria | Test | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Compare the active ADM login implementation with KDS UI, status lookup, token, password and PIN paths | ProgramTrustGate, AdminLoginForm, KitchenLogin, KDS trust route | None | Read-only | Differences and reusable shared code recorded | Source and route inspection | PASS |
| 2 | Align KDS ID/status/password phases and guidance with ADM while preserving KDS eligibility and token scope | KDS-only paths in ProgramTrustGate and program-trust-routes | 1 PASS | KDS login only | ID-only first step, server KDS checks, common password/token path, no password-stage back link | TypeScript, ESLint, auth-flow unit tests | PASS |
| 3 | Remove the legacy separate KDS PIN presentation and align it with ADM's shared PIN stage | KitchenLogin and shared auth context | 2 PASS | KDS login only | Shared employee PIN, KDS login endpoint/session and existing design constraints preserved | TypeScript, ESLint, PIN/API tests | PASS |
| 4 | Validate KDS login, token isolation, authorization and protected KDS work APIs against TDK_POS_TEST | Existing KDS APIs and isolated fixtures | 2-3 PASS | Temporary test fixtures only | Positive and negative paths pass; order data untouched; fixtures cleaned | Guarded live API integration | IN_PROGRESS |
| 5 | Verify the rendered login and navigation in Chrome, record results and retain a checkpoint | KDS browser route, PLANS.md, .codex-backups | 2-4 results | Browser and documentation | Chrome confirms ID-only first step, stage transitions, focus, PIN and KDS entry; checkpoint retained | Actual Chrome; post-check | TODO |

- ADM implementation baseline: both programs use `ProgramTrustGate`; ADM ID submit uses ADM-only bootstrap and setup-status APIs, while KDS correctly uses `/api/kitchen/auth/trust?loginId=...` so account eligibility is checked against `kds_enabled` and the token remains KDS-scoped. Both programs submit master-password verification through the same `enrollProgramTrust` and `verifyMasterPassword` server path. PIN registration uses the shared `/api/program-trust/pin` path and employee PIN hash; PIN login must use each program's own session route.
- KDS-specific differences found: the shared gate starts KDS at `LOGIN_ID`, but its password phase still renders the selected ID beside the password and includes the `뒤로가기 · ID 변경` link; the request explicitly requires removing that KDS password-stage link. KDS has its own PIN-login form because its endpoint creates a KDS session; it already consumes the shared gate's ID and employee PIN. ADM's bootstrap/status APIs are ADM-scoped and must not be called for KDS.
- Existing KDS main page and order/action APIs remain guarded by `getCurrentKdsStaff`; polling remains the live update method. No WebSocket/EventSource route was found. No KDS order/cooking logic, DB schema, ADM login code, POS login code, or production DB is in scope.
- Pre-change checkpoint for this replacement: `.codex-backups/20261101-kds-login-replacement-before.zip`.
- Stage 2 PASS: KDS begins with an ID-only form, validates active/non-terminated/KDS-enabled status through the KDS trust endpoint, and follows server status to KDS PIN, reset-password registration, approved first-owner registration, or the common master-password login path. The permitted reset flag is exposed as a boolean only after KDS eligibility checks. Master verification/token issuance still uses the shared `enrollProgramTrust`/`verifyMasterPassword` path and KDS token cookie. The password screen retains the ID but no longer renders the old back link; KDS copy matches ADM. Password input autofocus remains phase-driven. No ADM/POS logic or token policy changed.
- Stage 2 verification: TypeScript, targeted ESLint and related unit/API tests PASS (13/13). The unit suite now checks the explicit-reset status behavior. Checkpoint for this completed step: `.codex-backups/20261101-kds-login-replacement-stage2.zip`.
- Stage 3 PASS: KDS PIN login now uses ADM's login-card CSS and two-field layout while retaining the KDS-specific PIN session API, current KDS auth context ID, error handling, and autofocus. PIN setup remains on the shared ProgramTrustGate path. No ADM source or KDS work-screen code changed.
- Rate-limit root cause found while diagnosing the live 429: the existing Drizzle upsert's generated assignment order updates `window_started_at` before evaluating the `attempt_count` reset expression. On an expired bucket, that expression then sees the new timestamp and increments the old count instead of resetting it, so the IP can remain locked past the 15-minute window. `reserveKdsIpAttempt` now uses a transaction, inserts a no-op row if absent, locks and reads the row, evaluates expiry once, and writes either 1 or the incremented count. The 30-per-15-minute policy is unchanged. Unit coverage asserts both expired-window reset and active-window denial.
- Stage 4 live retry: guarded script again confirmed `DB_NAME=TDK_POS_TEST` and cleaned its temporary employee, but got HTTP 429 before authorization assertions. A read-only DB query showed the limiter bucket at 33 attempts and 256 seconds into its window. This indicates the server on `localhost:3000` is still executing the older compiled limiter; the updated source's expiry logic is not yet verified against the live API. No limiter row was edited or deleted, and no production DB was accessed.
- Related TypeScript, targeted ESLint, and unit/API checks now PASS (15/15); `node --check scripts/check-kds-chrome-login.cjs` and `git diff --check` PASS. Stage 4 remains IN_PROGRESS until live API integration can run against the updated server after the pre-existing limiter window expires.
- A disposable Chrome end-to-end check is available at `scripts/check-kds-chrome-login.cjs`. It creates a random reset-authorized employee only in `TDK_POS_TEST`, drives ID → registration → master authentication → PIN setup → KDS page in Chrome, checks focus and HttpOnly token behavior, then cleans the fixture and temporary browser profile. Actual browser verification remains unverified: prior attempts connected to Chrome DevTools but timed out waiting for `Page.enable`; no browser PASS is claimed. Stage 5 remains TODO.

## KDS ID 조회 429 근본 원인 및 limiter 식별 개선 — 2026-11-01

| 단계 | 작업 | 완료 기준 | 결과 |
| --- | --- | --- | --- |
| 1 | ID submit → status API → limiter 경로와 ADM 비교 | fetch 수, 응답 및 카운터 소유 범위 확정 | PASS (코드 추적 및 TDK_POS_TEST read-only 확인) |
| 2 | 개발 환경 IP 식별 및 상태조회/PIN limiter 분리 | 위조 헤더 미신뢰, 제한 정책 유지, 목적별 독립 카운터 | PASS (단위 테스트) |
| 3 | 타입·lint·API 관련 테스트 | 전체 통과 | PASS |
| 4 | 실제 서버 및 Chrome 재검증, ADM 회귀 확인 | 새 코드를 제공하는 서버에서 ID 조회와 인증 흐름 정상 | IN_PROGRESS |

- 최초 원인: KDS 상태 API `GET /api/kitchen/auth/trust?loginId=...`가 `reserveKdsIpAttempt`를 사용한다. 개발 ingress의 localhost 경로는 `x-tdk-local-dev`만 설정하고 `x-tdk-verified-client-ip`는 설정하지 않아, `getKdsRateLimitIp()`가 null을 반환했다. limiter는 null 모두를 SHA-256(`unverified-client-ip`) 하나로 합쳐 개발 요청을 전역 IP 버킷 하나에 누적했다. `TDK_POS_TEST` read-only 조회에서 해당 버킷은 34회였고, 15분 창 내라 단 한 번의 새 클릭도 429를 받는 상태였다. 이 KDS 버킷은 PIN 로그인도 공유했다. 이전 만료 처리 순서 오류가 있으면 창이 만료된 뒤에도 누적 횟수가 초기화되지 않을 수 있었다.
- 프런트엔드 추적: ID 화면 폼에는 `onSubmit`만 있고 다음 버튼은 submit 버튼이다. KDS ID 상태 조회 `useEffect`, 자동 재시도, 클릭 핸들러 중복은 없다. 제출 lock이 중복 제출을 막는다. 요청 과다 오류는 실제 HTTP 429에서만 표시된다. 429 응답이면 먼저 실패 분기에서 반환하므로 **KDS 상태 API 요청은 1회**, ADM 초기설정 상태 조회 후속 요청은 0회다. 200 응답일 때만 후속 `POST /api/admin-center/trust/initial-master/status`를 호출한다. 이벤트 계측을 통한 실제 Chrome 네트워크 횟수는 아직 확인하지 않았다.
- ADM 비교: ADM의 ID 다음은 `/api/admin-center/trust` 상태 조회이며 KDS IP limiter를 사용하지 않는다. 그 외 setup/status 요청은 별도 정책이다. Strict Mode는 이벤트 핸들러를 중복 실행하지 않고, ID 화면 자동 조회도 없다.
- 수정: `kds-ingress.cjs`에서 비운영 환경의 limiter 주소는 위조 가능한 forwarded header 대신 TCP socket peer에서 정규화해 설정한다. `reserveKdsIpAttempt` 카운터 키에 목적(`id-status` 또는 `pin-login`)을 포함해 ID 상태조회와 PIN 인증의 횟수를 분리했다. 두 경로 모두 기존 30회/15분 정책을 유지한다. 만료 창은 기존 트랜잭션/row-lock 방식으로 1부터 다시 시작한다. ADM/POS, 운영 ingress, 계정/PIN/토큰 데이터는 변경하지 않았다.
- 정적 검증: TypeScript PASS, 변경 관련 ESLint PASS, 관련 ingress/auth/API 테스트 26/26 PASS, `node --check kds-ingress.cjs` PASS.
- 실제 서버 확인은 BLOCKED: `localhost:3000`의 sondows GET은 HTTP 200을 반환했지만 새 IP+scope limiter 버킷 기록이 없었다. 격리 통합 테스트에서는 임시 테스트 직원의 KDS status API가 현 소스상 기대하는 403 대신 200을 반환했고 임시 직원 정리는 완료됐다. 이는 3000번 서버가 현재 작업 트리의 코드를 실행하지 않는다는 증거다. limiter 데이터는 수정하지 않았고 운영 DB는 접근하지 않았다. 따라서 수정 후 실제 API/Chrome 및 ADM 회귀는 PASS로 표시하지 않는다.
- 복구 체크포인트: `.codex-backups/20261101-kds-id-status-limit-root-cause.zip`.

## KDS PIN 로그인 429 및 인증 경로 점검 — 2026-11-01

| 단계 | 목표 | 결과 |
| --- | --- | --- |
| 1 | PIN 화면부터 토큰 확인, PIN 제한, 검증, 세션 생성까지 호출 경로 조사 | PASS (코드 및 read-only DB 확인) |
| 2 | 중복 제출 방지, limiter 원인 식별 테스트, 오류 코드 구분 | PASS (TypeScript, ESLint, 테스트) |
| 3 | 개발 서버·Chrome에서 실제 PIN 로그인과 ADM 회귀 확인 | IN_PROGRESS (실행 중 서버가 현재 코드와 불일치) |

- 현재 단일 PIN 경로: `KitchenLogin` 폼 `onSubmit` → `POST /api/kitchen/auth/login` (ID와 PIN JSON; same-origin fetch는 브라우저 쿠키를 자동 첨부) → `getCurrentProgramTrust("KDS", { loginId })`로 직원·KDS 프로그램·서명 토큰 쿠키 확인 → `reserveKdsIpAttempt("pin-login")` → 활성 직원 조회 → 직원 단위 제한 → 공통 `verifyEmployeePin` → `KDS_LOGIN_SUCCESS` 감사 이벤트와 KDS 타입 `staff_sessions` 생성 → `tdk_kds_session` HttpOnly 쿠키 반환. 토큰이 없거나 직원 ID와 다르면 IP limiter 전에 `403 TRUST_REQUIRED`로 처리한다. 별도 구형 KDS PIN API 호출은 없으며 다른 프로그램용 `verifyStaffPin` / `verifyAdminStaffPin`은 KDS route에서 사용하지 않는다.
- 원인 판정: `KitchenLogin.errorText`가 HTTP 429를 PIN 오류와 구분하지 않고 같은 “로그인 시도가 많습니다” 문구로 바꾼다. TDK_POS_TEST read-only 조사에서 `kds_auth_ip_attempts`에는 단일 레거시 `SHA-256("unverified-client-ip")` 버킷이 있었고 35회, 15분 창 안이었다. `kds_login_attempts` 행은 0개였으며 sondows 직원 단위 실패 카운터도 없었다. 서버 코드는 KDS IP 제한을 PIN 검증보다 먼저 실행하므로 해당 네트워크 버킷이 차단하면 PIN 불일치 여부와 관계없이 429가 난다. 앞선 ID 조회 제한 수정이 현재 서버에서 실행되지 않아 이전 공용 미확인 IP 버킷이 남아 ID 조회와 PIN 로그인을 함께 막는 것이 직접 원인으로 확인됐다.
- 중복 인증 여부: 실제 KDS PIN route는 하나뿐이다. PIN 화면에는 submit handler 하나만 있고 로그인 fetch도 한 곳이다. 중복 `onClick`/`onSubmit`은 없다. `useState(busy)` 방어 외에 in-flight ref lock이 없어서 빠른 연속 제출 경합 가능성은 제거하고 `submitLock` ref를 추가했다. 잘못된 PIN 제한은 직원별 5회/15분이고 IP 제한은 별도 30회/15분이다. KDS 마스터 비밀번호 등록은 `trust-enroll-kds` 인증 제한을 사용하며 PIN 카운터와 분리되어 있다. ADM PIN은 공통 PIN 검증 함수를 쓰지만 `adm-login` 계정/IP 실패 제한을 사용하고 KDS IP 제한을 공유하지 않는다.
- 수정: PIN 로그인 제출 ref lock 추가. 오류 UI에서 `KDS_IP_RATE_LIMIT`와 `KDS_EMPLOYEE_RATE_LIMIT`를 구분해 표시. 앞 절의 수정사항처럼 KDS ID 조회와 PIN 제한 key는 각각 `id-status`와 `pin-login`으로 분리하고, 개발 ingress는 TCP peer IP를 limiter 식별자로 넣는다. 기존 30/15 IP, 5/15 직원 실패 정책은 유지. 인증 함수·DB 스키마·계정/PIN/토큰 데이터를 수정하지 않았다.
- 검증: TypeScript PASS, 관련 ESLint PASS, 관련 auth/ingress/API 테스트 27/27 PASS. route unit test는 신뢰 KDS 토큰이 있을 때 IP limiter가 `429 KDS_IP_RATE_LIMIT`을 반환하고 PIN/직원 조회로 진행하지 않음을 확인한다.
- 실제 API/브라우저 미검증: 앞선 `localhost:3000` 통합 검사는 임시 직원을 정리했지만 현 소스가 기대한 미등록 ID 403 대신 200을 반환했다. 같은 런타임에서 sondows trust status GET은 200이었으나 새 scope 카운터 기록이 없었다. 따라서 해당 서버가 현재 작업 트리 수정사항을 반영하지 않는다. PIN POST 실제 HTTP 응답/쿠키와 Chrome Network 패널, ADM 회귀는 확인하지 않았다. 35회 레거시 카운터와 직원 단위 0건은 TDK_POS_TEST에서 읽기 전용 확인했으며 카운터를 지우거나 운영 DB를 사용하지 않았다.
- 복구 체크포인트: `.codex-backups/20261101-kds-pin-login-root-cause.zip`.

## KDS 네트워크 로그인 요청 제한 근본 원인 수정 — 2026-11-01

| 단계 | 목표 | 수정 대상 | 완료 기준 | 검증 | 상태 |
| --- | --- | --- | --- | --- | --- |
| 1 | KDS 요청 제한, IP 식별, 인증 API 호출 경로 조사 | KDS ingress, 인증 API, limiter | 429 경로와 로그인 요청별 카운터 확인 | 소스 추적 및 개발 API 관찰 | PASS |
| 2 | IP 미확인 공용 버킷 제거 및 네트워크/단계별 제한 분리 | KDS limiter, ID/비밀번호/PIN API | IP 없으면 503, 네트워크와 단계별 30회/15분 독립 카운터 | 단위/API 테스트 | PASS |
| 3 | 오류를 제한 종류별로 표시하고 재시도 폭주 방지 | KDS 로그인 UI, 상태 확인 | 네트워크/단계 제한과 IP 식별 오류 구분 | TypeScript, ESLint, 코드 검토 | PASS |
| 4 | 최신 개발 서버와 Chrome에서 전체 로그인 재검증 | Windows dev runtime, TDK_POS_TEST, Chrome | 최신 ingress에서 IP 식별 및 로그인 확인 | 실제 브라우저/API | BLOCKED |
| 5 | 결과와 복구 체크포인트 기록 | PLANS.md, .codex-backups | 검증/미검증을 구분하고 복원 지점 보존 | 문서와 checkpoint | PASS |

- 근본 원인: 이전 TDK_POS_TEST 조회에서 unverified-client-ip 공용 버킷 하나에 36회가 누적되어 있었다. IP 확인 실패 때 모든 개발 클라이언트와 인증 단계가 그 한 키로 합쳐져 30회 제한을 넘긴 뒤 정상 ID 조회도 429가 됐다. 이전 만료 처리에는 만료된 값을 1로 재설정하지 못하는 SQL assignment 순서 문제도 있어 row-lock 트랜잭션으로 고쳤다.
- IP 식별: 개발은 Node TCP peer를 사용하고 브라우저 전달 헤더는 폐기한다. 운영 reverse proxy는 Caddy 공유 비밀이 검증된 요청의 x-tdk-proxy-client-ip만 사용한다. 미확인 IP는 공용 fallback 없이 503 KDS_RATE_LIMIT_IP_UNAVAILABLE로 처리한다. X-Forwarded-For는 신뢰하지 않는다.
- 제한: 인증 요청 한 건은 network bucket과 해당 단계 bucket 각각 한 번 집계한다. 양쪽 모두 30회/15분이며 id-status, initial-master-status, master-auth, initial-master-register, pin-setup, pin-login이 분리된다. 비밀번호 실패 및 직원별 PIN 실패 제한도 별도 유지한다. 31번째 요청은 네트워크 또는 해당 단계에서 429다.
- 코드상 일반 최초 로그인은 ID 상태 GET 1회, 일반 초기 설정 확인 POST 1회, 마스터 인증 POST 1회, PIN 등록 또는 PIN 로그인 POST 1회다. 초기 비밀번호 등록/재등록 경로에서는 상태 POST 대신 비밀번호 등록 POST가 실행되어 총 5회가 된다. 각 HTTP 요청은 network에 1회와 해당 단계에 1회만 집계된다. 이 요청 수는 코드 추적 결과이며 Chrome에서 실측하지 않았다.
- 검증: limiter/PIN API/enrollment 12/12 PASS; ingress/IP spoofing 10/10 PASS; npx.cmd tsc --noEmit PASS; 대상 파일 ESLint PASS.
- 실행 서버: localhost:3000의 KDS ID 상태 API가 HTTP 503 KDS_RATE_LIMIT_IP_UNAVAILABLE을 반환했다. 현재 ingress 소스의 개발 IP 설정과 달라 실행 서버가 오래된 코드를 사용 중이라는 직접 증거다. PID 104608 Node 종료는 Access denied로 실패했다. 최신 서버에서 DB 카운터 증가, 31번째 요청, 다중 기기/직원 및 Chrome 로그인은 미검증이며 단계 4는 BLOCKED다. 개발 서버 재시작 후 실제 검증이 필요하다.
- TDK_POS 운영 DB는 접근하거나 변경하지 않았다. 복구 체크포인트: .codex-backups/20261101-kds-network-rate-limit-after.zip.

### 실행 서버 재검증 — 2026-11-01

- 사용자가 최신 개발 서버를 재시작한 뒤 KDS trust status API를 실제 호출했다: `GET /api/kitchen/auth/trust?loginId=sondows` → HTTP 200, `success=true`, `trusted=false`, `passwordRegistrationRequired=false`. IP 식별 503은 재현되지 않았다. `trusted=false`는 이 HTTP 요청에 브라우저 KDS 쿠키가 없다는 뜻이다.
- TDK_POS_TEST를 지정한 읽기 전용 조회에서 sondows는 1행, OWNER, 활성, 미퇴사, KDS 사용 허용, 마스터 비밀번호 설정, PIN 설정 상태였다. 미폐기 KDS token row는 1개였다. 비밀번호/PIN 해시 원문은 출력하지 않았다. 계정의 비밀번호를 알 수 없어 sondows 마스터 인증이나 해당 계정으로 새 토큰 발급은 시도하지 않았다.
- 실제 Chrome headless를 통해 TDK_POS_TEST 임시 직원으로 ID부터 마스터 등록, 공통 마스터 인증, KDS token 발급, PIN 등록, KDS 화면 진입을 검증했다. 별도 재접속 검증에서는 KDS 로그아웃 후 새로고침 시 KDS token cookie가 유효한 상태로 PIN 화면이 나타났고, PIN 제출 후 KDS 메인 화면에 도달했다. 이는 토큰 값을 브라우저 스크립트에 노출하지 않은 functional cookie 전달 검증이다. 테스트 직원, 세션, 감사 및 토큰 행은 스크립트에서 정리 완료됐다.
- Chrome UI에서 KDS PIN 로그인 후 실제 메인 화면 진입 PASS. PIN 경로는 KDS 전용 API를 사용했고 성공 응답 이후 보호된 KDS page가 렌더링됐다. 별도의 주문 변경은 하지 않았다.
- ADM 회귀: `/tdkadm/login` HTTP 200, `/api/admin-center/trust?loginId=sondows` HTTP 200. 자격증명을 제출하지 않았으므로 ADM 비밀번호 인증 자체는 실행하지 않았다.
- 제한 집계 검토(코드 수정 없음): 현재 limiter는 성공/일반 요청도 network 및 단계별 30회/15분 카운터에 포함한다. ID 상태 GET, 일반 최초 설정 상태 POST, 성공한 마스터 인증, PIN 등록 또는 PIN 로그인 각각이 카운트된다. 첫 인증은 보통 네트워크 카운터 4회(최초 마스터 등록까지 포함하면 5회)를 사용하며, 같은 NAT IP 매장 직원들이 공유한다. 따라서 이 값은 실패 횟수 전용이 아니고 정상 트래픽으로 소진될 수 있다.
- 정책 권고: 보안 기준 30회/15분은 유지하되 의미를 실제 잘못된 마스터 비밀번호/PIN 시도에 적용되는 실패 카운터로 두고, 성공 인증/상태 조회는 실패 카운터에서 제외하는 것이 매장 사용량과 공격 시도를 구분한다. ID 조회 abuse/계정 열거 방지는 별도 요청 카운터·응답 균일화로 다루되, 조회 제한값은 매장 피크 사용량 측정 없이 변경하지 않는다. 본 요청은 추가 코드 수정 금지이므로 정책은 적용하지 않았다.
- DB 접속 시도는 TDK_POS_TEST로 가드했으며 읽기 전용 계정 조회와 승인된 임시 E2E fixture 외에 인증정보 변경은 없었다. 운영 DB는 접근/변경하지 않았다. 이전 단계의 BLOCKED는 사용자가 재시작한 뒤 기능 검증을 진행해 해소됐고, 실제 sondows 인증은 사용자 비밀번호 미제공으로 미검증이다.

## TDKON POS 로그인 전면 교체 및 구형 인증 소스 정리 — 2026-11-01

| 단계 | 작업 목표 | 수정 대상 | 선행 조건 | 예상 영향 범위 | 완료 기준 | 테스트 방법 | 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | ADM 성공 로그인과 POS 기존 로그인/UI/API/페이지 보호 구조 비교 | ProgramTrustGate, POS login page, auth/trust routes, POS session helpers | 없음 | 읽기 전용 | 재사용 API, 중복 호출, 보존해야 할 POS 업무/보조 PIN 참조를 식별 | 참조 검색, route/source 조사, Next Route Handler 문서 확인 | PASS |
| 2 | POS ID 조회에서 직원 활성/퇴사/POS 권한/마스터 상태/POS token을 서버에서 판정 | POS trust status API, shared trust route | 1 PASS | POS 로그인 상태 조회 | 무효 계정 차단, reset/initial setup 상태만 등록 허용, POS 전용 trust만 확인 | route unit/API tests, TDK_POS_TEST | PASS |
| 3 | POS 화면을 ID → 다음 → 등록/마스터 인증 흐름으로 연결 | POS branch in ProgramTrustGate | 2 PASS | POS login UI only | ADM과 같은 단계, ID 유지, 포커스/오류/안내 문구, 불필요한 뒤로가기 제거 | auth-flow tests, TypeScript, ESLint, Chrome | PASS |
| 4 | 공통 POS token/PIN 등록 및 POS PIN 로그인으로 단일 요청 연결, 중복 PIN 사전검증 폐기 | program trust APIs, POS login child, auth login/verify-pin routes | 3 PASS | POS auth endpoints only | POS 전용 HttpOnly token/session, 공통 PIN, login 성공 1회 요청, 참조 없는 구형 route 제거 | route tests, TDK_POS_TEST integration | PASS |
| 5 | POS 페이지/API 인증 및 다른 프로그램 token 차단 확인 | POS page, sales/order/payment APIs, getCurrentStaff | 4 PASS | POS access boundary | POS permission/revocation/session 검사 유지, 주문/결제 코드 변경 없음 | API access audit, guarded negative probes | PASS |
| 6 | 인증 정상/오류/재접속과 ADM·KDS 회귀를 실제 개발 환경에서 검증 | isolated test fixture, Chrome, related tests | 2-5 PASS | 임시 TDK_POS_TEST fixture only | 모든 요구 시나리오 통과, fixture cleanup, 업무 데이터 무변경 | TypeScript, ESLint, unit/API integration, Chrome | PASS |
| 7 | 파일 삭제/변경 목록과 검증 결과를 기록하고 복구 체크포인트 보존 | PLANS.md, .codex-backups | 1-6 results | documentation/checkpoint | 미검증 항목을 분리 표기, 복원 가능한 checkpoint | checkpoint/file check | PASS |

- Stage 1 findings: ADM and POS both use ProgramTrustGate and the same `/api/{program}/trust` plus `enrollProgramTrust`, which calls `verifyMasterPassword` and issues a program-specific trust token. Shared `/api/program-trust/pin` registers the shared employee PIN. POS `/api/auth/login` is the current POS-specific PIN-to-session API and should remain; it creates a POS session linked to the POS token. The old login page calls `/api/auth/verify-pin` and then `/api/auth/login`, verifying the same PIN twice. The UI also fetches `/api/staff/active` and shows an employee picker; that endpoint remains used by POS secondary PIN checks in order summary/table/admin flows and cannot be removed globally.
- Existing gap: POS ProgramTrustGate currently begins with an unscoped trust check and falls into combined ID+master-password UI; there is no POS ID-submit branch. `trustStatus("POS", request)` currently checks token cookies but does not validate a supplied ID's active/terminated/POS permission state. PIN re-entry component is the older staff list/keypad UI. `getCurrentStaff` protects the POS page/session and checks POS permission plus matching non-revoked POS trust. `getPosLoginMode()` is hard-coded PERSONAL. Existing POS work/payment APIs are out of scope for edits.
- Route safety: `/api/auth/verify-pin` is referenced only by the old POS login component; `verifyActiveStaffCredentials` is still used by admin/sales reauthentication and must not be removed. `/api/staff/active` is also used outside login and must remain. No database schema or staff data changes are planned.
- Next.js implementation reference reviewed: installed Next 16 App Router Route Handler docs under `node_modules/next/dist/docs/01-app/...`; request/response handlers use Web Request/Response APIs and GET handlers are not cached by default unless explicitly opted in.
- Pre-change checkpoint to create before step 2: `.codex-backups/20261101-pos-auth-replacement-before.zip` (POS and shared gate/auth source, tests, PLANS).
- Production DB `TDK_POS` is prohibited. Integration fixtures, where schema supports them, must be created and cleaned only in `TDK_POS_TEST`; no real sondows password/PIN will be changed.
- Pre-change checkpoint created: `.codex-backups/20261101-pos-auth-replacement-before.zip`.
- Stage 2 implementation: POS trust status validates the submitted ID against exactly one active, non-terminated, POS-enabled non-shared employee. Registration state is returned only from the explicit reset flag; a POS token is usable only when the master hash exists and the reset flag is clear. Initial setup still requires the existing approved setup or OWNER-reset permission. `program=POS` registration also checks POS access.
- Stage 2 tests: POS status unit tests passed 4/4 for eligible account, reset-only registration, NULL hash without reset denied, and trusted POS token/PIN state.
- POS login UI now starts ID-only, requests `/api/auth/trust?loginId=...` only on Next, branches into approved registration/master auth/PIN, retains ID, focuses the active input, and removes the POS password-stage back link. ADM and KDS branches were not changed.
- POS PIN login now consumes the ID from `ProgramAuthContext` and calls `/api/auth/login` once. Removed unused `/api/auth/verify-pin` endpoint after confirming no remaining source caller; `/api/staff/active` and shared credential helpers remain for secondary reauthentication.
- Chrome POS E2E PASS on localhost:3000 with a random temporary TDK_POS_TEST employee: ID-only screen; retained ID; password and PIN focus; master auth; POS-only token; PIN login; `[data-pos-app]` main page. Network showed one GET `/api/auth/trust`, one POST `/api/auth/trust`, one POST `/api/auth/login`, and no verify-pin call. Browser could not read the HttpOnly trust cookie. DB contained one active 64-hex POS token hash and one linked POS session.
- POS API integration PASS on TDK_POS_TEST: eligible ID 200; unknown/inactive/terminated/POS-disabled ID denied; token enrollment denied for ineligible accounts; PIN without POS trust denied (403); wrong master password and PIN denied (401); successful enrollment/login/reconnect/page returned 200. First PIN registration and subsequent login also passed. All fixture rows were deleted.
- POS access audit PASS: `/tdkpos` without a session redirected to `/tdkpos/login` (307); `/api/pos/menu-catalog` without a session returned 401; `/api/auth/login` without POS trust returned 403. `getCurrentStaff` remains the POS page/API session guard, and all nine `src/app/api/pos/**/route.ts` handlers retain the guard. Order/payment business files were not modified.
- ADM/KDS regression PASS: API integration wrong-password 401, enrollment 200, wrong-PIN 401, login/reconnect/page 200 for both. Existing KDS Chrome registration/master-auth/token/PIN/main-page flow passed after shared gate changes. Temporary test rows/tokens/sessions were cleaned.
- TypeScript passed after `npx next typegen` refreshed generated route types following obsolete route removal. ESLint passed on changed code/scripts; related unit tests passed 11/11. No schema change or production DB access/change.
- Checkpoints: pre-change `.codex-backups/20261101-pos-auth-replacement-before.zip`; after-change `.codex-backups/20261101-pos-auth-replacement-after.zip`; manifest `checkpoints/20261101-pos-auth-replacement-after.md`.

## TDKON 공통 인증 요청 제한 시스템 개선 — 2026-11-01

| 단계 | 목표 | 수정 대상 | 선행 조건 | 영향 범위 | 완료 기준 | 검증 | 상태 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | ADM/POS/KDS ID·마스터 비밀번호·PIN·등록·IP·429 제한과 저장/만료/호출 경로 전수 조사 | limiter modules, login/status APIs, ingress, schema | 없음 | 읽기 전용 | 정상/실패 요청별 실제 카운터, cross-NAT 경로, 런타임 한계 파악 | source trace, TDK_POS_TEST read-only counters | PASS |
| 2 | 실패 카운터를 직원 및 인증 단계별로 통합하고 성공/입력오류/권한거부를 제외 | shared auth limit helper, ADM/POS/KDS login routes | 1 PASS | 인증 제한만 | 마스터와 PIN 독립, 직원 ID 정규화, 30/15 명시 정책 보장 | unit tests, TypeScript, ESLint | PASS (코드/정적 검증) |
| 3 | ID/status와 PIN 등록 남용 제한을 인증 실패 카운터에서 분리 | ID status, setup APIs, KDS request limiter | 2 PASS | 인증 요청 제한만 | 기존 ID/setup 요청 제한 별도 유지, 정상/실패 인증 분리 | source trace, route unit tests | PASS (코드 검증; 실제 API 미검증) |
| 4 | 30회·31회, 기간 만료, 직원·단계 독립성 검증 | auth limit tests, TDK_POS_TEST fixtures | 2-3 PASS | 테스트 직원만 | 실패만 증가, 최대 30회·31번째 차단, 15분 만료 및 다른 직원 정상 인증 | pure unit tests; API/counter integration pending | IN_PROGRESS |
| 5 | 실제 Chrome에서 정상/실패 인증과 ADM·POS·KDS 회귀 확인 | current dev server, TDK_POS_TEST, Chrome | 4 PASS | 임시 테스트 계정 | 정상 트래픽의 실패 카운터 영향 없음, 여러 직원 NAT 영향 분리 | browser network/API/DB | TODO (localhost:3000 not listening) |
| 6 | 결과를 기록하고 복구 체크포인트 생성 | PLANS.md, checkpoints | 1-5 results | documentation/archive | 변경·검증·미완료 항목 보존 | archive inspection | IN_PROGRESS |

- Stage 1 findings: `admin-auth-limit.ts` uses `admin_auth_attempts` with SHA-256 keys for `{scope,account}` and `{scope,ip}`, currently 5/15m; a wrong credential increments both and any success clears both, so one employee can block all staff on the same IP within that scope. Scope strings differ among ADM/POS/KDS, so identical master credentials are not one stage-wide bucket. `admin-login-limit.ts` is a process-local 5/15m map used by POS PIN; KDS layers another 5/15m process-local map over `kds_login_attempts` DB rows for known employees, while unknown IDs are process-local only. ADM PIN uses the shared DB helper and a shared IP bucket.
- KDS additionally calls `reserveKdsIpAttempt` for every ID-status, master-auth, PIN-login, and PIN-setup request. It increments both an IP-wide `network` bucket and an API-scope bucket at 30/15m before credentials are checked. Therefore valid KDS ID lookups, valid master authentication, and valid PIN logins consume the same network budget. ID status and setup should remain on separate abuse/request limits; master/PIN auth should count actual credential failures only.
- Current data is opaque hashed counters, not request telemetry. A read-only query to `TDK_POS_TEST` found `admin_auth_attempts`: 3 rows, 0 active in 15m, historical max 44; `kds_auth_ip_attempts`: 7 rows, 0 active, historical max 36; `kds_login_attempts`: 0 rows. No keys, employee identities, IPs, or secrets were read. Expired rows were not cleared. No historical request logs or traffic baseline were found, so no new ID-abuse threshold should be introduced; existing ID/status and setup caps remain 30/15 where already implemented.
- Existing per-employee credential cap is actually 5/15m in the DB and in-memory helpers, despite the requested policy describing 30/15m. The explicit requested 30 failed attempts then 31st blocked policy is being treated as the target for password/PIN failures; successful and malformed/permission-denied requests will not consume it. Legacy request-count caps remain separate and will not deny valid credentials due to shared NAT failures.
- Counter storage: `admin_auth_attempts` is DB-persistent and shared across processes, with old rows purged only during failed-auth recording; `kds_auth_ip_attempts` is DB-persistent with row-lock transactions and 1-day cleanup; `kds_login_attempts` is DB-persistent but currently duplicated by process-local state and has no automatic stale-row purge. POS/KDS in-memory counters reset on process restart and do not coordinate across processes. DB schema will be reused; no new table or counter reset is planned.

- Implementation: `auth-attempt-policy.ts` now sets the requested 30 failures/15 minutes and allows failure 30 to be recorded; failure 31 is rejected. Hashed keys normalize staff IDs and separate `master-password` from `employee-pin`. `admin-auth-limit.ts` advances persistent rows under transaction/row lock, clears only that employee's stage counter on success, and records IP failures separately. A full IP failure bucket is not checked before valid authentication, so a wrong-password/PIN sequence from one staff member does not block a correct coworker behind NAT. ID/status abuse and setup/recovery requests retain separate existing 30/15 request counters.
- Route changes: POS, ADM, KDS PIN routes now use the shared employee PIN counter; program-token enrollment and password reauthentication share the master-password counter. KDS no longer reserves the shared network+phase request buckets for every PIN login or master-password authentication; valid ID status in ADM/POS/KDS does not consume invalid-ID request buckets. Invalid/ineligible ID status and setup/recovery APIs remain separately request-limited. Malformed requests, missing/ineligible accounts, permission denials, PIN-not-configured responses, and successful verification do not increment credential-failure counters.
- Code verification: `npx.cmd tsc --noEmit` PASS; ESLint on changed TypeScript/MJS files PASS; policy + KDS limiter + KDS PIN route unit tests 12/12 PASS. Unit tests cover normalized/separate keys, employee separation, stage separation, 30th/31st behavior, 15-minute expiry, and KDS not spending a general IP request token before PIN credential checks.
- Runtime verification pending: port 3000 has no listening process in the current environment, so no actual HTTP integration, TDK_POS_TEST counter exercise, multi-employee NAT run, or Chrome/ADM/POS/KDS regression could be performed. No database writes or schema changes were made in this turn. Earlier read-only TDK_POS_TEST counter inventory remains unchanged; no counter cleanup/reset was performed. New endpoint counter behavior has only source/unit coverage, not a live DB assertion.
- Recovery checkpoints: `checkpoints/20261101-common-auth-rate-limit-policy.zip` and `checkpoints/20261101-common-auth-rate-limit-policy-v2.zip` (the latter includes the final ADM ID-status adjustment). These are review/restore points, not Git commits.
