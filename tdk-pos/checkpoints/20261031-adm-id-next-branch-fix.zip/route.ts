import { and, eq, isNull, ne, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { adminSecurityOwners, staff } from "@/db/schema";
import { reserveAdminStatusAttempt } from "@/lib/admin-auth-limit";
import { getKdsRateLimitIp } from "@/lib/kds-network-server";
import { isNasOwnerSetupWrite } from "@/lib/nas-owner-setup";

const noStore = { "Cache-Control": "no-store" };

/** Status is visible only in NAS local setup mode; ID alone never authorizes registration. */
export async function POST(request: Request) {
  if (!isNasOwnerSetupWrite(request))
    return NextResponse.json({ available: false }, { status: 403, headers: noStore });
  const body = await request.json().catch(() => null) as Record<string, unknown> | null;
  const loginId = typeof body?.loginId === "string" ? body.loginId.trim().toLowerCase() : "";
  if (!/^[a-z][a-z0-9._-]{2,31}$/.test(loginId))
    return NextResponse.json({ available: false }, { headers: noStore });
  try {
    if (!await reserveAdminStatusAttempt("initial-master-status", await getKdsRateLimitIp()))
      return NextResponse.json({ available: false }, { status: 429, headers: noStore });
    const [account] = await db.select({ staffId: staff.staffId, passwordHash: staff.securityPasswordHash,
      role: staff.role, isActive: staff.isActive, adminEnabled: staff.adminEnabled,
      terminatedAt: staff.terminatedAt, staffCode: staff.staffCode,
      isOwner: sql<boolean>`${adminSecurityOwners.staffId} IS NOT NULL`.as("is_owner") }).from(staff)
      .leftJoin(adminSecurityOwners, eq(adminSecurityOwners.staffId, staff.staffId))
      .where(and(sql`LOWER(${staff.adminLoginId}) = ${loginId}`,
        isNull(staff.terminatedAt), ne(staff.staffCode, "000")))
      .limit(1);
    const eligible = Boolean(account?.isOwner && account.role === "OWNER" && account.isActive === 1 &&
      account.adminEnabled === 1 && account.terminatedAt === null && account.staffCode !== "000" &&
      account.passwordHash === null);
    return NextResponse.json({ available: eligible, accountFound: Boolean(account),
      passwordConfigured: account ? account.passwordHash !== null : null }, { headers: noStore });
  } catch (error) {
    console.error("Initial master status unavailable", { code: (error as { code?: string }).code });
    return NextResponse.json({ available: false }, { status: 503, headers: noStore });
  }
}
