import type { CustomerTradeRow } from "@/lib/customer-trade";
import type { PrintCommand, PrintDocument } from "@/lib/print-document";

const printableWidth = 488;
const fontSize = 24;
const maxCommands = 250;

export type PrinterTextMeasure = (value: string) => number;

function dateLabel(value: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!match) throw new Error("거래 날짜 형식을 확인할 수 없습니다.");
  return `${match[1].slice(-2)}/${match[2]}/${match[3]}`;
}

function cleanDescription(value: string) {
  return value.replace(/[\u0000-\u001f\u007f]+/g, " ").replace(/\s+/g, " ").trim();
}

function splitGraphemes(value: string) {
  if (typeof Intl.Segmenter === "function") {
    return [...new Intl.Segmenter("ko", { granularity: "grapheme" }).segment(value)].map(part => part.segment);
  }
  return Array.from(value);
}

function clippedDescription(value: string, width: number, measure: PrinterTextMeasure) {
  if (measure(value) <= width) return value;
  const suffix = "..";
  let result = "";
  for (const part of splitGraphemes(value)) {
    if (measure(`${result}${part}${suffix}`) > width) break;
    result += part;
  }
  if (!result) {
    if (measure(suffix) > width) throw new Error("표준 글꼴과 금액 폭에서 거래 내용을 한 줄로 배치할 수 없습니다.");
    return suffix;
  }
  return `${result}${suffix}`;
}

function amountLabel(amount: number) {
  if (!Number.isFinite(amount)) throw new Error("거래 금액을 확인할 수 없습니다.");
  return amount.toLocaleString("ko-KR", { maximumFractionDigits: 2 });
}

function toColumnPercent(pixelWidth: number) {
  return Math.ceil(pixelWidth * 100 / printableWidth);
}

function maxWidth(values: string[], measure: PrinterTextMeasure) {
  return values.reduce((maximum, value) => Math.max(maximum, measure(value)), 0);
}

function allocateColumns(rows: readonly CustomerTradeRow[], measure: PrinterTextMeasure): [number, number, number, number] {
  const dates = rows.map(row => dateLabel(row.transactionAt));
  const amounts = rows.map(row => amountLabel(row.amount));
  const balances = rows.map(row => amountLabel(row.balance));
  // Reserve the standard 24px font widths first; descriptions use only what remains.
  // GDI's DrawString can be a little wider than browser canvas metrics for Malgun Gothic.
  // Keep extra hard space on the fixed date column so the final digit cannot wrap on the printer.
  const dateWidth = toColumnPercent(Math.ceil(maxWidth(dates, measure) + 20));
  const amountWidth = toColumnPercent(Math.ceil(maxWidth(amounts.map(value => `${value}  `), measure) + 4));
  const balanceWidth = toColumnPercent(Math.ceil(maxWidth(balances, measure) + 4));
  const descriptionWidth = 100 - dateWidth - amountWidth - balanceWidth;
  const columns: [number, number, number, number] = [dateWidth, descriptionWidth, amountWidth, balanceWidth];
  if (columns.some(width => width < 10) || columns.reduce((sum, width) => sum + width, 0) !== 100) {
    throw new Error("날짜와 금액이 일반 영수증 글자 크기로 한 줄에 들어가지 않습니다.");
  }
  return columns;
}

function rowCommand(
  row: CustomerTradeRow,
  columns: [number, number, number, number],
  measure: PrinterTextMeasure,
  describe: (row: CustomerTradeRow) => string,
): PrintCommand {
  const date = dateLabel(row.transactionAt);
  const amount = amountLabel(row.amount);
  const balance = amountLabel(row.balance);
  const description = cleanDescription(describe(row));
  const actualWidths = columns.map(column => Math.floor(printableWidth * column / 100));
  const [dateWidth, descriptionWidth, amountWidth, balanceWidth] = actualWidths;
  const descriptionBudget = descriptionWidth - measure("    ") - 4;
  if (measure(date) + 3 > dateWidth || measure(`${amount}  `) + 3 > amountWidth || measure(balance) + 3 > balanceWidth) {
    throw new Error("날짜 또는 금액이 일반 영수증 글자 크기로 한 줄에 들어가지 않습니다.");
  }
  if (measure("..") > descriptionBudget) {
    throw new Error("표준 글꼴과 금액 폭에서 거래 내용을 한 줄로 배치할 수 없습니다.");
  }
  const displayDescription = clippedDescription(description, descriptionBudget, measure);
  const cells = [
    { value: date, width: columns[0], align: "left" as const },
    { value: `  ${displayDescription}  `, width: columns[1], align: "left" as const },
    { value: `${amount}  `, width: columns[2], align: "right" as const },
    { value: balance, width: columns[3], align: "right" as const },
  ];
  // The Device Agent wraps text that exceeds a cell's GDI width; reject instead of shrinking fonts.
  if (cells.some((cell, index) => measure(cell.value) > actualWidths[index] - 2)) {
    throw new Error("거래 행의 글자 폭을 일반 영수증 한 줄에 맞추지 못했습니다.");
  }
  return { type: "row", cells, size: fontSize };
}

export function buildCustomerBalancePrintDocuments(
  rows: readonly CustomerTradeRow[],
  measure: PrinterTextMeasure,
  describe: (row: CustomerTradeRow) => string,
  header: readonly PrintCommand[],
  footer: readonly PrintCommand[],
): PrintDocument[] {
  if (!Number.isFinite(measure("0")) || measure("0") <= 0) throw new Error("프린터 글꼴 폭을 측정할 수 없습니다.");
  if (rows.length === 0) throw new Error("출력할 거래 내역이 없습니다.");

  const columns = allocateColumns(rows, measure);
  const rowCommands = rows.map(row => rowCommand(row, columns, measure, describe));
  const nonFinalCapacity = maxCommands - header.length - 1;
  const finalCapacity = maxCommands - header.length - footer.length;
  const documents: PrintDocument[] = [];
  let index = 0;
  while (rowCommands.length - index > finalCapacity) {
    documents.push({ commands: [...header, ...rowCommands.slice(index, index + nonFinalCapacity), { type: "cut" }] });
    index += nonFinalCapacity;
  }
  documents.push({ commands: [...header, ...rowCommands.slice(index), ...footer] });
  return documents;
}
