import assert from "node:assert/strict";
import test from "node:test";
import { buildCustomerBalancePrintDocuments } from "./customer-balance-print.ts";

function printerMeasure(value) {
  let width = 0;
  for (const character of value) {
    if (/\p{Script=Hangul}/u.test(character)) width += 24;
    else if (/[0-9A-Za-z]/.test(character)) width += 13.2;
    else if (character === " ") width += 6.6;
    else if (character === "," || character === "/" || character === ".") width += 6.6;
    else if (character === "-") width += 8;
    else width += 12;
  }
  return width;
}

function ledgerRow({ date = "2026-01-01T12:34:00", description = "계좌입금", amount = 10000, balance = 10000 } = {}) {
  return {
    ledgerId: 1, entryType: "DEPOSIT", amount, balance, transactionAt: date, createdAt: date,
    methodCode: "TRANSFER", adjustmentReason: null, memo: null, paymentId: null, checkoutId: null,
    paymentMethodName: null, reversesLedgerId: null, description,
  };
}

const header = {
  commands: Array.from({ length: 7 }, () => ({ type: "text", value: "receipt header", align: "center", size: 24 })),
};

function printDocuments(rows, currentBalance = 96000) {
  const footer = [
    { type: "line" },
    { type: "row", left: "현재 잔액", right: currentBalance.toLocaleString("ko-KR"), size: 24, bold: true },
    { type: "line" }, { type: "feed", lines: 3 }, { type: "cut" },
  ];
  return buildCustomerBalancePrintDocuments(rows, printerMeasure, row => row.description, header.commands, footer);
}

test("24px receipt body prints date, description, signed money, and balance as one line per trade", () => {
  const [document] = printDocuments([
    ledgerRow({ description: "흑돼지김치찌개4", amount: -20000, balance: 16000 }),
    ledgerRow({ date: "2026-01-02T15:40:00", description: "계좌입금", amount: 30000, balance: 46000 }),
    ledgerRow({ date: "2026-01-03T08:00:00", description: "Card refund", amount: -10000, balance: -10000 }),
  ]);
  const rows = document.commands.filter(command => command.type === "row" && command.cells?.length === 4);
  assert.equal(rows.length, 3);
  assert.deepEqual(rows[0].cells.map(cell => cell.value).slice(0, 1), ["26/01/01"]);
  assert.equal(rows[0].cells[2].value, "-20,000  ");
  assert.equal(rows[1].cells[2].value, "30,000  ");
  assert.equal(rows[2].cells[2].value, "-10,000  ");
  assert.equal(rows[2].cells[3].value, "-10,000");
  for (const row of rows) {
    assert.equal(row.size, 24);
    assert.equal(row.cells.reduce((sum, cell) => sum + cell.width, 0), 100);
    assert.ok(row.cells.every(cell => !/[\r\n]/.test(cell.value)));
    row.cells.forEach(cell => assert.ok(printerMeasure(cell.value) <= Math.floor(488 * cell.width / 100) - 2));
  }
  assert.equal(document.commands.at(-5).type, "line");
  const currentBalance = document.commands.find(command => command.type === "row" && command.left === "현재 잔액");
  assert.equal(currentBalance.right, "96,000");
  assert.equal(currentBalance.size, 24);
  assert.equal(currentBalance.bold, true);
  assert.equal(document.commands.at(-1).type, "cut");
});

test("long Korean and mixed descriptions are clipped at grapheme boundaries without line breaks", () => {
  const [document] = printDocuments([
    ledgerRow({ description: "흑돼지김치찌개추가 Extra topping, takeaway", amount: -9999999, balance: -9999999 }),
    ledgerRow({ date: "2026-01-02T00:00:00", description: "흑돼지김치찌개4", amount: 9999999, balance: 9999999 }),
  ]);
  const rows = document.commands.filter(command => command.type === "row" && command.cells?.length === 4);
  for (const row of rows) {
    const description = row.cells[1].value.trim();
    assert.ok(description.endsWith(".."));
    assert.equal(description.includes("\n"), false);
    assert.equal(row.size, 24);
  }
});

test("maximum transaction values and negative current balance retain commas and signs", () => {
  const [document] = printDocuments([ledgerRow({ amount: 9999999, balance: -9999999 })], -9999999);
  const row = document.commands.find(command => command.type === "row" && command.cells?.length === 4);
  assert.equal(row.cells[2].value, "9,999,999  ");
  assert.equal(row.cells[3].value, "-9,999,999");
  assert.equal(document.commands.find(command => command.type === "row" && command.left === "현재 잔액").right, "-9,999,999");
});

test("large ledgers respect the Agent 250-command limit and print current balance only on final cut", () => {
  const documents = printDocuments(Array.from({ length: 500 }, (_, index) => ledgerRow({
    date: `2026-01-${String(index % 28 + 1).padStart(2, "0")}T12:00:00`, description: `거래 ${index}`,
  })));
  assert.ok(documents.length > 1);
  assert.ok(documents.every(document => document.commands.length <= 250));
  assert.equal(documents.filter(document => document.commands.some(command => command.type === "row" && command.left === "현재 잔액")).length, 1);
  assert.ok(documents.every(document => document.commands.at(-1).type === "cut"));
  assert.equal(documents.flatMap(document => document.commands).filter(command => command.type === "row" && command.cells?.length === 4).length, 500);
});

test("empty, invalid date, invalid width, or non-finite amounts are rejected", () => {
  assert.throws(() => printDocuments([]), /출력할 거래 내역/);
  assert.throws(() => buildCustomerBalancePrintDocuments([ledgerRow()], () => 0, row => row.description, header.commands, []), /글꼴 폭/);
  assert.throws(() => printDocuments([ledgerRow({ date: "invalid" })]), /날짜 형식/);
  assert.throws(() => printDocuments([ledgerRow({ amount: Number.NaN })]), /거래 금액/);
});
