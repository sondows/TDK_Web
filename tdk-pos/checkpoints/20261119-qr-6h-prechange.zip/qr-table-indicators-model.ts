export type QrTableIndicatorState = "NONE" | "TOKEN" | "PENDING_ORDER";

export function qrTableIndicatorState(status: { hasActiveQrToken: boolean; hasPendingQrOrder: boolean }): QrTableIndicatorState {
  if (status.hasPendingQrOrder) return "PENDING_ORDER";
  if (!status.hasActiveQrToken) return "NONE";
  return "TOKEN";
}
