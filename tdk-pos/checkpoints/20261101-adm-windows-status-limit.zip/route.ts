import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { adminSecurityOwners, staff } from "@/db/schema";
import { reserveAdminStatusAttempt } from "@/lib/admin-auth-limit";
import { getKdsRateLimitIp } from "@/lib/kds-network-server";
import { isNasOwnerSetupWrite } from "@/lib/nas-owner-setup";
import { classifyInitialMasterAccount } from "@/lib/initial-admin-setup";
import { requiresInitialMasterStatusLimit } from "@/lib/owner-setup-mode.cjs";

const noStore = { "Cache-Control": "no-store" };

/** Status is visible only in explicitly attested setup mode; ID alone never authorizes registration. */
export async function POST(request: Request) {
  if (!isNasOwnerSetupWrite(request))
    return NextResponse.json({ available: false }, { status: 403, headers: noStore });
  const body = await request.json().catch(() => null) as Record<string, unknown> | null;
  const loginId = typeof body?.loginId === "string" ? body.loginId.trim().toLowerCase() : "";
  if (!/^[a-z][a-z0-9._-]{2,31}$/.test(loginId))
    return NextResponse.json({ available: false }, { headers: noStore });
  try {
    if (requiresInitialMasterStatusLimit(process.env) &&
      !await reserveAdminStatusAttempt("initial-master-status", await getKdsRateLimitIp()))
      return NextResponse.json({ available: false }, { status: 429, headers: noStore });
    const [account] = await db.select({ staffId: staff.staffId, passwordHash: staff.securityPasswordHash,
      role: staff.role, isActive: staff.isActive, adminEnabled: staff.adminEnabled,
      terminatedAt: staff.terminatedAt, staffCode: staff.staffCode,
      isOwner: sql<boolean>`${adminSecurityOwners.staffId} IS NOT NULL`.as("is_owner") }).from(staff)
      .leftJoin(adminSecurityOwners, eq(adminSecurityOwners.staffId, staff.staffId))
      .where(sql`LOWER(${staff.adminLoginId}) = ${loginId}`)
      .limit(1);
    const state = classifyInitialMasterAccount({ accountFound: Boolean(account),
      passwordHash: account?.passwordHash ?? null, role: account?.role,
      active: account?.isActive, adminEnabled: account?.adminEnabled,
      terminatedAt: account?.terminatedAt, staffCode: account?.staffCode,
      isOwner: Boolean(account?.isOwner) });
    return NextResponse.json({ state, available: state === "MASTER_PASSWORD_REQUIRED",
      accountFound: Boolean(account), passwordConfigured: account ? account.passwordHash !== null : null }, { headers: noStore });
  } catch (error) {
    console.error("Initial master status unavailable", { code: (error as { code?: string }).code });
    return NextResponse.json({ available: false }, { status: 503, headers: noStore });
  }
}
