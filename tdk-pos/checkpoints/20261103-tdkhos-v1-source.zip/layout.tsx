import type { Metadata } from "next";

export const metadata: Metadata = { title: "TDK HOS", applicationName: "TDK HOS" };

export default function HosLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return children;
}
