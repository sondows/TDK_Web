import HosHome from "./HosHome";
import HosLogin from "./HosLogin";
import { getCurrentHosStaff } from "@/lib/hos-auth";
import { loadQrOrderNotificationCursor } from "@/lib/qr-table-indicators";

export const dynamic = "force-dynamic";

export default async function HosPage() {
  const staff = await getCurrentHosStaff();
  if (!staff) return <HosLogin />;
  const qrOrderNotificationCursor = await loadQrOrderNotificationCursor();
  return <HosHome qrOrderNotificationCursor={qrOrderNotificationCursor} staffLoginId={staff.loginId} />;
}
