"use client";

import { useEffect, useRef, useState } from "react";
import type { StaffSummary } from "@/lib/staff-management";
import styles from "../admin.module.css";

export default function StaffSecurityPasswordModal({ staff, onClose }: {
  staff: StaffSummary; onClose: () => void; onSaved: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [temporaryPassword, setTemporaryPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { const current = dialog.current; current?.showModal(); return () => current?.close(); }, []);
  const issue = async () => {
    if (busy || temporaryPassword) return;
    setBusy(true); setMessage("");
    try {
      const response = await fetch(`/api/admin-center/staff/${staff.staffId}/security-password`, { method: "POST" });
      const result = await response.json() as { success?: boolean; message?: string; temporaryPassword?: string };
      if (!response.ok || !result.success || !result.temporaryPassword) {
        setMessage(result.message ?? "임시 비밀번호를 발급하지 못했습니다."); return;
      }
      setTemporaryPassword(result.temporaryPassword);
    } catch { setMessage("임시 비밀번호를 발급하지 못했습니다."); }
    finally { setBusy(false); }
  };
  return <dialog aria-labelledby="staff-security-title" className={styles.customerModal}
    onCancel={event => { if (busy) event.preventDefault(); else onClose(); }} ref={dialog}>
    <div className={styles.customerModalHeader}><h2 id="staff-security-title">직원 임시 마스터 비밀번호</h2>
      <button aria-label="닫기" className={styles.customerModalClose} disabled={busy} onClick={onClose} type="button">×</button></div>
    <div className={styles.customerModalFields}>
      <p className="text-sm text-slate-600">직원 {staff.loginId}의 임시 비밀번호를 발급합니다. 기존 보안토큰과 로그인 세션은 무효화됩니다.</p>
      {temporaryPassword && <div className={styles.customerField}>
        <label htmlFor="staff-security-temporary">임시 비밀번호 (한 번만 표시)</label>
        <input className={styles.customerFieldInput} id="staff-security-temporary" readOnly value={temporaryPassword} />
        <p className="text-xs text-slate-500">직원 본인에게 안전하게 전달해 주세요. 최초 인증 후 본인이 새 비밀번호를 설정합니다.</p>
      </div>}
      {message && <p className={styles.customerFieldError} role="alert">{message}</p>}
    </div>
    <div className={styles.customerModalFooter}><button className={styles.customerCancelButton} disabled={busy}
      onClick={onClose} type="button">닫기</button><button className={styles.customerSubmitButton}
      disabled={busy || Boolean(temporaryPassword)} onClick={() => void issue()} type="button">
        {busy ? "발급 중…" : "임시 비밀번호 발급"}</button></div>
  </dialog>;
}
