import "server-only";

import { createHash } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { kdsAuthIpAttempts } from "@/db/schema";
import { sessionCookieSecure } from "@/lib/auth";
import { isExternalAdminHost } from "@/lib/host-access";
import { getKdsRateLimitIp } from "@/lib/kds-network-server";

export function kdsCookieSecureForRequest(request: Request) {
  return sessionCookieSecure || isExternalAdminHost(request.headers.get("host"));
}

export function isSameOriginRequest(request: Request) {
  const origin = request.headers.get("origin"), host = request.headers.get("host");
  if (!origin || !host) return false;
  try { return new URL(origin).host.toLowerCase() === host.toLowerCase(); }
  catch { return false; }
}

/** Trust and initial credential writes require a schemeful same-origin browser request. */
export function isHttpsSameOriginRequest(request: Request) {
  if (!isSameOriginRequest(request)) return false;
  if (process.env.NODE_ENV !== "production") return true;
  try { return new URL(request.headers.get("origin") ?? "").protocol === "https:"; }
  catch { return false; }
}

export async function reserveKdsIpAttempt() {
  const clientIp = await getKdsRateLimitIp();
  const ipHash = createHash("sha256").update(clientIp ?? "unverified-client-ip").digest("hex");
  await db.delete(kdsAuthIpAttempts).where(sql`${kdsAuthIpAttempts.updatedAt} < DATE_SUB(NOW(), INTERVAL 1 DAY)`);
  const expired = sql`${kdsAuthIpAttempts.windowStartedAt} <= DATE_SUB(NOW(), INTERVAL 15 MINUTE)`;
  await db.insert(kdsAuthIpAttempts).values({ ipHash, windowStartedAt: new Date(), attemptCount: 1 })
    .onDuplicateKeyUpdate({ set: {
      attemptCount: sql`IF(${expired}, 1, ${kdsAuthIpAttempts.attemptCount} + 1)`,
      windowStartedAt: sql`IF(${expired}, NOW(), ${kdsAuthIpAttempts.windowStartedAt})`,
      updatedAt: sql`NOW()`,
    } });
  const [row] = await db.select({ attemptCount: kdsAuthIpAttempts.attemptCount })
    .from(kdsAuthIpAttempts).where(eq(kdsAuthIpAttempts.ipHash, ipHash)).limit(1);
  return Boolean(row && row.attemptCount <= 30);
}
