"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import ProgramTrustGate from "@/components/ProgramTrustGate";

function errorText(status: number, code?: string) {
  if (code === "EMPLOYEE_PIN_NOT_CONFIGURED") return "개인 PIN이 설정되지 않았습니다. 최초 인증 화면에서 본인이 설정해 주세요.";
  if (code === "KDS_AUTH_SCHEMA_MISMATCH") return "인증 설정을 확인할 수 없습니다. 관리자에게 문의해 주세요.";
  if (code === "KDS_PERMISSION_DENIED") return "이 직원에게 KDS 사용 권한이 없습니다.\n관리자에게 문의해 주세요.";
  if (code?.includes("RATE_LIMIT") || status === 429) return "로그인 시도가 많습니다. 15분 후 다시 시도해 주세요.";
  if (status === 401) return "ID 또는 PIN을 확인해 주세요.";
  if (status === 503) return "인증 서비스를 이용할 수 없습니다. 잠시 후 다시 시도해 주세요.";
  return "로그인하지 못했습니다. 잠시 후 다시 시도해 주세요.";
}

export default function KitchenLogin() {
  return <ProgramTrustGate program="KDS"><KitchenPinLogin /></ProgramTrustGate>;
}

function KitchenPinLogin() {
  const router = useRouter();
  const [loginId, setLoginId] = useState("");
  const [pin, setPin] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const normalizedLoginId = loginId.trim().toLowerCase();
    if (busy || !normalizedLoginId || !/^\d{6}$/.test(pin)) return;
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/kitchen/auth/login", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ loginId: normalizedLoginId, pin }),
      });
      const result = await response.json() as { success?: boolean; code?: string };
      if (result.code === "TRUST_REQUIRED") { window.dispatchEvent(new Event("tdk-program-trust-required")); return; }
      if (!response.ok || !result.success) { setPin(""); setMessage(errorText(response.status, result.code)); return; }
      window.dispatchEvent(new Event("tdk-program-authenticated"));
      router.refresh();
    } catch { setPin(""); setMessage("네트워크 오류가 발생했습니다. 다시 시도해 주세요."); }
    finally { setBusy(false); }
  };

  return <main className="flex min-h-dvh items-center justify-center bg-slate-100 p-4">
    <section className="h-[min(600px,calc(100dvh-2rem))] w-full max-w-[440px] overflow-y-auto rounded-2xl bg-white p-6 shadow-xl sm:p-8">
      <header className="mb-6 text-center"><h1 className="text-4xl font-extrabold text-blue-600">TDKON</h1>
        <p className="mt-2 text-lg font-bold text-slate-600">로그인</p></header>
      <form onSubmit={event => void submit(event)}>
        <div className="space-y-4">
          <label className="block text-sm font-bold text-slate-700">ID
            <input autoCapitalize="none" autoComplete="username" autoCorrect="off"
              className="mt-2 min-h-14 w-full rounded-xl border border-slate-300 px-4 disabled:bg-slate-100"
              disabled={busy} inputMode="text" lang="en" maxLength={32}
              onChange={event => { setLoginId(event.target.value); setMessage(""); }}
              spellCheck={false} required type="text" value={loginId} /></label>
          <label className="block text-sm font-bold text-slate-700">PIN
            <input autoComplete="current-password"
              className="mt-2 min-h-14 w-full rounded-xl border border-slate-300 px-4 text-center text-2xl font-bold tracking-[0.5em] disabled:bg-slate-100"
              disabled={busy || !loginId.trim()} inputMode="numeric" maxLength={6}
              onChange={event => setPin(event.target.value.replace(/\D/g, "").slice(0, 6))}
              pattern="[0-9]{6}" required type="password" value={pin} /></label>
        </div>
        <div className="flex h-14 items-center justify-center"><p aria-live="polite"
          className={`max-h-full w-full overflow-y-auto text-center text-sm font-semibold text-red-600 ${message.includes("\n") ? "whitespace-pre-line break-keep leading-[1.2]" : ""}`}
          role={message ? "alert" : undefined}>{message}</p></div>
        <button className="min-h-14 w-full rounded-xl bg-blue-600 text-lg font-extrabold text-white disabled:opacity-50"
          disabled={busy || !loginId.trim() || !/^\d{6}$/.test(pin)} type="submit">
          {busy ? "로그인 중…" : "로그인"}</button>
      </form>
    </section>
  </main>;
}
