import { and, eq, isNull, ne } from "drizzle-orm";
import { db } from "@/db";
import { adminSecurityOwners, auditLogs, programTrustTokens, staff, staffSessions } from "@/db/schema";
import { hashProgramPassword } from "@/lib/auth";
import { getCurrentAdminStaff, requireOwnerSecurityAccess } from "@/lib/admin-auth";
import { isHttpsSameOriginRequest } from "@/lib/kds-device";
import { newTemporaryProgramPassword } from "@/lib/program-password-lifecycle";

/** Issue a temporary password; the employee must replace it before a trust token is issued. */
export async function POST(request: Request, { params }: { params: Promise<{ staffId: string }> }) {
  if (!isHttpsSameOriginRequest(request)) return Response.json({ success: false }, { status: 403 });
  const denied = await requireOwnerSecurityAccess();
  if (denied) return denied;
  const actor = await getCurrentAdminStaff();
  if (!actor) return Response.json({ success: false }, { status: 401 });
  const targetId = Number((await params).staffId);
  if (!Number.isSafeInteger(targetId) || targetId <= 0) return Response.json({ success: false }, { status: 400 });
  try {
    const temporaryPassword = newTemporaryProgramPassword();
    const hash = await hashProgramPassword(temporaryPassword);
    const issued = await db.transaction(async tx => {
      const [target] = await tx.select({ staffId: staff.staffId }).from(staff)
        .where(and(eq(staff.staffId, targetId), ne(staff.staffCode, "000"),
          eq(staff.isActive, 1), isNull(staff.terminatedAt))).limit(1).for("update");
      if (!target) return false;
      const [owner] = await tx.select({ staffId: adminSecurityOwners.staffId })
        .from(adminSecurityOwners).where(eq(adminSecurityOwners.staffId, targetId)).limit(1);
      if (owner) return false;
      const now = new Date();
      await tx.update(staff).set({ securityPasswordHash: hash, securityPasswordChangeRequired: 1,
        updatedAt: now }).where(eq(staff.staffId, targetId));
      await tx.update(programTrustTokens).set({ revokedAt: now, revokeReason: "PASSWORD_RESET" })
        .where(and(eq(programTrustTokens.enrolledByStaffId, targetId), isNull(programTrustTokens.revokedAt)));
      await tx.update(staffSessions).set({ status: "LOGGED_OUT", loggedOutAt: now, ownerReauthenticatedAt: null })
        .where(and(eq(staffSessions.staffId, targetId), eq(staffSessions.status, "ACTIVE")));
      await tx.insert(auditLogs).values({ staffId: actor.staffId,
        actionType: "TEMPORARY_PROGRAM_PASSWORD_ISSUED", entityType: "STAFF", entityId: targetId });
      return true;
    });
    return issued ? Response.json({ success: true, temporaryPassword }, {
      headers: { "Cache-Control": "no-store" },
    }) : Response.json({ success: false, message: "직원 상태 또는 최고관리자 보호 규칙을 확인해 주세요." },
      { status: 403 });
  } catch (error) {
    console.error("Temporary program password issuance failed", { code: (error as { code?: string }).code });
    return Response.json({ success: false, message: "임시 비밀번호를 발급하지 못했습니다." }, { status: 503 });
  }
}
