﻿export const QR_HISTORY_AUDIT_ACTIONS = [
  "QR_TABLE_ASSIGN",
  "QR_TARGET_ASSIGN",
  "QR_RETIRE",
  "QR_RETIRED_BY_REPLACEMENT",
  "QR_UNASSIGN",
] as const;

export type QrHistoryAuditAction = typeof QR_HISTORY_AUDIT_ACTIONS[number];
export type QrHistoryAuditRow = { actionType: string; createdAt: Date | null; description: string | null };
export type QrUsageHistoryEvent = { eventType: string; happenedAt: string; table: string | null; detail: string | null };

function toIso(value: Date | null): string | null {
  return value instanceof Date && Number.isFinite(value.getTime()) ? value.toISOString() : null;
}

export function buildQrUsageHistoryEvents(issuedAt: Date, auditRows: QrHistoryAuditRow[]): QrUsageHistoryEvent[] {
  const issueTime = toIso(issuedAt);
  const events: Array<QrUsageHistoryEvent | null> = [
    issueTime ? { eventType: "QR 발행", happenedAt: issueTime, table: null, detail: "관리번호 생성 기록" } : null,
    ...auditRows.map(row => {
      const happenedAt = toIso(row.createdAt);
      if (!happenedAt || !QR_HISTORY_AUDIT_ACTIONS.includes(row.actionType as QrHistoryAuditAction)) return null;
      const description = row.description ?? "";
      const tableId = row.actionType === "QR_TABLE_ASSIGN" ? description.match(/\btable\s+(\d+)\b/i)?.[1] : undefined;
      const target = row.actionType === "QR_TARGET_ASSIGN" ? description.match(/\bto\s+(GUEST_MENU|WAITING)\b/i)?.[1] : undefined;
      const eventType = row.actionType === "QR_TABLE_ASSIGN" ? "테이블 연결 변경"
        : row.actionType === "QR_TARGET_ASSIGN" ? "QR 사용 대상 변경"
          : row.actionType === "QR_RETIRED_BY_REPLACEMENT" ? "다른 QR로 교체되어 폐기"
            : row.actionType === "QR_UNASSIGN" ? "QR 연결 해제"
              : "QR 폐기";
      return {
        eventType,
        happenedAt,
        table: tableId ? `테이블 ID ${tableId}` : null,
        detail: target === "GUEST_MENU" ? "매장 메뉴 QR로 지정"
          : target === "WAITING" ? "대기 QR로 지정"
            : row.actionType === "QR_RETIRED_BY_REPLACEMENT" ? "기존 QR 관리 기록"
              : null,
      };
    }),
  ];
  return events.filter((event): event is QrUsageHistoryEvent => event !== null).sort((a, b) => Date.parse(b.happenedAt) - Date.parse(a.happenedAt));
}

export function unavailableQrUsageMetrics() {
  return { firstUseAt: null, recentUseAt: null, sessionCount: null, orderCount: null, anomalyCount: null, attributionAvailable: false } as const;
}
