﻿import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, diningTables, qrCodes, qrTableLinks } from "@/db/schema";
import { requireQrNoticeManager } from "@/lib/qr-notice-admin-auth";
import { buildQrUsageHistoryEvents, QR_HISTORY_AUDIT_ACTIONS, unavailableQrUsageMetrics } from "@/lib/qr-usage-history";

export const dynamic = "force-dynamic";
const HISTORY_LIMIT = 200;
type RouteContext = { params: Promise<{ qrCodeId: string }> };

function iso(value: Date | null): string | null {
  return value instanceof Date && Number.isFinite(value.getTime()) ? value.toISOString() : null;
}

export async function GET(_request: Request, { params }: RouteContext) {
  const auth = await requireQrNoticeManager();
  if ("error" in auth) return auth.error;

  const { qrCodeId: rawId } = await params;
  const qrCodeId = Number(rawId);
  if (!Number.isSafeInteger(qrCodeId) || qrCodeId <= 0) {
    return Response.json({ success: false, message: "QR 관리번호가 유효하지 않습니다." }, { status: 400, headers: { "Cache-Control": "no-store" } });
  }

  const [qr] = await db.select({
    qrCodeId: qrCodes.qrCodeId,
    managementNumber: qrCodes.managementNumber,
    status: qrCodes.status,
    targetType: qrCodes.targetType,
    createdAt: qrCodes.createdAt,
    tableNo: diningTables.tableNo,
  }).from(qrCodes)
    .leftJoin(qrTableLinks, eq(qrTableLinks.qrCodeId, qrCodes.qrCodeId))
    .leftJoin(diningTables, eq(diningTables.tableId, qrTableLinks.tableId))
    .where(eq(qrCodes.qrCodeId, qrCodeId)).limit(1);

  if (!qr) return Response.json({ success: false, message: "QR 관리번호를 찾을 수 없습니다." }, { status: 404, headers: { "Cache-Control": "no-store" } });

  const auditRows = await db.select({ actionType: auditLogs.actionType, createdAt: auditLogs.createdAt, description: auditLogs.description })
    .from(auditLogs)
    .where(and(eq(auditLogs.entityType, "QR_CODE"), eq(auditLogs.entityId, qrCodeId), inArray(auditLogs.actionType, [...QR_HISTORY_AUDIT_ACTIONS])))
    .orderBy(desc(auditLogs.createdAt), desc(auditLogs.auditLogId)).limit(HISTORY_LIMIT + 1);

  return Response.json({
    success: true,
    qr: {
      qrCodeId: Number(qr.qrCodeId),
      managementNumber: qr.managementNumber,
      status: qr.status,
      targetType: qr.targetType,
      issuedAt: iso(qr.createdAt),
      currentTable: qr.tableNo,
    },
    usage: unavailableQrUsageMetrics(),
    events: buildQrUsageHistoryEvents(qr.createdAt, auditRows.slice(0, HISTORY_LIMIT)),
    truncated: auditRows.length > HISTORY_LIMIT,
    eventAttributionNote: "고객 세션·주문에는 고정 QR 관리번호가 저장되지 않아 스캔, 초대, 장바구니, 주문, 결제 기록을 이 QR에 연결할 수 없습니다.",
  }, { headers: { "Cache-Control": "no-store" } });
}
