/* eslint-disable @typescript-eslint/no-require-imports */
const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");

const origin = "http://localhost:3000";
const chrome = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function main() {
  const profile = await fs.mkdtemp(path.join(os.tmpdir(), "tdk-adm-id-next-"));
  let browser;
  let socket;
  try {
    browser = spawn(chrome, ["--headless=new", "--disable-gpu", "--disable-extensions",
      "--no-first-run", "--remote-debugging-port=0", `--user-data-dir=${profile}`, "about:blank"],
    { stdio: "ignore", windowsHide: true });
    const until = async (check, label, limit = 100) => {
      for (let i = 0; i < limit; i++) {
        try { const result = await check(); if (result) return result; }
        catch { /* A page navigation may replace the execution context. */ }
        await delay(150);
      }
      const detail = await evaluate('document.body.innerText + "\\nINPUTS=" + Array.from(document.querySelectorAll("input")).map(i => [i.type, i.autocomplete, !!i.closest("dialog"), i.outerHTML]).join(" | ")').catch(() => "<unavailable>");
      throw new Error(`Timed out waiting for ${label}: ${detail}`);
    };
    const port = await until(async () => Number((await fs.readFile(
      path.join(profile, "DevToolsActivePort"), "utf8")).split(/\r?\n/)[0]) || null, "Chrome port");
    const page = await until(async () => (await (await fetch(
      `http://127.0.0.1:${port}/json/list`)).json())
      .find(item => item.type === "page" && item.webSocketDebuggerUrl), "Chrome page");
    socket = new WebSocket(page.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      socket.addEventListener("open", resolve, { once: true });
      socket.addEventListener("error", reject, { once: true });
    });
    let sequence = 0;
    const pending = new Map();
    const requests = [];
    const paused = [];
    let scenario = "";
    socket.addEventListener("message", event => {
      const message = JSON.parse(event.data);
      if (message.method === "Network.requestWillBeSent") {
        const request = message.params.request;
        const pathname = new URL(request.url).pathname;
        if (pathname.startsWith("/api/")) requests.push({ id: message.params.requestId,
          method: request.method, url: request.url, path: pathname, body: request.postData ?? "" });
      }
      if (message.method === "Network.responseReceived") {
        const request = requests.find(item => item.id === message.params.requestId);
        if (request) request.status = message.params.response.status;
      }
      if (message.method === "Fetch.requestPaused") {
        paused.push(message.params);
        if (scenario !== "hold") void fulfill(message.params);
        return;
      }
      if (!message.id) return;
      const entry = pending.get(message.id);
      if (!entry) return;
      pending.delete(message.id);
      if (message.error) entry.reject(new Error(message.error.message));
      else entry.resolve(message.result);
    });
    const send = (method, params = {}) => new Promise((resolve, reject) => {
      const id = ++sequence;
      const timer = setTimeout(() => { pending.delete(id); reject(new Error(method + " timeout")); }, 8000);
      pending.set(id, { resolve: value => { clearTimeout(timer); resolve(value); },
        reject: error => { clearTimeout(timer); reject(error); } });
      socket.send(JSON.stringify({ id, method, params }));
    });
    function mockResponse(request) {
      const url = new URL(request.request.url);
      if (request.request.url.includes("/api/admin-center/trust/initialize"))
        return { status: 200, body: { available: scenario === "bootstrap" } };
      if (request.request.url.includes("/api/admin-center/trust/initial-master/status")) {
        const loginId = JSON.parse(request.request.postData ?? "{}").loginId;
        if (scenario === "failure") return { status: 503, body: { available: false } };
        return { status: 200, body: { available: scenario === "register" && loginId === "sondows" } };
      }
      if (url.pathname === "/api/admin-center/trust") {
        const loginId = url.searchParams.get("loginId");
        const trusted = scenario === "pin" && loginId === "tokenuser";
        return { status: 200, body: { success: true, trusted, invalidated: false,
          pinSetupRequired: false, ...(trusted ? { loginId } : {}) } };
      }
      return { status: 500, body: { success: false } };
    }
    async function fulfill(request) {
      const result = mockResponse(request);
      await send("Fetch.fulfillRequest", { requestId: request.requestId, responseCode: result.status,
        responseHeaders: [{ name: "Content-Type", value: "application/json" }],
        body: Buffer.from(JSON.stringify(result.body)).toString("base64") });
    }
    const evaluate = async expression => {
      const result = await send("Runtime.evaluate", { expression, returnByValue: true });
      if (result.exceptionDetails) throw new Error("Browser expression failed");
      return result.result.value;
    };
    const start = async () => {
      await send("Page.navigate", { url: origin + "/tdkadm/login" });
      await until(() => evaluate('document.querySelector(\'input[autocomplete="username"]\') !== null'),
        "ID stage");
      await until(() => evaluate('Array.from(document.querySelectorAll("button")).some(b => b.textContent.trim() === "다음")'),
        "Next button");
    };
    const enterId = async loginId => {
      await evaluate('document.querySelector(\'input[autocomplete="username"]\').focus(); document.querySelector(\'input[autocomplete="username"]\').select()');
      await send("Input.insertText", { text: loginId });
      await until(() => evaluate(`document.querySelector('input[autocomplete="username"]')?.value === ${JSON.stringify(loginId)}`),
        "ID value");
    };
    const clickNext = async () => evaluate(
      'Array.from(document.querySelectorAll("button")).find(b => b.textContent.trim() === "다음")?.click()');
    const inputCount = () => evaluate('document.querySelectorAll("main section input").length');
    const hasDialog = () => evaluate('document.querySelector("dialog")?.open === true');
    const hasPassword = () => evaluate('document.querySelector(\'main > section > form input[autocomplete="current-password"]\') !== null');

    await send("Page.enable");
    await send("Runtime.enable");
    await send("Network.enable");
    await start();
    assert.equal(await inputCount(), 1, "first ADM screen contains only the ID field");
    assert.equal(await hasPassword(), false, "password is hidden before Next");
    assert.equal(requests.some(item => item.path.includes("initial-master/status")), false,
      "ID entry alone must not query account status");
    await enterId("sondows");
    assert.equal(requests.some(item => item.path.includes("initial-master/status")), false,
      "typing must not query account status");
    await clickNext();
    const realStatus = await until(() => requests.find(item =>
      item.path === "/api/admin-center/trust/initial-master/status" && item.status), "real setup status response");
    assert.equal(JSON.parse(realStatus.body).loginId, "sondows");
    assert.equal(realStatus.status, 403, "ordinary development mode must deny initial registration");
    await until(() => hasPassword(), "password login stage");
    assert.equal(await hasDialog(), false);
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), "sondows");
    await evaluate('Array.from(document.querySelectorAll("button")).find(b => b.textContent.includes("ID 변경"))?.click()');
    await until(async () => !(await hasPassword()), "back to ID");
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), "sondows");

    await send("Fetch.enable", { patterns: [
      { urlPattern: "*api/admin-center/trust?*", requestStage: "Request" },
      { urlPattern: "*api/admin-center/trust/initialize*", requestStage: "Request" },
      { urlPattern: "*api/admin-center/trust/initial-master/status*", requestStage: "Request" },
    ] });

    scenario = "hold";
    await start();
    await enterId("worker");
    await clickNext();
    await until(() => paused.length >= 3, "three held status requests");
    assert.equal(await evaluate('document.querySelector("main > section button[type=submit]")?.disabled'),
      true, "Next is disabled while account checks are pending");
    await evaluate('document.querySelector("main > section button[type=submit]")?.click()');
    await delay(200);
    assert.equal(paused.length, 3, "double click must not create duplicate requests");
    scenario = "password";
    for (const request of paused.splice(0)) await fulfill(request);
    await until(() => hasPassword(), "password stage after normal status");
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), "worker");
    await evaluate('Array.from(document.querySelectorAll("button")).find(b => b.textContent.includes("ID 변경"))?.click()');

    scenario = "pin";
    await start();
    await enterId("tokenuser");
    await clickNext();
    await until(() => evaluate('document.querySelector(\'#admin-login-pin\') !== null'), "PIN screen");
    assert.equal(await evaluate('document.querySelector("#admin-login-id")?.value'), "tokenuser",
      "selected ID must carry into PIN screen");
    assert.equal(await evaluate('document.querySelector("#admin-login-id")?.readOnly'), true);
    await evaluate('Array.from(document.querySelectorAll("button")).find(b => b.textContent.includes("ID 변경"))?.click()');
    await until(() => evaluate('document.querySelector(\'input[autocomplete="username"]\') !== null'), "PIN back to ID");
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), "tokenuser");

    scenario = "bootstrap";
    await start();
    await enterId("firstowner");
    await clickNext();
    await until(() => evaluate('document.querySelector("main p")?.textContent?.trim() === "최고관리자 최초 등록"'),
      "first owner registration");
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), "firstowner");
    await evaluate('Array.from(document.querySelectorAll("button")).find(b => b.textContent.includes("ID 변경"))?.click()');
    await until(() => evaluate('document.querySelector(\'input[autocomplete="username"]\') !== null'), "bootstrap back");
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), "firstowner");

    scenario = "register";
    await start();
    await enterId("sondows");
    await clickNext();
    await until(() => hasDialog(), "authorized first password dialog");
    assert.equal(await evaluate('document.querySelector("dialog h2")?.textContent?.trim()'),
      "마스터 비밀번호 등록");

    scenario = "failure";
    await evaluate('document.querySelector("dialog")?.close()');
    await evaluate('Array.from(document.querySelectorAll("button")).find(b => b.textContent.includes("ID 변경"))?.click()');
    await until(() => evaluate('document.querySelector(\'input[autocomplete="username"]\') !== null'), "failure case ID");
    await enterId("sondows");
    await clickNext();
    await until(() => evaluate('document.querySelector("[role=alert]")?.textContent?.includes("계정 상태를 확인할 수 없습니다")'),
      "status failure message");
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), "sondows");

    console.log(JSON.stringify({ realOrdinaryStatus: 403, nextOnly: true, duplicateBlocked: true,
      idPreservedOnPasswordBack: true, tokenBranchAndIdPreserved: true, bootstrapBranch: true,
      authorizedRegistrationBranch: true, statusFailureHandled: true }));
    await send("Fetch.disable");
  } finally {
    socket?.close();
    browser?.kill();
    const safeRoot = await fs.realpath(os.tmpdir());
    const safeProfile = await fs.realpath(profile);
    if (!safeProfile.startsWith(safeRoot + path.sep) ||
      !path.basename(safeProfile).startsWith("tdk-adm-id-next-"))
      throw new Error("Unexpected Chrome profile location");
    await fs.rm(safeProfile, { recursive: true, force: true, maxRetries: 10, retryDelay: 300 });
  }
}

main().catch(error => {
  console.error("ADM ID next flow check failed", { name: error.name, message: error.message });
  process.exitCode = 1;
});
