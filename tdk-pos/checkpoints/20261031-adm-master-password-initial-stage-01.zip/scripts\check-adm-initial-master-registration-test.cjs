/* eslint-disable @typescript-eslint/no-require-imports */
const assert = require("node:assert/strict");
const { createHash, randomBytes } = require("node:crypto");
const { spawn } = require("node:child_process");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const mysql = require("mysql2/promise");
require("dotenv").config({ path: ".env.local", quiet: true });

const origin = "http://localhost:3000";
const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const digest = value => createHash("sha256").update(value).digest("hex");
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function until(check, label, attempts = 100) {
  for (let i = 0; i < attempts; i++) {
    try { const result = await check(); if (result) return result; }
    catch { /* A navigation may replace the inspected page. */ }
    await delay(150);
  }
  throw new Error(`Timed out waiting for ${label}`);
}

async function main() {
  if (process.env.DB_NAME !== "TDK_POS_TEST") throw new Error("Only TDK_POS_TEST is allowed");
  const db = await mysql.createConnection({ host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 3306), user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME });
  const suffix = randomBytes(6).toString("hex");
  const loginId = `first${suffix}`;
  const staffCode = `FIRST-${suffix}`;
  const pinSentinel = `unchanged-pin-${suffix}`;
  const ownerSecondFactorSentinel = `existing-owner-2fa-${suffix}`;
  const token = randomBytes(32).toString("base64url");
  const password = `P7!${randomBytes(24).toString("base64url")}`;
  const accountAttemptKey = digest(`master-password-initial:account:${loginId}`);
  const profile = await fs.mkdtemp(path.join(os.tmpdir(), "tdk-adm-initial-master-"));
  let staffId = null;
  let browser;
  let socket;
  const requestById = new Map();
  try {
    const [created] = await db.execute("INSERT INTO staff " +
      "(staff_code,name,admin_login_id,employee_pin_hash,role,is_active,admin_enabled,kds_pin_change_required) " +
      "VALUES (?,'Initial Master Test',?,?, 'OWNER',1,1,0)", [staffCode, loginId, pinSentinel]);
    staffId = Number(created.insertId);
    await db.execute("INSERT INTO admin_security_owners (staff_id,password_hash,credential_state) " +
      "VALUES (?,?, 'ACTIVE')", [staffId, ownerSecondFactorSentinel]);
    await db.execute("INSERT INTO master_password_recovery_grants (staff_id,token_hash,expires_at) " +
      "VALUES (?,?,DATE_ADD(NOW(),INTERVAL 15 MINUTE))", [staffId, digest(token)]);

    const unauthorized = await fetch(`${origin}/api/program-trust/master-recovery/register-initial`, {
      method: "POST", headers: { origin, "content-type": "application/json" },
      body: JSON.stringify({ loginId, token: "X".repeat(43), password, confirmPassword: password }),
    });
    assert.equal(unauthorized.status, 401, "ID and password alone cannot authorize initial setup");
    const weakPassword = await fetch(`${origin}/api/program-trust/master-recovery/register-initial`, {
      method: "POST", headers: { origin, "content-type": "application/json" },
      body: JSON.stringify({ loginId, token, password: "weak", confirmPassword: "weak" }),
    });
    assert.equal(weakPassword.status, 400, "server must reject a weak password");
    const mismatch = await fetch(`${origin}/api/program-trust/master-recovery/register-initial`, {
      method: "POST", headers: { origin, "content-type": "application/json" },
      body: JSON.stringify({ loginId, token, password, confirmPassword: `${password}different` }),
    });
    assert.equal(mismatch.status, 400, "server must reject mismatched passwords");
    const [beforeRegistration] = await db.execute(
      "SELECT security_password_hash FROM staff WHERE staff_id=?", [staffId]);
    assert.equal(beforeRegistration[0].security_password_hash, null,
      "rejected registration attempts must not store a password");

    browser = spawn(chromePath, ["--headless=new", "--disable-gpu", "--disable-extensions",
      "--no-first-run", "--remote-debugging-port=0", `--user-data-dir=${profile}`, "about:blank"],
    { stdio: "ignore", windowsHide: true });
    const port = await until(async () => {
      const content = await fs.readFile(path.join(profile, "DevToolsActivePort"), "utf8");
      return Number(content.split(/\r?\n/)[0]) || null;
    }, "Chrome debugging port");
    const page = await until(async () => {
      const response = await fetch(`http://127.0.0.1:${port}/json/list`);
      return (await response.json()).find(item => item.type === "page" && item.webSocketDebuggerUrl);
    }, "Chrome page");
    socket = new WebSocket(page.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      if (socket.readyState === WebSocket.OPEN) return resolve();
      const timer = setTimeout(() => reject(new Error("Chrome WebSocket open timeout")), 5000);
      socket.addEventListener("open", () => { clearTimeout(timer); resolve(); }, { once: true });
      socket.addEventListener("error", error => { clearTimeout(timer); reject(error); }, { once: true });
      socket.addEventListener("close", () => { clearTimeout(timer);
        reject(new Error("Chrome WebSocket closed before open")); }, { once: true });
    });
    let sequence = 0;
    const pending = new Map();
    const requests = [];
    socket.addEventListener("message", event => {
      const message = JSON.parse(event.data);
      if (message.method === "Network.requestWillBeSent") {
        const request = message.params.request;
        const pathname = new URL(request.url).pathname;
        if (pathname.startsWith("/api/")) {
          let requestId;
          if (pathname.endsWith("/master-recovery/status") ||
              pathname.endsWith("/master-recovery/register-initial")) {
            try { requestId = JSON.parse(request.postData ?? "{}").loginId; } catch { /* Ignore malformed test bodies. */ }
          }
          requests.push({ requestKey: message.params.requestId, method: request.method, path: pathname,
            ...(requestId ? { loginId: requestId } : {}) });
          requestById.set(message.params.requestId, requests.at(-1));
        }
      }
      if (message.method === "Network.responseReceived") {
        const observed = requestById.get(message.params.requestId);
        if (observed) observed.status = message.params.response.status;
      }
      if (!message.id) return;
      const entry = pending.get(message.id);
      if (!entry) return;
      pending.delete(message.id);
      if (message.error) entry.reject(new Error(message.error.message));
      else entry.resolve(message.result);
    });
    const send = (method, params = {}) => new Promise((resolve, reject) => {
      const id = ++sequence;
      const timer = setTimeout(() => { pending.delete(id);
        reject(new Error(`Chrome command timed out: ${method}`)); }, 5000);
      pending.set(id, { resolve: result => { clearTimeout(timer); resolve(result); },
        reject: error => { clearTimeout(timer); reject(error); } });
      socket.send(JSON.stringify({ id, method, params }));
    });
    const evaluate = async expression => {
      const result = await send("Runtime.evaluate", { expression, returnByValue: true });
      if (result.exceptionDetails) throw new Error("Browser expression failed");
      return result.result.value;
    };
    const hasButton = label => evaluate(
      `Array.from(document.querySelectorAll("button")).some(button => button.textContent?.trim() === ${JSON.stringify(label)})`);
    await send("Page.enable");
    await send("Runtime.enable");
    await send("Network.enable");
    await send("Page.navigate", { url: `${origin}/tdkadm/login?recovery=1#master-recovery=${token}` });
    await until(() => hasButton("계정 상태 확인"), "ID check screen");
    const idValue = await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value');
    assert.equal(idValue, loginId, "NAS grant should bind the page to its approved account");

    await evaluate('document.querySelector(\'input[autocomplete="username"]\').focus()');
    await send("Input.dispatchKeyEvent", { type: "keyDown", key: "Tab", code: "Tab", windowsVirtualKeyCode: 9 });
    await send("Input.dispatchKeyEvent", { type: "keyUp", key: "Tab", code: "Tab", windowsVirtualKeyCode: 9 });
    await until(() => evaluate('document.querySelector("dialog")?.open === true'), "registration dialog after blur");
    assert.equal(await evaluate('document.querySelector("dialog h2")?.textContent?.trim()'), "마스터 비밀번호 등록");
    await send("Input.dispatchKeyEvent", { type: "keyDown", key: "Escape", code: "Escape", windowsVirtualKeyCode: 27 });
    await send("Input.dispatchKeyEvent", { type: "keyUp", key: "Escape", code: "Escape", windowsVirtualKeyCode: 27 });
    await until(() => evaluate('document.querySelector("dialog")?.open === false'), "registration dialog close");

    await evaluate('document.querySelector(\'input[autocomplete="username"]\').focus()');
    await send("Input.dispatchKeyEvent", { type: "keyDown", key: "Enter", code: "Enter",
      text: "\r", unmodifiedText: "\r", windowsVirtualKeyCode: 13 });
    await send("Input.dispatchKeyEvent", { type: "keyUp", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13 });
    try {
      await until(() => evaluate('document.querySelector("dialog")?.open === true'), "registration dialog after Enter");
    } catch (error) {
      const diagnostic = await evaluate(`({ text: document.body?.innerText.slice(0, 500),
        active: document.activeElement?.tagName + ":" + document.activeElement?.getAttribute("autocomplete"),
        id: document.querySelector('input[autocomplete="username"]')?.value,
        dialogOpen: document.querySelector("dialog")?.open })`);
      throw new Error(`${error.message}; browser=${JSON.stringify(diagnostic)}`);
    }
    const fields = await evaluate(`(() => {
      const inputs = Array.from(document.querySelectorAll("dialog input"));
      const values = ["weak", "weak"];
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      inputs.forEach((input, index) => {
        input.focus(); setter.call(input, values[index]);
        input.dispatchEvent(new InputEvent("input", { bubbles: true }));
      });
      return { count: inputs.length, valuesMatch: inputs.every(input => input.value === values[0]) };
    })()`);
    assert.equal(fields.count, 2);
    assert.equal(fields.valuesMatch, true);
    await until(() => hasButton("등록"), "registration submit button");
    let canSubmit = await evaluate('Array.from(document.querySelectorAll("dialog button")).some(button => button.textContent?.trim() === "등록" && !button.disabled)');
    assert.equal(canSubmit, false, "weak passwords should keep registration disabled");
    await evaluate(`(() => {
      const inputs = Array.from(document.querySelectorAll("dialog input"));
      const values = [${JSON.stringify(password)}, ${JSON.stringify(`${password}different`)}];
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      inputs.forEach((input, index) => {
        input.focus(); setter.call(input, values[index]);
        input.dispatchEvent(new InputEvent("input", { bubbles: true }));
      });
    })()`);
    await until(() => evaluate('document.querySelectorAll("dialog input")[0]?.value.length > 10'), "strong password entry");
    canSubmit = await evaluate('Array.from(document.querySelectorAll("dialog button")).some(button => button.textContent?.trim() === "등록" && !button.disabled)');
    assert.equal(canSubmit, false, "mismatched passwords should keep registration disabled");
    await evaluate(`(() => {
      const input = document.querySelectorAll("dialog input")[1];
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
      input.focus(); setter.call(input, ${JSON.stringify(password)});
      input.dispatchEvent(new InputEvent("input", { bubbles: true }));
    })()`);
    canSubmit = await until(() => evaluate('Array.from(document.querySelectorAll("dialog button")).some(button => button.textContent?.trim() === "등록" && !button.disabled)'), "matching password enable");
    assert.equal(canSubmit, true, "valid matching passwords should enable registration");
    await evaluate('Array.from(document.querySelectorAll("dialog button")).find(button => button.textContent?.trim() === "등록").click()');
    await until(async () => await hasButton("인증") &&
      await evaluate('document.querySelector(\'input[autocomplete="current-password"]\')?.value === ""'),
    "ADM first-auth screen after password registration");
    assert.equal(await evaluate('document.querySelector(\'input[autocomplete="username"]\')?.value'), loginId,
      "ID should remain in the first-auth screen");
    assert.equal(await evaluate('document.querySelector("dialog")?.open === false'), true);

    const [rows] = await db.execute("SELECT s.admin_login_id,s.security_password_hash,s.employee_pin_hash," +
      "s.role,s.admin_enabled,s.is_active,o.credential_state,o.password_hash AS owner_password_hash " +
      "FROM staff s INNER JOIN admin_security_owners o ON o.staff_id=s.staff_id WHERE s.staff_id=?", [staffId]);
    const saved = rows[0];
    assert.equal(saved.admin_login_id, loginId);
    assert.equal(saved.security_password_hash?.startsWith("scrypt$"), true);
    assert.notEqual(saved.security_password_hash, password);
    assert.equal(saved.employee_pin_hash, pinSentinel);
    assert.equal(saved.role, "OWNER");
    assert.equal(Number(saved.admin_enabled), 1);
    assert.equal(Number(saved.is_active), 1);
    assert.equal(saved.credential_state, "ACTIVE");
    assert.equal(saved.owner_password_hash, ownerSecondFactorSentinel);
    const [accessRows] = await db.execute("SELECT " +
      "(SELECT COUNT(*) FROM program_trust_tokens WHERE enrolled_by_staff_id=? ) AS token_count," +
      "(SELECT COUNT(*) FROM staff_sessions WHERE staff_id=? ) AS session_count," +
      "(SELECT COUNT(*) FROM master_password_recovery_grants WHERE staff_id=? AND used_at IS NOT NULL) AS used_grants",
    [staffId, staffId, staffId]);
    assert.equal(Number(accessRows[0].token_count), 0);
    assert.equal(Number(accessRows[0].session_count), 0);
    assert.equal(Number(accessRows[0].used_grants), 1);
    assert.ok(requests.some(item => item.path.endsWith("/master-recovery/status") && item.loginId === loginId));
    assert.ok(requests.some(item => item.path.endsWith("/master-recovery/register-initial") && item.loginId === loginId));
    assert.equal(requests.find(item => item.path.endsWith("/master-recovery/status") && item.loginId === loginId)?.status, 200);
    assert.equal(requests.find(item => item.path.endsWith("/master-recovery/register-initial") && item.loginId === loginId)?.status, 200);
    assert.equal(requests.some(item => item.method === "POST" &&
      ["/api/admin-center/trust", "/api/program-trust/pin"].includes(item.path)), false,
    "registration must not authenticate or start PIN enrollment");

    const replay = await fetch(`${origin}/api/program-trust/master-recovery/register-initial`, {
      method: "POST", headers: { origin, "content-type": "application/json" },
      body: JSON.stringify({ loginId, token, password, confirmPassword: password }),
    });
    assert.equal(replay.status, 401, "a consumed grant cannot register again");
    const [hashAfterReplay] = await db.execute("SELECT security_password_hash FROM staff WHERE staff_id=?", [staffId]);
    assert.equal(hashAfterReplay[0].security_password_hash, saved.security_password_hash);

    process.stdout.write(JSON.stringify({ db: "TDK_POS_TEST", browser: "pass", statusCheck: "pass",
      openedOnBlur: true, openedOnEnter: true, registration: "pass", storedHash: "scrypt",
      idRetained: true, authButtonVisible: true, passwordFieldEmpty: true,
      loginAttempted: false, tokensChanged: false, pinChanged: false, sessionsCreated: false,
      replayRejected: true }) + "\n");
  } finally {
    if (socket) socket.close();
    if (browser) browser.kill();
    if (staffId !== null) {
      await db.execute("DELETE FROM admin_auth_attempts WHERE attempt_key=?", [accountAttemptKey]).catch(() => {});
      await db.execute("DELETE FROM audit_logs WHERE staff_id=?", [staffId]);
      await db.execute("DELETE FROM master_password_recovery_grants WHERE staff_id=?", [staffId]);
      await db.execute("DELETE FROM admin_security_owners WHERE staff_id=?", [staffId]);
      await db.execute("DELETE FROM staff WHERE staff_id=? AND staff_code=?", [staffId, staffCode]);
      process.stdout.write(JSON.stringify({ db: "TDK_POS_TEST", fixtureCleanup: "complete" }) + "\n");
    }
    await db.end();
    const safeRoot = await fs.realpath(os.tmpdir());
    const safeProfile = await fs.realpath(profile);
    if (!safeProfile.startsWith(safeRoot + path.sep) ||
      !path.basename(safeProfile).startsWith("tdk-adm-initial-master-"))
      throw new Error("Unexpected Chrome profile location");
    await fs.rm(safeProfile, { recursive: true, force: true, maxRetries: 10, retryDelay: 500 });
  }
}

main().catch(error => {
  console.error("ADM initial master registration test failed", { code: error.code ?? error.name,
    message: error.message });
  process.exitCode = 1;
});
